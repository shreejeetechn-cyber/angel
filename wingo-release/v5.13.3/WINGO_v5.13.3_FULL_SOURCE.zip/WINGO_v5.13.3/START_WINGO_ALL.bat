@echo off
setlocal
set "WINGO_ENV_MODE=CENTRAL"
title WINGO v5.08 - Exclusive UI Notice
echo.
echo WINGO v5.08 uses ONE ACTIVE GUI AT A TIME.
echo START_WINGO_ALL.bat is retired to prevent simultaneous Desktop/Web control.
echo.
echo Use one of:
echo   START_WINGO.bat      - Desktop control
echo   START_WINGO_WEB.bat  - Web control
echo.
pause
exit /b 2

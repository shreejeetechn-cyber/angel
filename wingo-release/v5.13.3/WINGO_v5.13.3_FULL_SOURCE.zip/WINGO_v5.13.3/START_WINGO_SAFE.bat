@echo off
rem WINGO v5.06 Unified Core safe Desktop launcher.
rem Safe start suppresses automatic provider/feed/scanner startup for recovery.
setlocal EnableExtensions
set "WINGO_ENV_MODE=CENTRAL"
set "WINGO_SAFE_START=1"
call "%~dp0START_WINGO.bat"
endlocal

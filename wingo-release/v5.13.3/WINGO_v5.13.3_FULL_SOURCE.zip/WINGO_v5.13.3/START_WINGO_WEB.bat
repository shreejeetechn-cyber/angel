@echo off
rem WINGO v5.08 Web launcher: starts or attaches to the singleton Unified Core runtime.
setlocal EnableExtensions
set "WINGO_ENV_MODE=CENTRAL"


cd /d "%~dp0"
set "WINGO_VERSION="
set /p "WINGO_VERSION="<"VERSION.txt"
title WINGO v%WINGO_VERSION% Unified Core - Web

set "SEARCH=%CD%"
set "WINGO_ROOT="

:find_root
for %%I in ("%SEARCH%") do set "NAME=%%~nxI"
if /I "%NAME%"=="Wingo" (
    set "WINGO_ROOT=%SEARCH%"
    goto root_found
)
for %%I in ("%SEARCH%\..") do set "NEXT=%%~fI"
if /I "%NEXT%"=="%SEARCH%" goto root_fallback
set "SEARCH=%NEXT%"
goto find_root

:root_fallback
for %%I in ("%CD%\..") do set "WINGO_ROOT=%%~fI"

:root_found
set "PY=%WINGO_ROOT%\.venv\Scripts\python.exe"
set "ENVFILE=%WINGO_ROOT%\.env"
set "WINGO_ENV_FILE=%ENVFILE%"

echo.
echo ============================================
echo       WINGO UNIFIED CORE WEB WORKSPACE
echo ============================================
echo URL   : http://127.0.0.1:8787/
echo Scope : 32/32 shared runtime pages + authenticated Unified-Core controls
echo Auth  : Login required (credentials shown below on first run)
echo Safety: LIVE EXECUTION LOCKED
echo.

if not exist "%PY%" (
    echo [ERROR] Shared Python environment not found:
    echo %PY%
    echo Run setup_common_venv.ps1 first.
    pause
    exit /b 1
)

if not exist "%ENVFILE%" (
    echo [ERROR] Central WINGO .env not found:
    echo %ENVFILE%
    pause
    exit /b 1
)

"%PY%" -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 12)"
if errorlevel 1 (
    echo [ERROR] WINGO requires Python 3.12 in the shared .venv.
    "%PY%" --version
    pause
    exit /b 1
)

"%PY%" "%CD%\app\core\dependency_check.py" "%CD%\requirements.txt"
if errorlevel 1 (
    echo [SETUP] Installing or repairing WINGO Web dependencies...
    "%PY%" -m pip install --disable-pip-version-check -r "%CD%\requirements.txt"
    if errorlevel 1 (
        echo [ERROR] Dependency installation failed.
        pause
        exit /b 1
    )
    "%PY%" "%CD%\app\core\dependency_check.py" "%CD%\requirements.txt"
    if errorlevel 1 (
        echo [ERROR] Dependency verification still fails.
        pause
        exit /b 1
    )
)

echo [OK] Ensuring singleton Core and opening localhost Web GUI...
echo Closing this launcher does NOT stop WINGO Core.
echo.

"%PY%" -m app.core.unified_launcher --web --open-browser

if errorlevel 1 (
    echo.
    echo [ERROR] WINGO Web stopped with an error.
    echo Check whether port 8787 is already in use and review WINGO logs.
    pause
    exit /b 1
)

endlocal

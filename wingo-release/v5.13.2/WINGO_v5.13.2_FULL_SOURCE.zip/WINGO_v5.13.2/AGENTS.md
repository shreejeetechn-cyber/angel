# Release versioning

The user requires an incremented numeric version for every release and its folder/files.

- Current release: 5.13.2. The next patch release is 5.13.3; increment for each new published build.
- Treat VERSION.txt as the release authority. Keep runtime APP_VERSION, BUILD_NAME, source distribution profile, install marker and installer default consistent with it.
- Read VERSION.txt in build/launch scripts and workflow artifact names. Pad it to four numeric components for Windows file/product version metadata.
- Use a fresh source root `WINGO_v<version>` and archive `WINGO_v<version>_FULL_SOURCE.zip`.
- Include `v<version>` in accompanying release README, validation, checksum, change-list and diff filenames, and publish under `wingo-release/v<version>/`.
- Preserve previously published folders/artifacts. Verify the archive top-level folder, runtime version, install version and report version all agree before delivery.
- Stable Python import/entry-point names and installed executable names are runtime contracts; version the release folders and distributable filenames rather than renaming imports.
- Run the relevant release checks against the exact source being packaged. State Windows compilation and live-broker test limitations accurately.
- All source versions share the central `<Wingo root>/.env` for broker login. Normal mode is CENTRAL and must not follow stale WINGO_ENV_FILE test overrides.
- Explicit ISOLATED/EXPLICIT modes require WINGO_ENV_FILE; QA must always opt into ISOLATED with temporary state/credentials and must never fall back to the user's central file.
- Dhan reads, validates, saves and renews through the same central config authority. Preserve other broker settings and never create per-version credential copies.

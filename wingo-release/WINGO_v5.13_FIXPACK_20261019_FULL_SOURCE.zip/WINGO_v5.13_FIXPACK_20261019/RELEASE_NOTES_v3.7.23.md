# WINGO v3.7.23 dual_screen_paper_currency

## Added

- Detects display topology at startup and while WINGO is running.
- Automatically opens Profitability maximized on the display other than the main WINGO display.
- Returns the pop-out to the WINGO display when a monitor is removed.
- Adds `Settings → General → Auto Pop-out Profitability on Second Monitor`.
- Safe Start suppresses automatic pop-out.

## Paper currency contract

- Persists Lots, Lot Size and Total Units separately.
- Uses `Total Units = Lots × Lot Size` for new manual and automatic Paper entries.
- Single-leg Entry/Current Value uses contract LTP/net × Total Units.
- Multi-leg Fill Net is calculated from the exact BUY/SELL leg fills; currency value multiplies the net by Total Units.
- Positions and P&L Ledger expose Reference Net, Fill Net, Entry Value, Current Value, charges, slippage, gross P&L and net P&L.
- Entry tooltips retain market quote/fill source and quote age.
- Legacy OPEN positions migrate with a double-multiplication guard. Closed legacy history is not monetarily rewritten.

## Retained

- v3.7.22 bool-safe table Focus controls.
- Central `.env` and shared `.venv` launch contract.
- Upstox/FYERS feeds, exact contract locks, scanner/Signal gates and real-execution lock.

# WINGO v3.7.15 — Signal Page Readability & Lifecycle Observability

## Scope
This is a narrow **Signal Page** upgrade built from the verified v3.7.14 base. The Profitability Page remains a separate module and its page/controller/scoring/lifecycle/acceptance sources are unchanged.

## Signal Page improvements
- Added independent view presets: **ACTIVE / OPTIONS / FUTURES / ALL**.
- Kept all existing **25 Signal columns** available in `ALL`.
- Added Signal-only search plus dropdown filters for **Signal Type, Quality, State, Alignment, Policy, Side, and Strategy**.
- Added quick controls for **ACTIVE ONLY, NEW, WEAKENING, BLOCKED, PAPER ELIGIBLE, BEST FIRST, AUTO FIT, RESET**.
- `Trade Permission` display is clarified on this page as **Policy = ALLOW / BLOCK**; the underlying policy evaluation is unchanged.
- `Updated` is presented as compact relative **Age**; the exact timestamp remains available in tooltips/details.
- Added a selected-row **WHY THIS SIGNAL?** panel showing Signal source, lifecycle state/state age, quality, score, alignment, R:R, policy, paper eligibility, divergence/block reason, and current reason.
- Added bounded Signal lifecycle observability: `state_changed_at` plus up to 64 state-history entries. Older saved records receive backward-compatible defaults.
- Superseded option/futures invalidations now pass through the Signal lifecycle transition helper so the lifecycle history records the invalidation.
- Added Signal-specific cell-data Auto Fit, 90th-percentile representative sizing, wrapped headers, width caps, and one-column viewport slack fill. No continuous `ResizeToContents` was introduced.
- Best First is presentation sorting only: Signal State → Quality → Score → Alignment → R:R → age. Signal scoring formulas are not changed.

## Windows Table Tools crash fix
The reported runtime error:

`AttributeError: 'PySide6.QtWidgets.QWidget' object has no attribute 'addSeparator'`

was traced to relying on the wrapper returned by `QMenu.addMenu(str)`. `Sort` and `Columns` are now created as explicit `QMenu` objects and then attached to the parent menu. This removes the failing wrapper path while retaining the existing Table Tools actions.

## Safety / separation
- **Profitability Page remains separate from Signal Page.** No Signal filter/view code calls Profitability logic.
- Profitability Page/engine protected files are byte-identical to the v3.7.14 base.
- Existing WINGO `THEME` palette is byte-identical to v3.7.14.
- Signal scoring, trend-policy evaluation, Paper eligibility, risk controls and live execution gate are unchanged except for lifecycle-history bookkeeping around state transitions.
- FYERS SDK remains pinned to **3.1.16**.
- Broker `.place_order()` calls remain **zero**.
- Live execution remains **LOCKED**.

## Verification
- 33 / 33 QA scripts PASS.
- 904 `PASS:` assertions.
- 150 / 150 Python files compile.
- Profitability protected hashes unchanged.
- Existing theme palette unchanged.
- Table Tools explicit-QMenu fix statically verified.

The build container does not include PySide6, so exact Windows widget rendering and the reported Windows menu interaction cannot be executed here. The failing source path is removed and should be rechecked on the target Windows runtime.

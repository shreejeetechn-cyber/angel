# WINGO v4.0.1 autonomous_ai_trade_planner

## Cash Holdings

- Adds a dedicated `Paper -> Cash Holdings` tab while preserving the existing F&O Positions workflow.
- Supports BUY-only paper equity-delivery holdings with normalized NSE cash symbols, quantity, buy price, optional stop and target.
- Reserves full paper purchase value from available cash and uses executable BID for long-holding valuation/close.
- Adds Cash Deployed to the Dashboard and keeps the persistent P&L Ledger combined for auditability.
- Adds a distinct CASH/equity-delivery cost classification so equity trades no longer fall through to option charges.
- Optional cash stop/target integrates with the existing paper auto-exit decision path.

## Stability and compatibility

- Retains the v4.0.0 autonomous AI trade-planner features, F&O workflows, profitability controls, scanner, feeds, diagnostics, runtime isolation and safety lock.
- Retains the startup `datetime` hotfix in `_refresh_dashboard()`.
- Live broker execution remains locked; Cash Holdings is paper simulation only.
- Cash short-selling is not enabled.

## Version identity

- Runtime, launcher title, README current-build label and package root are promoted to **v4.0.1**.
- Earlier release notes and QA records remain in the package as historical records.

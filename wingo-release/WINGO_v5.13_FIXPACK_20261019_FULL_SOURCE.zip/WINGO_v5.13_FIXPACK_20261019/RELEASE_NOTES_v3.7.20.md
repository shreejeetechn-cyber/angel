# WINGO v3.7.20 manual_paper_control

This release fixes manual Paper entry observability without enabling real broker execution.

- Adds a persistent `underlying` field to Paper positions and ledger events.
- Migrates older saved rows from the matching Signal record, with a conservative contract-symbol fallback.
- Shows `Script` separately from exact `Contracts` in Paper Positions and P&L Ledger.
- Shows manual Paper readiness, exact block reason, and remaining Risk slots on the Signals page.
- Replaces silent manual-entry failures with an explicit warning dialog and successful opens with a confirmation dialog.
- Adds configurable `Manual Reserve` to Paper Automation; Auto Entry defaults to leaving one global Risk slot available.
- Preserves contract locks, fills, charges, slippage, live marks, P&L, execution lock, and all v3.7.19 runtime isolation controls.

Existing sessions that already have all Risk slots occupied remain protected. Close one Paper position or deliberately change `Risk → Max positions` before opening another manual position.

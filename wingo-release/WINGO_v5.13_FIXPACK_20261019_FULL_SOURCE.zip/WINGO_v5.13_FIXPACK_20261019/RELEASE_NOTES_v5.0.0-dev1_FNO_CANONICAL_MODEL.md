# WINGO v5.0.0-dev1 — F&O Canonical Core Model

Base: WINGO v4.5.2 Exclusive UI + Web-App Stability

## Scope
This build implements the correct Futures & Options identity model without claiming the full v5 Core-separation roadmap is complete.

## Core model
- Tradable canonical identity is FUTURE or OPTION only.
- Cash equity/index symbols are UnderlyingReference objects only.
- Bare symbols are no longer silently converted to NSE:<symbol>-EQ in the Core subscription path.
- Canonical IDs are provider independent.
- FYERS symbols and Upstox instrument keys are provider IDs/adapters, not business identity.

## Canonical examples
Future:
NSE|FNO|DABUR|FUTURE|2026-09-24

Option:
NSE|FNO|DABUR|OPTION|2026-09-24|520|CE

Reference only:
NSE|REFERENCE|DABUR|SPOT

## Integration
- Scanner uses explicit reference_symbol / underlying_reference_id.
- Futures contracts expose canonical_instrument and canonical_id.
- Upstox maps exact exchange + underlying + expiry + strike + CE/PE into canonical F&O contracts.
- Option-chain legs carry instrument_id separately from provider_id/symbol.
- Strategy legs preserve instrument_id.
- Signal lifecycle persists instrument_id.
- Paper positions persist instrument_id.
- Contract locks prefer canonical instrument_id, making them provider-symbol independent.

## Compatibility retained
- Existing NSE reference workflows remain supported through explicit compatibility adapters.
- v4.5.2 exclusive Desktop/Web UI behavior retained.
- v4.4.1 Profitability signature fix retained.
- v4.2.13 Profitability selected-timeframe logic retained.
- v4.3.3 worker/CVD stability protections retained.
- Profitability automatic pop-out remains disabled; Manual Pop Out retained.
- Live broker execution remains LOCKED.
- Stage 8 remains ABSENT.

## Verification
- Canonical F&O model: 36/36 PASS
- v4.5.2 stability regression: 56/56 PASS
- predecessor regression: 22/22 PASS
- Signal sorting regression: 14/14 PASS
- Combined: 128/128 PASS
- 181 application Python modules AST parse/compile successfully.
- JavaScript syntax check PASS.
- No app .place_order( call exists.

## Environment limitation
The verification environment is not a Windows live-market FYERS/Upstox session. Final live broker/session soak remains a Windows-side acceptance check.

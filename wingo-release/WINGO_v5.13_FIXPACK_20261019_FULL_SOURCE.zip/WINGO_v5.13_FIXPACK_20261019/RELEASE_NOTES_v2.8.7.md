# WINGO v2.8.7 — Session Audit + Paper Automation

## Session Audit
- Per-run JSONL event log under `.wingo_state/sessions/`.
- Continuous JSON/TXT summary plus `LATEST_SESSION_SUMMARY.txt`.
- Current IDLE/RUNNING/LIVE/RECONNECTING/OFFLINE/DISABLED state.
- Last PASS/FAIL/WARN/STOPPED/NOT RUN result.
- Every UI activity line mirrored to rotating `wingo.log` and session JSONL.
- Background task durations, safe errors, startup/shutdown and unhandled exceptions.
- Session Audit & Logs page with status matrix, export and open-folder controls.
- Credential values are redacted.

## Auto Paper audit/fixes
1. Paper WebSocket now reuses hardened FYERS live feed (`reconnect=True`, auth preflight, error classification, 200 symbol guard).
2. Auto-entry rejects stale signals; default max age 60 minutes.
3. Missing option symbols and invalid reference prices are rejected.
4. Daily loss uses today's local-calendar realized PnL, not all-time PnL.
5. Per-trade risk budget is now enforced (`PER_TRADE_RISK`).
6. AUTO EXIT has an independent ON/OFF control; default ON.
7. Paper feed callbacks are generation-safe so retired sockets cannot overwrite current state.
8. RECONNECTING is healthy and will not trigger needless socket restarts.
9. Auto-entry is skipped outside market session.
10. Positions persist exit reason and UI shows Today Realized / Exit Reason.
11. Auto-entry cycles, rejects, opens, exits and feed lifecycle are recorded in Session Audit.

Real execution remains locked.

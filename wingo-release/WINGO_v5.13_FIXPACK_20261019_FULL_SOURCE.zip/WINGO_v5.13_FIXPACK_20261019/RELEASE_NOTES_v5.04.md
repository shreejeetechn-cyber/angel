# WINGO v5.04 — MCX Profitability LTP + Buffered Risk Sizing

Base: WINGO v5.03 MCX Futures Signal Decoupling Verified

## Repairs
- Profitability rows now register exact WINGO F&O contract identity, display underlying, reference/provider aliases and derived monthly provider symbols.
- MCX exact identity such as `MCX|FNO|COPPER|FUTURE|2026-09-30` binds to live symbols such as `MCX:COPPER26SEPFUT`.
- Upstox live ticks carry `canonical_fno_id` through the common normalized tick pipeline, avoiding loss of exact contract identity.
- Risk-based Paper sizing now uses the same components as the final risk gate before requesting lots: planned stop risk + estimated round-trip costs + 10% gap/latency buffer.
- Position sizing also respects remaining portfolio-risk room. Final Risk Gate remains authoritative for open-position count, daily loss, per-trade and portfolio rules.
- Futures risk popup labels entry-to-stop risk correctly instead of calling it a percentage stop rule.

## Release discipline
- `ACTIVE_RELEASE_CHECKLIST.md` is the mandatory active checklist for every supplied build.
- `qa/verify_v5_04_ltp_risk_release_gate.py` covers the two v5.04 repairs.
- `qa/run_active_release_gate.py` runs the current mandatory automated gates.
- Actual broker-session freshness is explicitly a runtime gate; it is never claimed from an offline synthetic test.

## Retained
- v5.03 MCX Futures signal decoupling / FUTURES-ONLY fallback.
- Profitability Policy v2: OFF / ADVISORY / BALANCED / STRICT / AUTO.
- Full MCX universe; NSE + MCX dual-provider core.
- Live Execution LOCKED; Stage 8 absent.

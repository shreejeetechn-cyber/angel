# WINGO v4.5.2 Web Application Guide

## Control policy
Only one interactive control surface is authoritative at a time:
- `DESKTOP`
- `WEB`
- `NONE`

The Unified Core remains the single owner of broker feeds, scanner, signals, profitability, paper state, scheduled entries, risk, settings and diagnostics.

## Web behavior
- Browser-native routes such as `/dashboard`, `/signals`, `/profitability`, `/scheduled`, `/paper`, `/diagnostics`, `/settings`.
- Browser Back/Forward and direct URL refresh are supported.
- WebSocket updates Core/provider/scanner status without reloading the Core.
- Browser refresh/close does not stop broker feeds or scanner.
- Responsive layout uses CSS Grid/Flex; the old Desktop-coordinate scaled canvas is not the primary Web layout.
- Native Core endpoints are used where available. Remaining pages use a bounded compatibility adapter without Desktop pixel geometry.

## Switching
### Desktop → Web
Open the Web app, log in, then choose **Switch control to Web**. Desktop is hidden and its expensive presentation rendering is suspended.

### Web → Desktop
Use **Switch to Desktop** or run `START_WINGO.bat`. The Web UI becomes non-authoritative and Desktop performs one deferred repaint/AutoFit.

## Profitability
Automatic second-monitor Profitability pop-out is disabled in v4.5.2. The setting is forced OFF and disabled. Manual Pop Out remains available.

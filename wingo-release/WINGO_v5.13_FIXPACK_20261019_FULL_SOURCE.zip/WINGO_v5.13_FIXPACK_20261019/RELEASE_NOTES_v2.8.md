# WINGO v2.8 — Compact Trading Terminal

- Removed the large Filter/Regime blank band.
- Filter + regime now live in Top Opportunities header.
- Top Opportunities reduced to decision columns for 8–10 visible rows.
- Summary cards include compact percentages.
- Breadth legend fits all three rows without scrolling.
- Alerts panel syncs with signals when alert aggregation is empty.
- Heatmap has an Oversold/Overbought scale.
- Index Trend shows full names, LTP, daily change %, trend.
- Paper labels Open Positions vs Closed Trades; no-trade Win Rate is dash.
- Sidebar compact markers are monochrome/font-safe.
- Footer is slimmer and market-closed freshness is neutral.
- Realtime scan/dashboard logic is preserved.
- Execution remains locked.

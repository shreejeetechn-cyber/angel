@echo off
rem WINGO v5.13 starts or attaches the Desktop client to the singleton Unified Core runtime.
setlocal EnableExtensions
title WINGO v5.13 Unified Core - Desktop

cd /d "%~dp0"

set "SEARCH=%CD%"
set "WINGO_ROOT="

:find_root
for %%I in ("%SEARCH%") do set "NAME=%%~nxI"
if /I "%NAME%"=="Wingo" (
    set "WINGO_ROOT=%SEARCH%"
    goto root_found
)

for %%I in ("%SEARCH%\..") do set "NEXT=%%~fI"
if /I "%NEXT%"=="%SEARCH%" goto root_fallback
set "SEARCH=%NEXT%"
goto find_root

:root_fallback
for %%I in ("%CD%\..") do set "WINGO_ROOT=%%~fI"

:root_found
set "PY=%WINGO_ROOT%\.venv\Scripts\python.exe"
set "ENVFILE=%WINGO_ROOT%\.env"

echo.
echo ============================================
echo          WINGO PRODUCTION LAUNCHER
echo ============================================
echo Build: WINGO v5.13 Auto Update Bootstrap + Canonical Incremental State (Live Execution Locked)
echo Root : %WINGO_ROOT%
echo.

if not exist "%PY%" (
    echo [ERROR] Common virtual environment Python not found:
    echo %PY%
    echo.
    echo Expected shared environment:
    echo %WINGO_ROOT%\.venv
    pause
    exit /b 1
)

if not exist "%ENVFILE%" (
    echo [ERROR] Common .env not found:
    echo %ENVFILE%
    pause
    exit /b 1
)

rem Robust Python version check:
rem Do NOT use FOR /F around a quoted executable path; it breaks on some
rem Windows/OneDrive paths because cmd.exe re-parses nested quotes.
"%PY%" -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 12)"
if errorlevel 1 (
    echo [ERROR] WINGO requires Python 3.12 in the shared .venv.
    echo.
    "%PY%" --version
    pause
    exit /b 1
)

echo [OK] Python 3.12
echo [OK] Common .env found
echo [OK] Shared .venv found

rem A shared .venv may exist while one or more GUI/runtime packages are
rem missing or pinned to a different version. Validate the complete file, then
rem repair the same environment once before refusing to launch.
"%PY%" "%CD%\app\core\dependency_check.py" "%CD%\requirements.txt"
if errorlevel 1 (
    echo [SETUP] Missing/outdated WINGO dependencies - repairing shared .venv...
    "%PY%" -m pip install --disable-pip-version-check -r "%CD%\requirements.txt"
    if errorlevel 1 (
        echo [ERROR] Full dependency repair failed.
        echo Check internet access, requirements.txt, and pip in the shared .venv.
        pause
        exit /b 1
    )
    "%PY%" "%CD%\app\core\dependency_check.py" "%CD%\requirements.txt"
    if errorlevel 1 (
        echo [ERROR] Dependency verification still fails after repair.
        pause
        exit /b 1
    )
)

rem v3.1.0 adds the official Upstox Python SDK. Keep the single shared .venv;
rem install only this missing dependency automatically, never create another venv.
"%PY%" -c "import upstox_client" >nul 2>nul
if errorlevel 1 (
    echo [SETUP] Upstox SDK missing - installing into shared .venv...
    "%PY%" -m pip install --disable-pip-version-check "upstox-python-sdk==2.28.0"
    if errorlevel 1 (
        echo [ERROR] Could not install upstox-python-sdk==2.28.0
        echo Check internet access and pip in the shared .venv.
        pause
        exit /b 1
    )
) else (
    echo [OK] Upstox SDK available
)

rem v3.7.24 retains the pinned FYERS SDK 3.1.16. Existing shared .venv installs may still
rem contain 3.1.15, so verify the exact package version before launch.
"%PY%" -c "import importlib.metadata as m,sys; raise SystemExit(0 if m.version('fyers-apiv3') == '3.1.16' else 16)" >nul 2>nul
if errorlevel 1 (
    echo [SETUP] FYERS SDK missing/outdated - installing fyers-apiv3==3.1.16...
    "%PY%" -m pip install --disable-pip-version-check "fyers-apiv3==3.1.16"
    if errorlevel 1 (
        echo [ERROR] Could not install fyers-apiv3==3.1.16
        echo Check internet access and pip in the shared .venv.
        pause
        exit /b 1
    )
) else (
    echo [OK] FYERS SDK 3.1.16
)

echo.
echo Ensuring singleton WINGO Core and opening Desktop client...
echo.

"%PY%" -m app.core.unified_launcher --desktop --autofit

if errorlevel 1 (
    echo.
    echo [ERROR] WINGO exited with an error.
    echo Check:
    echo %WINGO_ROOT%\.wingo_state\logs\wingo.log
    echo Crash/Hang reports:
    echo %WINGO_ROOT%\.wingo_state\crashes
    pause
    exit /b 1
)

endlocal

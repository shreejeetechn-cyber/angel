# WINGO v2.8.15 — AI-Readable Diagnostics Export

## Settings switch

Settings now includes **Enable AI-Readable Log Export**. It defaults OFF and is persisted in `.wingo_state/settings.json`.

When ON, the Session Audit & Logs page enables **Export AI Diagnostics**.

## Export format and limits

The export is one plain UTF-8 `.txt` file designed for reliable upload and incremental AI/file-reader inspection.

Hard caps:
- report: maximum 8,000 lines
- report: maximum 2.5 MB
- application log tail: maximum 3,500 lines
- current session events: maximum 2,000 events
- scanner errors: maximum 200 rows
- scanner diagnostic sample: maximum 25 rows
- recent Futures snapshots: maximum 12 rows
- recent signals: maximum 30 rows

If a cap is reached the report explicitly marks itself truncated rather than growing without bound.

## Included diagnostics

- current Session Health summary
- deduplicated Error/Warning signatures
- latest session problems
- task duration aggregates and slowest tasks
- persistent Scanner baseline/runtime/checkpoint metadata
- bounded scanner errors/sample rows
- true Market Breadth snapshot
- bounded recent Futures snapshot state
- bounded recent Signals and open Paper positions
- bounded current-session JSONL events
- bounded rotating `wingo.log` tail

## Privacy and security

The export deliberately excludes `.env` and never intentionally exports raw access tokens, refresh tokens, auth codes, passwords, PIN/TOTP, API keys or client secrets. It applies an additional text/object redaction pass for credential-like values, Bearer tokens, JWT-looking values and unusually long token-like strings.

## Performance hardening

Session summary files are now written at most once per second. `record=False` state transitions no longer trigger persistent summary writes. This prevents rapidly changing feed detail from creating avoidable disk-write pressure while preserving immediate recorded error/state events in the session JSONL.

Real execution remains locked.

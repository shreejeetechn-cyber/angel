# WINGO v3.6.3 — Global Responsive UI Scale

This is a UI/presentation hardening release on top of **v3.6.2 Roadmap Stability Hotfix**. It remains inside the existing v3.6 Profitability Lab development phase. It does **not** change RSI/lifecycle, VWAP, OI, E-CVD, depth intelligence, profitability scoring, strategy selection, OOS validation, paper-automation rules, provider behavior, or live-execution policy.

## Application-wide screen adjustment

- One central `UiScaleManager` is installed at `QApplication` level rather than duplicating zoom code page-by-page.
- **Ctrl + Mouse Wheel** adjusts UI density from **80% / 90% / 100% / 110% / 120% / 130%**.
- **Ctrl + +** and **Ctrl + -** use the same global scale steps.
- **Ctrl + 0** resets to 100%.
- Main footer shows the active `ZOOM n%`; clicking it resets to 100%.
- Scale applies to Dashboard, Scanner, Divergence, Profitability Lab, Futures, Option Chain, Signals, Backtest, Paper, Diagnostics, Acceptance, Automation, Intelligence, Risk, Validation, Execution, Watchlist, Logs, Settings and detached/pop-out windows.
- Selected QSS presentation measurements, layout margins/spacing, table row density and control icons are scaled; colours, market data and calculation cadence are untouched.
- Runtime `setStyleSheet()` colour/status changes are re-scaled asynchronously so live status updates do not silently revert the user's zoom.
- Scale persistence is debounced (450 ms), keeping disk/OneDrive I/O out of rapid wheel events.

## Screen-fit behavior

- A saved zoom always wins.
- On first run without a saved zoom, smaller screens use a conservative 90% density.
- Normal top-level WINGO windows are constrained to the current screen's `availableGeometry()` instead of opening larger than the usable desktop.
- Qt remains responsible for physical high-DPI scaling; WINGO's percentage is an additional user-controlled information-density layer.

## Profitability Lab resizable blocks

- Existing Matrix/Details vertical splitter remains draggable and is now non-collapsible.
- RSI Intelligence, Market & Sector Context and Derivatives Context are changed from a fixed three-column grid to a native horizontal `QSplitter`.
- Each intelligence block can be resized independently with the mouse.
- Splitter sizes persist across restarts.
- Splitter persistence is debounced (500 ms); dragging never writes settings on every mouse movement.
- Resizing panels does not trigger RSI/VWAP/CVD/score recalculation.

## Safety continuity

- v3.6.2 unsafe custom Qt sorter remains removed.
- v3.6.2 blank detail-panel sequencing fix remains active.
- v3.6.2 runtime-path cache and FYERS subscription-churn fix remain active.
- v3.6.1 Crash/Hang Shield remains active.
- Live execution remains **LOCKED**.
- Application source contains no broker `.place_order()` call.

## Verification limitation

The Linux/headless QA environment can compile and source/regression-test the PySide integration contracts but cannot reproduce the user's actual Windows desktop, monitor DPI, authenticated FYERS/Upstox sessions or physical mouse-wheel behavior. The package therefore still requires a short on-machine Windows visual acceptance run at 80/100/130% on the user's monitors.

# WINGO v2.8.17 — Unified FYERS WebSocket + Paper Feed Reliability

Build: **WINGO v2.8.17 Unified FYERS WebSocket + Paper Feed Reliability (Execution Locked)**

## Why this release
The v2.8.16 AI diagnostics showed that the Paper mark guard was correctly blocking impossible spread P&L, but the upstream Paper transport could become partially synchronized (`target=6`, `subscribed=3`) and still report itself as already synchronized. The user also confirmed that manually disconnecting and reconnecting the FYERS WebSocket restored smooth operation. FYERS guidance supplied by the user recommends a single WebSocket instance and full unsubscribe/resubscribe when changing the symbol list.

## One FYERS market-data socket
- Retired the dedicated `PaperOptionLiveFeed` transport. It is no longer imported or instantiated by `MainWindow`; its legacy class now raises if accidentally used.
- Main Live Feed, Paper legs, active signals, near futures, option workspace/contracts and core indices share one `FyersLiveFeed`.
- No second FYERS market-data socket is created for Paper trading.

## Full-set subscription replacement
- Dynamic symbol changes now use: **unsubscribe current complete set -> subscribe latest complete set**.
- Provider unsubscribe acknowledgement is recognized separately from subscribe acknowledgement.
- A bounded 1.25-second unsubscribe-ACK fallback prevents the socket from remaining permanently half-synchronized if that control ACK is absent.
- Desired-set changes that arrive during an in-progress subscription cycle are retained and applied after the current acknowledgement.
- A partial active set is never treated as synchronized merely because the desired set text is unchanged.
- Manual Paper sync forces a full resubscribe on the same socket.

## Reconnect lifecycle
- `reconnect=True` remains enabled.
- WINGO requests `reconnect_retry=10` (with compatibility fallback if an older SDK signature lacks the keyword).
- On transport close/reconnect, active/pending subscription state is cleared and the latest full desired set is resubscribed on reconnect.
- Paper leg freshness is reset on reconnect/full-resubscribe; old marks cannot make the transport appear ready.

## Paper transport integrity
- Open Paper strategy legs are P1 subscription symbols, ahead of scanner/watchlist contexts.
- The WINGO soft cap starts at 50 but expands to reserve all open Paper legs plus 50 additional slots, bounded by the provider ceiling.
- Paper health is now logical over the unified socket: `OFFLINE`, `SYNCING`, `SUBSCRIBED`, `READY`, `RECONNECTING`.
- `paper_subscribed_symbols` comes from the unified socket's provider-acknowledged active set; fresh-leg status is tracked separately.
- `READY` requires fresh post-resubscribe ticks for all required Paper legs.
- Auto exit has an additional per-position transport gate before the existing `WAITING_LEGS / STALE_LEG_MARKS / OUT_OF_BOUNDS / READY` P&L guard.
- A 2-second local housekeeping check expires old fresh-leg state without making network requests.

## Diagnostics
The persisted live-subscription plan now includes:
- `transport_topology: ONE_FYERS_DATA_SOCKET`
- adaptive WINGO soft cap
- FYERS provider subscription-limit reference
- current active unified symbols
- Paper target/subscribed/fresh symbol sets
- Paper logical state

## Preserved behavior
- Futures `360ONE` symbol-integrity fix remains intact.
- True 208-stock Advance/Decline and regime quality gates remain intact.
- FYERS Option Chain v3 nested Greeks/IV handling remains intact.
- Multi-leg impossible-P&L quarantine remains intact.
- Dhan remains parked.
- Real execution remains locked.
- Requirements and shared root `.venv` remain unchanged.

## Verification boundary
Whole-project compile/static/synthetic tests are included in the v2.8.17 QA report. Actual Windows PySide6 rendering and live FYERS WebSocket behavior cannot be executed in the build container; final provider acceptance remains on the user's Windows session.

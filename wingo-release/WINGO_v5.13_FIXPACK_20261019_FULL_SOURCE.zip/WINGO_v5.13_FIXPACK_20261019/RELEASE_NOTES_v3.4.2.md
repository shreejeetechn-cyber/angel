# WINGO v3.4.2 - Profitability Data Matrix Mockup Parity

- Consolidated the Mode 2 numerical workflow on one resizable screen.
- Added NIFTY 50, BANKNIFTY, INDIA VIX, breadth, aggregate evidence coverage
  and live data-age cards.
- Added provider status and live clock in the Profitability Data Matrix header.
- Added same-screen RSI Intelligence, Market & Sector Context and Derivatives
  Context panels for the selected script.
- Bridged provider-derived Futures OI/buildup and normalized option-chain PCR,
  ATM IV, bid-ask spread and liquidity into the Lab per underlying.
- Missing derivatives fields remain `N/A`; the UI explicitly states that
  unavailable OI, PCR or IV is never fabricated.
- Added a prominent Long/Short/Grade/Bias/Strategy decision strip and numbered
  human-readable evidence reasons.
- Added selected-script Shadow preview with baseline bias, panel decision,
  Long/Short scores, MFE, MAE and lot-aware hypothetical net P&L.
- Kept all six detailed tabs, multi-monitor pop-out, v3.4.1 full auto-run,
  BSE exclusion and live broker execution lock.

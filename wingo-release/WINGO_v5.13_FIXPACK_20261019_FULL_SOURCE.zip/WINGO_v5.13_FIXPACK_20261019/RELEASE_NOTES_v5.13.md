# WINGO 5.13 — Auto Update Bootstrap + Canonical Incremental State

## Purpose

WINGO 5.13 is the one-time full bootstrap release for the signed client auto-update system. It retains the v5.12 canonical incremental/table-stability logic and keeps live broker execution locked.

## Client update experience

- Background update check does not block WINGO startup.
- Dashboard shows a non-blocking update banner when a compatible update exists.
- Banner controls: **UPDATE NOW**, **LATER**, **RELEASE NOTES**.
- Settings → Updates provides current version/status, source selection, Future Update Folder, HTTPS manifest URL, check interval, **CHECK AGAIN**, and **INSTALL OFFLINE UPDATE**.
- Mandatory updates disable deferral.

## Update sources

WINGO supports:

1. production HTTPS `latest.json` + `.wupd`;
2. assigned local/LAN Future Update Folder;
3. manually selected signed `.wupd` for air-gapped/offline clients.

The default local discovery folder is `C:\ProgramData\WINGO\Updates\Available`. Client working state/downloads use the signed-in user's local application data so normal update checks/downloads do not require administrator write access.

## Cryptographic and compatibility gates

Every update requires:

- product = WINGO;
- patch type = `INSTALLED_UPDATE`;
- exact compatible base version;
- target version newer than installed version;
- expected package size;
- package SHA-256;
- dedicated Ed25519 update signature;
- safe payload paths;
- immutable signing/public-key policy;
- per-file payload SHA-256 verification.

Local/LAN packages are not trusted merely because they are local.

## Transactional installation

`WINGOUpdater.exe` is built as a separate helper. WINGO copies the installed updater to detached user update storage before launch so Windows file locking cannot prevent the installed updater itself from being replaced by a future update.

Transaction sequence:

`VERIFY → WAIT FOR WINGO EXIT → RECOVER PRIOR INCOMPLETE TRANSACTION → FREE-SPACE PRECHECK → STAGE → BACKUP → APPLY → FINAL VERIFY → COMMIT → RELAUNCH`

If apply/final verification fails:

`ROLLBACK → VERIFY RESTORE → record result → relaunch previous WINGO`

Interrupted `APPLY_STARTED` transactions are recovered from the persisted journal before a new update begins.

## Master/Admin release side

Universal Toolbox v2.3.0 adds **CLIENT UPDATE**:

- OLD compiled production runtime;
- NEW compiled production runtime;
- exact base and target versions;
- dedicated update signing private key;
- `.wupd` creation;
- signed `latest.json` generation;
- optional package URL;
- package-first / `latest.json`-last atomic folder publication.

The Toolbox validates runtime version markers and verifies that OLD/NEW runtimes carry the public key matching the selected signing private key before creating a package.

## Windows commercial packaging

The v5.13 Windows build pipeline now builds and includes `WINGOUpdater.exe`, pins `assets/update_public_key.pem`, updates Windows/Inno version metadata to 5.13, and generates `WINGO_v5.13_Setup.exe` / `WINGO_v5.13_PORTABLE.zip`.

## Safety

- Live broker execution remains **LOCKED**.
- Client update code does not place broker orders or create Paper Engine positions.
- Customer/runtime data is excluded from normal update payloads.
- License-signing and update-signing private keys are never included in the WINGO client build.

# WINGO Web Phase 6 — Full Desktop Parity

1. Extract under `C:\Wingo`.
2. Keep the shared `C:\Wingo\.venv` and `C:\Wingo\.env` contracts.
3. Start `START_WINGO.bat` first. Desktop WINGO remains the engine owner.
4. Start `START_WINGO_WEB.bat`.
5. Sign in at `http://127.0.0.1:8787/`.
6. Use the 32-page browser sidebar. Selecting a Web page switches the same Desktop page and returns a bounded mirror snapshot.
7. On Live Feed, `Connect Live Feed`, `Disconnect`, and `Reconnect` operate the Desktop feed engine.
8. Authentication secrets entered through mirrored sensitive fields use the memory-only localhost secret bridge; they are not stored in Web command files.
9. Live execution remains locked; Stage 8 is absent.

If the Desktop heartbeat is offline/stale, Web controls are disabled by the API and the retained snapshot is reference-only.

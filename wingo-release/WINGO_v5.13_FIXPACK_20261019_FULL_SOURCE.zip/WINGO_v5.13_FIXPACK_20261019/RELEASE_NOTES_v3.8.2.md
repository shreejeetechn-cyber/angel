# WINGO v3.8.2 risk_table_hotfix

Scope: NSE F&O Paper/Shadow only. Live execution remains locked.

## Risk repairs

- Retains the v3.8.1 independent expiry-payoff calculation for debit spreads,
  credit spreads and iron condors.
- Futures risk now uses `abs(entry price - actual stop price) * total units`.
- Futures Paper entry is explicitly blocked with `STOP_DATA_MISSING` when the
  signal does not contain a valid stop price; no full-price percentage fallback
  is used.
- Futures Paper positions persist their exact stop and target prices, and Auto
  Exit compares the live futures price directly with those levels.

## Universal table repair

- A dedicated 31px toolbar band is reserved above every managed table header.
- A-/A+, Focus/Maximize and Table Tools no longer share header geometry.
- Narrow tables use compact mode: Table Tools remains visible and contains the
  font and full-screen actions.
- Diagnostics includes `Table Header Clearance`, a geometry-based overlap test.
- Paper UI self-test now expects all five actual Paper tabs.

## Verification

`python qa/verify_v3_8_2_risk_table_hotfix.py`


# WINGO v5.05 — MCX Contract Economics + Margin + Fresh LTP

## Repairs
- Separates broker lot size from economic/priced quantity using provider `qty_multiplier`.
- MCX lot-size mismatch between FYERS and Upstox marks contract economics unverified and blocks Paper eligibility.
- Futures notional, stop risk, costs and Paper P&L sizing use economic quantity per lot.
- Provider quote timestamp is preserved; stale/unknown Futures quotes cannot create a new Futures signal.
- Upstox stale websocket recovery escalates from three resubscribe attempts to a fresh websocket worker while retaining the validated daily token.
- Broker margin authority queries Upstox/FYERS in background Auto Strategy work. Confirmed margins are never averaged; conservative maximum is used.
- If broker margin cannot be confirmed, WINGO reserves 100% one-lot notional and marks `MARGIN_UNVERIFIED`.
- Risk-based Paper sizing is capped by both buffered risk room and available-cash/margin room.
- AI diagnostics export MCX contract-economics, quote freshness, lot consensus, notional and margin fields.

## Safety retained
- Live Execution LOCKED.
- Stage 8 absent.
- Profitability Policy v2 retained.
- Daily manual broker 2FA retained; WINGO does not store OTP/TOTP/PIN/password.

# WINGO v3.1.1 — Centralized Credentials Hardening

Build: `WINGO v3.1.1 Centralized Credentials Hardening (Execution Locked)`

## Central credential policy

- The only supported credential file is `<Wingo root>\.env`.
- The application no longer falls back to a build-local `.env`.
- `setup_common_venv.ps1` creates the central file from `.env.example` only
  when the central file is missing; it never imports a project-local `.env`.
- `START_WINGO.bat`, `run_wingo.bat`, and `run_wingo.ps1` require the central
  file and show its resolved path when it is missing.
- Generated FYERS, Upstox, and Dhan tokens continue to be written only to the
  central file.
- `.gitignore` prevents accidental inclusion of real `.env` files and local
  runtime state in source-control/build workflows.

## Intended Windows location

```text
C:\Users\surya\OneDrive\Desktop\Shoonya_OI_Tracker\Wingo\.env
```

Extract this build into a separate child folder under `Wingo`. Keep the common
`.env` and `.venv` beside that child folder, never inside it.

## Safety

- No real credential values are included in this package.
- `.env.example` contains names and empty placeholders only.
- Real order execution remains locked.

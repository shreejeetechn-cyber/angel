# WINGO v4.3.6 — Web Phase 5 Operational Workspace Guide

## Scope
Web Phase 5 extends the authenticated localhost browser from the Phase 1–4 foundation with three read-only operational workspaces:

- **Profitability Lab** — bounded matrix projection, score/bias/grade/acceptance, CVD/VWAP/MTF context, strategy/lifecycle and reconciliation fields.
- **Paper & P&L** — paper-engine summary, account balances, profitability statistics, positions and ledger projection.
- **Session Health & Alerts** — session component state/result/detail plus active operator alerts.

The browser does **not** create, modify, close or execute positions. Broker order submission, broker credentials and Stage 8 execution controls are not exposed.

## Start order
1. Start desktop WINGO with `START_WINGO.bat`.
2. Start the authenticated localhost dashboard with `START_WINGO_WEB.bat`.
3. Open `http://127.0.0.1:8787/` and log in.

Shared runtime contracts remain:
- Python: `C:\Wingo\.venv\Scripts\python.exe`
- Environment: `C:\Wingo\.env`
- State: `C:\Wingo\.wingo_state`

## Authentication
Phase 4 authentication is retained: HttpOnly SameSite=Strict session cookie, CSRF protection, session expiry, login rate limiting and Logout.

Logout ends only the Web session. It does not stop desktop WINGO and does not log out FYERS/Upstox.

## Operational snapshot model
Desktop WINGO publishes a sanitized Phase-5 snapshot at a bounded cadence of approximately 5 seconds. The Web process reads the snapshot from the shared state directory and reports:

- `READY` — desktop heartbeat online and snapshot fresh.
- `STALE` — desktop online but operational snapshot too old.
- `OFFLINE` — desktop heartbeat offline; retained data is reference-only.
- `MISSING` — desktop has not published a Phase-5 snapshot yet.

Snapshot contents are bounded and secret-like keys/values are redacted before they reach the browser.

## Profitability refresh contract
Phase 5 does **not** change the Profitability page refresh policy. The desktop configuration remains authoritative:

- Manual refresh mode stays manual.
- The custom manual cadence remains 5 minutes unless the operator changes it.
- Background Profitability/CVD analytics continue independently as implemented by the v4.3.3 runtime-stability architecture.
- The Web workspace is a projection of the latest calculated desktop state, not a second analytics engine.

## Existing safe controls retained
Phase 3 safe control actions remain available after authentication and desktop-online validation: Full Scan, Incremental Scan, Stop Scan, Profitability Refresh, Market Breadth Refresh, Signals Refresh and Scheduled Entries Refresh.

Commands expire after 5 minutes. No order/execution action exists in the allow-list.

## Safety boundary
- Stage 8 execution engine: **NOT PRESENT**
- Live execution: **LOCKED**
- Browser broker-order entry: **NOT AVAILABLE**
- Browser Paper-position mutation: **NOT AVAILABLE**
- Broker secrets in operational snapshot: **NOT EXPOSED**

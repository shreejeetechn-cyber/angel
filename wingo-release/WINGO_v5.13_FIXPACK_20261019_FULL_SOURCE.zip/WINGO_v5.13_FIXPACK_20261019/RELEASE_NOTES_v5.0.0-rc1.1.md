# WINGO v5.0.0-rc1.1 — Full MCX Scanner Universe Restoration

This hotfix removes the rc1 hard-coded MCX four-symbol autonomous universe.

## Changed
- MCX Scanner now uses the full active MCX near-future universe from the instrument master.
- Removed the hidden GOLD/SILVER/CRUDEOIL/NATURALGAS allowlist from automatic Paper admission.
- Removed the same four-symbol filter from MCX Profitability Evidence.
- Acceptance now checks the full-master policy rather than enforcing a four-symbol production subset.

## Retained
- Canonical FUTURE/OPTION model and FUTURE_PROXY references.
- FYERS + Upstox MCX provider/adapters.
- Immutable Paper exchange ownership and cross-exchange mark protection.
- MCX-specific trading-cost routing.
- Exchange-generation tick/router reset.
- Exchange-isolated signal/session storage.
- Contract/session/expiry safety policy.
- Live Execution LOCKED; Stage 8 absent.

Known data gaps such as insufficient historical candles for newly introduced contracts are reported by the scanner rather than suppressed by a hidden universe restriction.

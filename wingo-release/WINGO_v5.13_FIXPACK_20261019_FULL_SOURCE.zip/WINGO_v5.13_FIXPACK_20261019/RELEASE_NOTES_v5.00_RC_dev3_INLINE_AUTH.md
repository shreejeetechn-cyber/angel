# WINGO v5.00 RC dev3 — Inline Daily Authentication Integration

Authentication-only integration on top of the verified RC dev3 Full MCX Universe build. Runtime identity and trading/scanner logic are unchanged.

- Authentication page reduced to a compact three-line FYERS + Upstox daily-login surface.
- FYERS and Upstox official broker login pages open inside the WINGO Authentication page using Qt WebEngine; no separate browser window is required by the WINGO action.
- OTP/TOTP/PIN are entered only into the broker-hosted page. WINGO provides no visible OTP/TOTP/PIN/auth-code input and never persists authorization codes.
- Existing centralized `<Wingo root>/.env` remains the single credential/token store.
- Fresh FYERS and Upstox OAuth tokens are provider-profile validated before replacing the saved token.
- Validated FYERS ID and Upstox UCC are remembered as `FYERS_USER_ID` and `UPSTOX_UCC`.
- Successful Upstox OAuth login writes `UPSTOX_TOKEN_MODE=DAILY`. A stored Analytics token is preserved in `.env` but is not used as an authentication bypass; the integrated Upstox path always requires the daily OAuth token produced by manual broker 2FA.
- Existing feed, scanner, MCX universe, Profitability, Stage 0-7, Paper and Live Execution lock logic are untouched.

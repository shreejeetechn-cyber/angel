# WINGO v3.7.6 Release Notes

## Compact Dashboard + Readability

- Dashboard top market/header area is compressed to a single horizontal strip at normal desktop widths.
- NIFTY 50, BANKNIFTY, INDIA VIX, market/provider/update status and provider checks share the compact header line.
- Header height is bounded to 48 px; index sparklines reduced from 82x24 to 54x18.
- Dashboard-local Arial font is used for compact operational text without changing the global QApplication font.
- Small dashboard labels/status text use 11 px Arial for improved readability.
- TOTAL F&O through TOTAL P&L summary cards use an 8-column single row at normal desktop content widths (>=1080 px).
- Summary cards are reduced to a 48-56 px height budget; narrow windows fall back to 4 or 2 columns instead of shrinking text.
- Dashboard opportunity table/header uses Arial 11 px.

## Preserved v3.7.5 behavior

- NIFTYFPI insufficient history remains BLOCKED / INSUFFICIENT_HISTORY rather than ERROR.
- FYERS -300 symbol isolation, network/transport classification and reconnect protections remain intact.
- FYERS depth payload self-test and documented depth-field normalization remain intact.
- BANKNIFTY freshness/NO TICK handling and Regime freshness guards remain intact.
- Real broker execution remains locked; app source contains zero `.place_order()` calls.

## Verification

- 25/25 QA suites PASS.
- 644 PASS checks emitted.
- 141 Python files compile cleanly.
- Final ZIP fresh re-extraction passes targeted v3.7.6 QA, full Python compilation and execution-lock scan.

## Runtime note

Final pixel-level Windows/DPI/font visual acceptance still requires the normal on-machine run. Arial is standard on supported Windows systems; Qt will use its platform font fallback if unavailable.

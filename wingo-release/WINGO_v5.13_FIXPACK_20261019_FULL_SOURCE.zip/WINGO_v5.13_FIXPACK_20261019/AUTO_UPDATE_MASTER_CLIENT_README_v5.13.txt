WINGO v5.13 MASTER -> CLIENT UPDATE FLOW
========================================

MASTER / ADMIN PC
-----------------
Full OLD production runtime
        +
Full NEW production runtime
        |
        v
Universal Toolbox v2.3.0 -> CLIENT UPDATE
        |
        +-- validates OLD/NEW wingo.install.json versions
        +-- validates update public key matches Master signing private key
        +-- compares runtime files
        +-- excludes mutable/customer/private-key paths
        +-- creates signed WINGO_<base>_to_<target>.wupd
        +-- creates signed latest.json
        |
        v
PUBLISH PACKAGE FIRST
        |
VERIFY COPIED/UPLOADED PACKAGE
        |
PUBLISH latest.json LAST
        |
        +------------------------------+
        |                              |
        v                              v
HTTPS UPDATE SERVER            FUTURE UPDATE FOLDER
                               local or LAN/UNC
        |                              |
        +--------------+---------------+
                       |
                       v
CLIENT WINGO
-----------
WINGO starts normally
  -> background manifest/folder check
  -> newer exact-base update found
  -> UPDATE AVAILABLE banner
  -> [UPDATE NOW] [LATER] [RELEASE NOTES]
  -> UPDATE NOW copies/downloads package locally
  -> size + SHA256 + Ed25519 signature + exact versions verified
  -> detached WINGOUpdater helper launched
  -> WINGO exits safely
  -> prior incomplete update recovery if required
  -> free-space precheck
  -> stage + backup + journal
  -> apply changed/new/deleted application files
  -> final per-file hashes + wingo.install.json target version
  -> COMMIT or automatic ROLLBACK
  -> WINGO relaunches

AIR-GAPPED CLIENT
-----------------
Settings -> Updates -> INSTALL OFFLINE UPDATE -> select signed .wupd
The same SHA256/signature/base-version/payload rules apply.

LOCALHOST RULE
--------------
localhost always means the SAME PC. If Master and Client are different PCs, use
an assigned UNC/LAN path such as \\WINGO-MASTER\Updates or a configured LAN server.

KEY RULE
--------
Client: public verification key only.
Master: private update signing key. MASTER ONLY. NEVER distribute to clients.

# WINGO v3.3.0 - Isolated Profitability Lab

## Added

- Isolated `app/features/profitability_lab/` package.
- Data-first live matrix with sortable/filterable/hideable tables.
- Selected-script numerical details and lightweight RSI graphical view.
- Detachable multi-monitor window with persistent geometry.
- RSI-on-RSI, session VWAP, Estimated CVD, depth imbalance, sector context,
  profitability scoring and shadow validation engines.
- Central `WINGO_PROFITABILITY_LAB` feature flag, default enabled.
- Separate persistent state under `.wingo_state/profitability_lab/`.

## Provider integration

- FYERS SymbolUpdate normalization now retains LTQ, bid/ask, ATP, VTT, OI
  and total buy/sell quantity.
- FYERS standard DepthUpdate subscribes only to a bounded shortlist and
  reports actual received levels rather than assuming deep entitlement.
- Upstox Full normalization retains LTQ, five-level bid/ask depth, ATP, VTT,
  OI and total quantities where present.
- Trade and depth evidence remains provider-consistent. Quote/tick classified
  flow is always labelled Estimated CVD.

## Safety

- No new broker order submission path.
- Feature import, controller and page failures are isolated from MainWindow.
- BSE universe remains excluded.
- A score is research output, not a profitability guarantee.
- Shadow results include configured round-trip cost before validation metrics.

## Upgrade behavior

- A fresh RSI scanner run stores a bounded daily RSI series used by the new
  RSI-on-RSI calculations. Older restored snapshots remain readable and show
  lower confirmation coverage until refreshed.
- Existing `.env`, paper ledger, signals and table layouts are preserved.


# WINGO v4.2.1 — Scheduled Entries

This release assigns the dedicated Scheduled Entries amendment its correct
v4.2.1 identity. Runtime, launchers, README, version marker, root folder and ZIP
filename all identify v4.2.1.

New in v4.2.1:

- Adds `Paper Trading -> Scheduled Entries` as a dedicated read-only tab.
- Consolidates pre-calculation decision, final executable reprice, passive
  entry wait, trigger limits, validity window, expected net ₹/lot, terminal
  result and resulting Paper position ID.
- Provides `ALL`, `WAITING / READY`, `FILLED` and `FAILED` filters with summary
  counts.
- Double-click or `View Strategy / Legs` opens the linked Signal or actual
  Paper Position in Strategy / Spread Inspector.
- Embeds the final pretrade receipt into each Stage-2 ENTRY intent.
- Preserves completed Stage-2 receipts across restarts. A stale pending intent
  is archived as cancelled and is never restored as executable work.
- Keeps the tab Paper-only and read-only. No broker API, order button, automatic
  Live promotion or profit guarantee is added.

Retained from v4.2.0:

- Unified Strategy / Spread Inspector connections.
- Persistent Alert/Alarm Journal and Profitability Matrix alert status.
- Stage 0 through Stage 7 safety, evidence and reconciliation gates.
- Live Execution Locked.

Verification:

- Python parsing and compilation pass.
- Stage 0–7 regression suite passes.
- Profitability/P&L, Alert Journal and Inspector regression suites pass.
- Scheduled-entry aggregation, persistence and routing suite passes.
- ZIP integrity and internal v4.2.1 identity checks pass.

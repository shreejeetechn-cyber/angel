# WINGO v3.3.1 - Profitability Lab Startup Hotfix

## Fixed

- Removed eager Profitability Lab scanner synchronization from WINGO startup.
- Deferred the first Lab synchronization until its page is visible.
- Replaced expensive matrix/shadow `ResizeToContents` behavior with interactive
  widths.
- Added cancel-safe, chunked rendering for matrix and shadow rows.
- Prevented hidden Lab pages from creating thousands of invisible table cells.

## Safety

- Existing v3.3.0 scoring, provider, shadow-validation and BSE-exclusion
  contracts remain unchanged.
- Live broker execution remains locked.
- Central `.env`, `.venv` and `.wingo_state` remain outside the project build.

# WINGO v2.4.2 — Collapsible Sidebar

- Collapse/expand left navigation.
- Smooth 180 ms slide animation.
- Top arrow toggle.
- Ctrl+B keyboard shortcut.
- 225 px expanded / 58 px collapsed.
- Compact clickable markers remain visible.
- Hover tooltips show full menu names.
- Main workspace expands automatically.
- Sidebar state persists across restarts.
- Programmatic Dashboard navigation remains functional while collapsed.

Execution remains locked.

# WINGO v4.2.5 — Stage 0-7 Data Telemetry

This patch makes factual operational data visible across every approved roadmap stage without inventing quotes, orders, fills or P&L.

## Added
- Dedicated Stage 0 runtime ledger persisted to `.wingo_state/stage0_precalculation.json`.
- Stage 0 records auto/manual pretrade receipts, final repricing decisions, market regime, effective trend policy and auto-entry cycle outcomes.
- New **Stage Monitor 0-7** page with exactly eight always-populated rows.
- Diagnostics export includes Stage 0 precalculation/admission telemetry.
- Roadmap Closure now reads Stage 0 runtime evidence instead of always reporting acceptance-only status.
- Stage 1, 3, 4, 5, 6 and 7 tables show factual empty-state/status rows when no valid market event exists.
- Stage 3 persists `last_reason` so no-quote causes remain visible after refresh/restart.

## Safety
- STATUS ONLY / GATE LOCKED rows are telemetry, not simulated fills.
- Stage 3/4 still require full Stage-1 READY data where their roadmap contract requires it.
- Stage 5/6/7 evidence and activation gates are unchanged.
- Stage 8 execution engine remains absent.
- Live execution remains locked and external broker requests remain prohibited.

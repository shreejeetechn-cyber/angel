# WINGO v5.09.1 FIX4 - Multi-Feed Re-login + Security Hardening

This patch implements the unified FYERS/Upstox re-login critical path without changing product licensing, paper trading, profitability, or market-routing logic.

## Changes
- Provider-neutral authentication error classifier.
- Upstox automatic LOGIN REQUIRED scheduling for missing/expired/rejected daily access token.
- One automatic login prompt per provider authentication incident.
- Network, rate-limit, and stale websocket failures remain reconnect/failover events and do not force OAuth.
- FYERS SDK logs use WINGO runtime logs/fyers (LocalAppData in installed mode).
- Secret-bearing legacy .env is never copied to plaintext migration backup.
- Direct commercial-security QA launcher fixed and QA dependencies documented.
- Release gate checks package contamination before cleanup.
- Final package cache/bytecode/log cleanup and SHA-256 manifest regeneration.

See FINAL_VALIDATION_v5.09.1_FIX4.txt for exact offline PASS results and runtime-only pending checks.

# WINGO v5.01 — Profitability Policy v2 Hotfix

This is a focused v5.01 Paper/Shadow hotfix. APP_VERSION and BUILD_NAME remain v5.01. Live Execution remains locked.

## What changed

- Added a first-class Profitability Policy ON/OFF control.
- Added policy modes: ADVISORY, BALANCED, STRICT, AUTO.
- Added `Show blocked opportunities` (default ON).
- Scheduled Entries are now calculated/attached before Auto Paper admission, so profitability/promotion failure no longer makes the Scheduled Entries workspace blank.
- Scheduled rows can show CALCULATED, LOW SAMPLE, BLOCKED, FILLED and terminal states.
- AUTO profitability qualification is source-separated: MANUAL results never qualify AUTO Paper.
- Sparse AUTO evidence falls back hierarchically within AUTO-only history: exact strategy/regime/symbol → AUTO strategy/regime → AUTO strategy → AUTO source pool.
- Profitability diagnostics now separate blocking reasons from advisory reasons.
- Missing spread/depth/liquidity metadata is explicit (`*_UNKNOWN`) instead of being silently treated as the same thing as a known bad value.

## Policy semantics

- OFF: profitability thresholds are advisory/ignored for Paper admission; non-profitability safety/risk/trend/contract gates remain active.
- ADVISORY: weak profitability is shown as WARN, not hidden; non-profitability gates remain active.
- BALANCED: requires minimum sample, positive cost-adjusted edge, edge/cost floor and known-bad execution-quality failures to pass.
- STRICT: all profitability/evidence rules must pass.
- AUTO: BALANCED until the configured sample/session requirement is ready, then STRICT.

## Recommended v2 baseline

- Minimum sample: 8
- Minimum sessions: 5
- Min expected ₹/lot: 1.00 (unchanged; edge/cost remains the scalable filter)
- Min edge/cost: 1.50
- Min payoff: 1.20
- Min profit factor: 1.30
- Max spread: 2.50%
- Top candidates/cycle: 3

One-time migration raises only legacy loose sample/session/profit-factor floors and caps an overly loose spread at 2.50%. Stricter saved values are not loosened. Existing stop/target/trailing preferences are not changed.

## Safety retained

- Stage 0–7 retained.
- Stage 8 execution engine absent.
- Live Execution LOCKED.
- Inline FYERS/Upstox daily login unchanged.
- Full MCX universe unchanged.
- MainThread async persistence/stall hotfix retained.

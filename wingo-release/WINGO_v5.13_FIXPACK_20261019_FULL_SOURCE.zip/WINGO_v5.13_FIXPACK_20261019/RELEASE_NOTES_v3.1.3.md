# WINGO v3.1.3 — Provider-Aware Auto Start

Build: `WINGO v3.1.3 Provider-Aware Auto Start (Execution Locked)`

## Root causes repaired

The v3.1.2 live router supported simultaneous FYERS and Upstox sockets, but the
startup/strategy pipeline still required `daily_fyers_bootstrap_completed`.
Consequently a FYERS Health compatibility error blocked automatic feeds and
Futures/Options intelligence even when Upstox was the healthy primary.

The same scanner refactor removed private history methods still used by FYERS
Health, Advanced Validation and Backtest. Persisted canonical underlyings could
also be wrapped twice into malformed `NSE:NSE:...-EQ-EQ` subscriptions.

## Implementation

- Added a tested provider-startup decision policy for primary/failover health.
- Automatic startup opens only validated provider feeds; one provider failure
  no longer blocks a healthy configured driver.
- Added automatic pre-open-to-open transition handling at 09:15.
- Daily baseline restore/full scan and Futures + Options strategy analysis now
  depend on provider readiness rather than FYERS-only completion.
- Futures Master completion is a prerequisite for combined auto strategy
  analysis and automatically resumes the queued workflow.
- Fixed FYERS full health to validate explicit FYERS long history.
- Added public whole-provider `history` and `history_range` APIs.
- Backtest cache stores provider provenance and prevents cross-provider merging.
- Advanced Validation migrated off removed private scanner methods.
- Normalized duplicate exchange/equity wrappers and known watchlist aliases.
- Added token-refresh socket restart and provider-startup telemetry.

## Safety boundary

- Historical candles from different providers are never mixed in one symbol or
  backtest cache series.
- Market intelligence remains read-only/paper-capable.
- Real broker execution remains locked.
- No credentials are included in the package.

# WINGO v3.2.0 — Paper Ledger + Trend/Divergence Intelligence

Build: `WINGO v3.2.0 Paper Ledger + Trend/Divergence Intelligence (Execution Locked)`

## Delivered

- Added a persistent manual paper account with opening capital, deposits,
  withdrawals, available cash, used margin, equity and drawdown.
- Added an immutable, idempotent open/close ledger with gross P&L, net P&L,
  entry/exit slippage and itemized brokerage, STT/CTT, exchange charge, SEBI
  fee, GST and stamp duty.
- Added editable broker/cost profiles for Upstox, FYERS, Shoonya and Custom.
  Default STT rates follow the schedule effective 1 April 2026: 0.05% on the
  sell side of equity futures and 0.15% on option premium sales.
- Added deterministic adverse fills: bid/ask plus impact when supplied, or a
  configurable basis-point fallback.
- Added risk-based paper quantity, paper cash/margin checks and uniform manual
  and automatic entry gates.
- Added three saved market-trend policies: Default, With Trend and confirmed
  Counter-Trend RSI Divergence. Counter-trend mode accepts only a regular,
  direction-matching A+ or B+ divergence at the configured minimum grade.
- Added confirmed-pivot, non-repainting regular/hidden bullish/bearish RSI
  divergence to the F&O scanner, signal ledger and automatic strategy queue.
- Added the six current NSE equity-derivative index underlyings to scanner and
  subscription mappings: NIFTY, BANKNIFTY, FINNIFTY, MIDCPNIFTY, NIFTYNXT50
  and NIFTYFPI.
- Explicitly excluded BSE-related products from the scanner, user CSV path,
  futures master and subscription validator.
- Added INDIA VIX to the dashboard header with calm/normal/elevated/high state.
- Added compact `F●`, `U●`, `D●` provider badges with state, freshness, symbol
  count and health tooltips. Dhan remains a future paid-live-adapter slot; no
  unimplemented feed is allowed to route ticks.
- Added shared controls to every table: sorting, movable columns, persisted
  column visibility/width/sort, row hide/show, text filter, copy and CSV export.
- Added backup-first temporary cache reset and double-confirmed factory reset.
  Both preserve the centralized `.env`, application files and shared `.venv`,
  then restart WINGO.

## Safety and compatibility

- Real broker execution remains locked.
- Existing signal and paper-position JSON files migrate through dataclass
  defaults; unknown/stale fields do not prevent startup.
- The common credential contract remains `<Wingo root>\.env`; no package-local
  `.env` is read or shipped.
- Cross-provider history is never mixed within one symbol, and multi-leg paper
  exits still require coherent fresh marks.

## Current-rate references

- NSE STT schedule: <https://www.nseindia.com/static/products-services/equity-derivatives-securities-transaction-tax>
- NSE stamp-duty schedule: <https://www.nseindia.com/static/invest/first-time-investor-sebi-turnover-fees-stt-other-levies>

All rates are editable because broker/exchange/statutory schedules can change.


# WINGO v3.7.21 unified_theme_gui

This is a GUI-only release. Feed, scanner, signal, Paper accounting and execution-lock behaviour remain unchanged.

## Unified themes

- Adds three approved semantic presets: **Midnight Dark** (default), **Royal Blue**, and **Royal Green**.
- Adds synchronized theme radio buttons in `Settings → Appearance` and the fixed footer.
- Theme changes apply immediately and persist in the shared WINGO settings state.
- Adds a fixed local clock using `DD:MM:YY - HH:MM:SS`.
- Makes Dashboard styling the common visual language for all pages, dialogs, focus views and the detached Profitability window.
- Preserves semantic BUY/SELL, profit/loss, warning/error colours across every preset.

## Readability and tables

- Standardizes GUI typography on **Arial**; Logs retain Consolas for diagnostic readability.
- Removes table grids and hard outer table borders. Alternating surfaces and a very mild header separator preserve row/column readability.
- Adds visible `A-` and `A+` controls to every registered table, with an 8-20 px bounded range and an Arial 11 px reset.
- Persists font size independently for each table, including detached Profitability tables.
- Adds bounded Smart Auto-Fit based on headers and representative visible cell data.
- Auto-Fit is debounced at 650 ms and samples at most 220 visible rows, preventing live repaint/resize storms.
- Adds `Automatic Smart Auto-Fit`, `Auto Fit Now`, `Fit to Window`, and font reset actions to Table Tools.
- Mirrors `A-`, `A+`, and `AUTO FIT` controls in full-screen table focus windows.

## Safety retained

- Central WINGO `.env` and shared `.venv` remain outside the version folder.
- Provider callback isolation, 250 ms live UI coalescing, two-slot REST workload governor and queued logging/session writes remain unchanged.
- Manual Paper reserve, Script/Symbol ledger visibility, charges, taxes and slippage remain unchanged.
- Real broker execution remains locked; no `place_order` call is present.


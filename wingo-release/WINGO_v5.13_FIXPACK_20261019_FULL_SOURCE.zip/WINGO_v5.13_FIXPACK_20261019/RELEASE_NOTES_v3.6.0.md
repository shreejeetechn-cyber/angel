# WINGO v3.6.0 — Roadmap Logic Completion

This release keeps the v3.5.0 Complete Superpage UI and upgrades the research logic underneath it. Live broker execution remains locked.

## Implemented
- Independent lifecycle engine: PRE-SIGNAL, ENTRY READY, CONFIRMED, MOMENTUM STRONG, EXHAUSTING, EXIT.
- RSI can no longer declare CONFIRMED/MOMENTUM STRONG by itself.
- VWAP acceptance states require trustworthy anchored session VWAP, directional slope, and non-extended location.
- Separate TREND and qualified REGULAR-DIVERGENCE REVERSAL acceptance paths.
- Persistent-depth confirmation; one transient book imbalance does not count as strict depth confirmation.
- Combined E-CVD + depth interpretation: strong buying/selling and absorption states.
- E-CVD 1-minute slope and 5-minute price-vs-delta divergence diagnostics.
- Strategy engine uses lifecycle, VWAP, option liquidity/spread, IV/VIX, and futures availability; execution remains research-only.
- Shadow validation records same-horizon baseline returns for Baseline-vs-Lab comparison.
- v3.6 validation gate uses only v3.6 fixed-model outcomes, chronological last-25% OOS checks, and baseline uplift before readiness.
- Adaptive weights disabled for v3.6 fixed-model validation; optimizer output is research-only.
- Paper automation is disarmed during migration and can only be armed explicitly after validation has already passed.

## Compatibility and safety
- Existing v3.5 numerical VWAP/OI/slippage fixes are retained.
- Feature isolation remains under `app/features/profitability_lab`.
- No live broker order path was added.
- Historical shadow rows remain visible but cannot unlock the v3.6 activation gate once v3.6 outcomes exist.

# WINGO v3.2.2 — Amendment UI Accessibility Fix

Build: `WINGO v3.2.2 Amendment UI Accessibility Fix (Execution Locked)`

## Why this release exists

The v3.2.0/v3.2.1 backend contained the paper ledger, cost model, trend policy,
divergence engine, reset handlers and universal table controller, but several
controls were compressed or clipped by dense non-scrollable pages. This release
changes the page structure so the amendment features are visible and usable.

## Paper account and P&L ledger

- Paper now has four dedicated tabs: **Account & Costs**, **Automation**,
  **Positions**, and **P&L Ledger**.
- An always-visible **Open P&L Ledger** action opens the ledger directly.
- Positions and ledger tabs show live row counts.
- Ledger and positions tables have explicit minimum heights and no small
  ledger maximum-height restriction.
- Manual opening capital, add/withdraw funds, broker profile, brokerage,
  STT/CTT, exchange, SEBI, GST, stamp and auto-slippage controls are arranged
  in a scrollable grid.
- The underlying paper engine was rechecked with a complete simulated open,
  mark and close. Gross P&L, itemized charges, entry/exit slippage, net P&L and
  ledger balance reconciled.

## Settings and trend policy

- Settings now has three dedicated tabs: **General**, **Trend & Divergence**,
  and **Cache & Restart**.
- The three mutually exclusive trend choices are directly visible:
  Default Balanced, With Market Trend Only, and Counter-Trend RSI Divergence.
- Counter-trend minimum divergence grade remains configurable as A+ or B+.
- Temporary cache reset and double-confirmed factory-fresh restart are no
  longer placed below a clipped page; both are in the Cache & Restart tab.
- Both reset paths still create a backup and preserve the centralized `.env`,
  `.venv` and application files.

## Dedicated divergence watch

- A new **RSI Divergence** navigation page lists confirmed A+/B+ regular or
  hidden bullish/bearish divergence with score, age, RSI values, current trend
  policy permission and history provider.
- Filters cover grade, direction and all-F&O versus NSE-index-only scope.
- A separate coverage table always lists NIFTY, BANKNIFTY, FINNIFTY,
  MIDCPNIFTY, NIFTYNXT50 and NIFTYFPI with signal/data status.
- BSE and BSE-related products remain excluded.

## Tables and dashboard status

- Every `QTableWidget` receives a visible **Table Tools** button.
- Table Tools exposes Sort, Columns, Hide Selected Rows, Show All Rows,
  Filter, Copy, CSV Export and Reset Layout.
- Header sections are explicitly clickable for left-click sorting.
- Cell right-click is connected to the table viewport, fixing Windows context
  menu delivery over cells and empty table space.
- The sidebar navigation is scrollable at the 1366x768 acceptance size.
- The Dashboard header is split into two rows and retains NIFTY 50,
  BANKNIFTY and INDIA VIX.
- Provider badges show readable text states (`F● LIVE`, `U● LIVE`, `D● SLOT`)
  and refresh immediately on FYERS/Upstox connection events in addition to the
  Dashboard timer.

## Diagnostics and safety

- UI Self-Test now checks scrollable navigation, four Paper tabs, three
  Settings tabs, non-collapsing ledger tables, dedicated divergence coverage,
  viewport context menus, visible table tools and readable provider badges.
- v3.2.1 OneDrive/Windows persistence retry and debounce hardening is retained.
- Existing state and settings schemas remain compatible; no reset is required.
- Credentials are read only from the common Wingo-root `.env`.
- Real broker execution remains locked.

## Installation

Extract this build directly under:

`C:\Users\surya\OneDrive\Desktop\Shoonya_OI_Tracker\Wingo`

Start with `START_WINGO.bat`. Do not copy keys, secrets or tokens into the
extracted project folder.

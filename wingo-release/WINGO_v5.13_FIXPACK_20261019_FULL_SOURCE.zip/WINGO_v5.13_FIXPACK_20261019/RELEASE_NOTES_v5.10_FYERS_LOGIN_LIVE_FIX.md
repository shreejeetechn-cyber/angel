# WINGO v5.10 FYERS Login/Live Fix — Clean Build

This clean source/build kit fixes the FYERS issues observed in the 2026-09-11 diagnostics.

## Fixed

- Commercial Nuitka build now explicitly packages `fyers_apiv3/FyersWebsocket/map.json`.
- Build fails before release if FYERS SDK 3.1.16 does not provide `map.json`.
- Frozen distribution is checked again after Nuitka; a missing `map.json` blocks the release.
- FYERS live runtime performs a package-resource preflight before importing the WebSocket transport.
- Missing WebSocket package data is reported as `PACKAGE_FATAL` / **PACKAGE ERROR**, not as token expiry.
- Package-resource failure stops the live transport instead of entering a repeated reconnect-warning loop.
- FYERS REST/auth/WebSocket logging remains routed through the WINGO writable runtime log directory under LocalAppData for installed builds.

## Not changed

- FYERS OAuth/token security model.
- User credentials, PIN, OTP/TOTP or auth codes are not embedded in this build.
- Live execution remains locked by the existing WINGO safety policy.

## Verification

Run:

```powershell
python qa\verify_v5_10_fyers_login_live_packaging_fix.py
```

A Windows commercial build must also print successful FYERS WebSocket resource preflight and frozen-resource verification messages.

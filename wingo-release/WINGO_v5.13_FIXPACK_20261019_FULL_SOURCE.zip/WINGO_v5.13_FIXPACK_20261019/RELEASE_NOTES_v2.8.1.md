# WINGO v2.8.1 — FYERS Auth + History Verified

Audit fixes:
- Authentication UI now exposes working `Validate Auth`, `Test History`, and `Full FYERS Health Check` buttons.
- Restored/created `fyers_value` and `fyers_detail` widgets used by validation callbacks.
- Fixed the latent crash where FYERS validation callbacks referenced widgets that did not exist.
- FYERS login SessionModel now includes the Secret Key, matching the official SDK login-flow example.
- Pasted auth_code fragments are URL-decoded safely.
- Auth validation no longer logs the raw FYERS profile response.
- History test validates chronological candle shape and numeric OHLCV, not just non-empty data.
- Full health check validates:
  1. access token/profile,
  2. short FYERS History request,
  3. WINGO scanner's actual 620-day chunk/merge History path,
  4. enough M/W/D bars for RSI(14).
- Scanner History implementation itself is intentionally unchanged because it has already passed the full F&O universe in runtime testing.

No order endpoint is called. Execution remains locked.

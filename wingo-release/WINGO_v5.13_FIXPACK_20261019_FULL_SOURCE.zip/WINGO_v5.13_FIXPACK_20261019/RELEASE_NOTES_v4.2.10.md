# WINGO v4.2.10

## Profitability Multi-Timeframe + Manual Minute Refresh

- Profitability-only TF checkboxes on the existing indicator line: 5m, 15m, 1H, 4H, D, W.
- Multiple TFs can be selected; selection persists. Default upgrade behavior remains D.
- AMIT remains read-only. Its existing Price EMA / RSI-BB fields now use the first selected TF and add TF Primary / TF Align / TF Summary columns.
- Legacy DECISION, RSI, FLOW and ALL 39 column contracts remain unchanged.
- LTP remains live; timeframe changes analysis candles only.
- Existing five refresh options remain MANUAL / REALTIME / FAST / BALANCED / STABLE with original preset milliseconds.
- Existing MANUAL option now accepts a custom 1..1440 minute cadence and persists it.
- Intraday history uses existing FYERS/Upstox historical failover policy without mixing providers inside one seed. Higher selected intraday TFs are locally resampled from the smallest selected base TF.
- D/W use scanner history; no extra history API is needed for those selections.
- 5m/15m can use matching rolling CVD growth. 1H/4H/D/W do not fabricate unavailable timeframe-specific aggressor CVD.
- Stage 0-7, Paper safety and Live Execution lock remain unchanged.

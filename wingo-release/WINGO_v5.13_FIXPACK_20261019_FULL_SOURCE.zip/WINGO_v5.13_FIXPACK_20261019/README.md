# WINGO v5.10 TOOLBOX INTEGRATED

v5.10 is the incremental Toolbox-Integrated commercial build release promoted from the verified v5.09.1 lineage. Trading, profitability, paper, risk, broker re-login and market-routing behavior are retained; the active release identity and Windows build/toolbox integration are advanced to v5.10.
Baseline architecture: v5.09 is an incremental architecture release based on the verified v5.08 calculation baseline. It moves Stage 1-7 live analytical computation off the Qt MainThread, separates lossless core tick flow from coalesced UI/analytical work, virtualizes the Signals table, introduces canonical Paper/dashboard snapshots, revision/dirty dependencies, bounded TTL/LRU caches, a central scheduler, journal/checkpoint persistence, controlled GC/runtime telemetry, and isolates profitability evidence so unrelated AUTO trades cannot share one monetary Expected ₹/Lot fallback.

Default AI Trade Intelligence limits in v5.09 are: Minimum DTE 0, Maximum DTE 60, Candidates/Signal 5, Signals/Cycle 30. Live broker execution remains LOCKED.

## v5.09 verification boundary

Automated offline release gates cover calculation regressions, CVD parity/soak, option/futures economics, profitability policy, risk, signal lifecycle, MCX multi-exchange contracts, UI source architecture, lossless buffering, cache/revision/persistence infrastructure, Python AST/compile checks, and forbidden package-file scans. Real broker-session freshness, live reconnect, and Windows/PySide6 GUI heartbeat/load checks remain runtime-only acceptance items and are not represented as offline PASS.

## v5.06 scope
- AI planner uses economic quantity per lot for Futures risk, notional and capital efficiency; broker lot size remains a separate order quantity.
- Futures/option freshness uses provider timestamps only; analysis/repricing time can no longer make stale market data look fresh.
- AI Engine, Auto Paper Entry/Exit, minimum grade, DTE, spread, quote-age, alternative-search and candidate-cap controls are wired to live runtime behavior.
- Self-learning champion evidence can influence ranking only through a bounded preference multiplier capped at 10%; it cannot override risk, freshness, capital or safety gates.
- Automatic champion rollback is auditable and restores the prior policy when promoted evidence degrades below configured requirements.
- AI planner evaluation runs in a background FunctionWorker from immutable snapshots; Auto Paper no longer calls planner.evaluate synchronously on the GUI thread.
- AI work is prefiltered/capped before expensive profitability analysis; default maximum is 120 signals per cycle.
- Signals rendering uses a production time-budget helper with a hard four-row chunk cap.
- Web GUI mirror heartbeat polling no longer performs a full Qt widget walk; forced compatibility snapshots are time-budgeted and cache-backed.
- Automated stress gates exercise 2,500 AI candidates and 2,500 signal rows.
- Live Execution remains locked and Stage 8 remains absent.

See `RELEASE_NOTES_v5.06.md` and `ACTIVE_RELEASE_CHECKLIST.md`.

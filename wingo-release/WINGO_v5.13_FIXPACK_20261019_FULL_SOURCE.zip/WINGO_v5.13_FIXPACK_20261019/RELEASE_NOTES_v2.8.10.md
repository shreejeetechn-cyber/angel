# WINGO v2.8.10 — Paper Feed Sync Reliability

## Live Paper Scanner -> Sync Live Option Feed audit

The button subscribes ONLY the FYERS option symbols belonging to currently
OPEN paper positions. It is not a general option-chain streaming button.

### Fixed

1. `Subscribed: N` was previously set from target symbols before the server
   had acknowledged the subscription.
   - Now the UI shows `Subscribed: actual / Target: requested`.

2. Paper table `Live=YES` could be shown just because a symbol was in the
   target set.
   - Now LIVE requires actual subscribed state.

3. Repeated Sync could stop the old QThread, wait only 100 ms on the GUI
   thread, then drop the Python reference.
   - Removed GUI-thread wait.
   - Retired feeds are retained until `QThread.finished`.
   - Old-generation callbacks are ignored.
   - Prevents `QThread: Destroyed while thread is still running` risk.

4. Sync is idempotent.
   - Repeated clicks do not restart an already healthy/reconnecting feed with
     the same target symbols.
   - Changed/offline targets get a new generation safely.

5. Added independent data freshness:
   - DATA: IDLE
   - DATA: WAITING FOR SUBSCRIPTION
   - DATA: SUBSCRIBED - WAITING FOR TICK
   - DATA: LIVE
   - DATA: QUIET
   - DATA: NO RECENT TICK
   A quiet/illiquid option is not falsely marked as a connection failure.

6. Tick count and last tick age are visible.

7. Reconnect clears the actual subscribed set until FYERS acknowledges the
   resubscription.

8. Shutdown now stops and waits on retired Paper QThreads too.

9. FYERS API v3 current support limit updated to 5000 unique symbols per API
   key. WINGO Paper Automation still normally uses only a handful because
   max open paper positions defaults to 5.

### Preserved

- FYERS REST auth preflight
- reconnect=True
- subscribe -> keep_running callback pattern
- generation-safe callbacks
- Auto Paper SL/Target exits
- daily PnL and risk gates
- Session Audit
- Execution locked

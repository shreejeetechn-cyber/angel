# WINGO v2.8.4 — Hang Fix & Runtime Throttle

Root cause addressed:
- persisted Paper positions could auto-start the Paper WebSocket during MainWindow construction;
- every Paper market tick wrote positions to disk, rebuilt the Paper table, and rebuilt the Dashboard;
- fast ticks could saturate the Qt GUI event loop and appear frozen;
- WebSocket stop previously waited up to 2 seconds on the GUI thread;
- shutdown could wait indefinitely for blocking SDK/network workers.

Fixes:
- no broker connection is opened inside MainWindow.__init__;
- startup services resume 1.5 seconds after the window/event loop starts;
- Paper feed is not auto-resumed after market hours;
- Paper ticks are UI-throttled to 750 ms;
- Paper persistence is throttled to 2 seconds, with immediate save on open/close/exit;
- Paper table schedules Dashboard refresh instead of rebuilding Dashboard directly;
- Paper WebSocket SDK reconnect loop disabled; explicit Sync button retries cleanly;
- failed Paper feed is actively stopped;
- old Paper feed stop no longer blocks GUI for 2 seconds;
- shutdown gets a 6-second grace period then force-terminates only remaining threads;
- START_WINGO_SAFE.bat added. Safe Start does not delete any state.

Execution remains locked.

# WINGO v3.2.4 — Provider-Neutral Market Breadth Hotfix

Build: `WINGO v3.2.4 Provider-Neutral Market Breadth Hotfix (Execution Locked)`

## Root cause closed

When Upstox completed Health first, it started the daily intelligence services
and set `market_services_started_day`. FYERS could pass Health later, but the
same-day early return occurred before the FYERS-only breadth timer block.
Consequently the timer never started and the Dashboard remained at A/D/U 0,
coverage 0%, `DATA INCOMPLETE`, even though both feeds looked healthy.

## Runtime correction

- Breadth arming now occurs before the same-day startup early return.
- It can start from either validated provider during the open NSE session.
- A first refresh is scheduled immediately; the bounded timer continues every
  90 seconds.
- The configured `WINGO_PRIMARY_MARKET_FEED` determines first attempt.
- `WINGO_AUTO_MARKET_FAILOVER=1` permits the other healthy provider to supply
  a complete fallback snapshot when the primary quote call fails or has less
  than 70% coverage.
- Provider snapshots are never mixed inside one breadth calculation.

## Quote and integrity contract

- FYERS uses its bulk Quotes response.
- Upstox uses V3 LTP fields `last_price` and `cp` (previous session close).
- Every snapshot records source, primary, fallback, coverage and attempts.
- A result below 70% coverage cannot overwrite a usable last-good snapshot.
- Market-regime freshness continues to expire after three minutes, so an old
  last-good snapshot cannot silently authorize a current trade.
- Dashboard regime text exposes breadth source and coverage; logs include
  provider attempts and low-coverage reasons.

## Retained safety

- v3.2.3 status footer, Acceptance correction, FYERS NIFTYFPI live guard and
  previous-day trend exclusion remain active.
- All v3.2.2 ledger, charges/slippage, manual money, table tools, trend policy,
  reset controls and RSI divergence A+/B+ work remains included.
- BSE remains excluded and real broker execution remains locked.

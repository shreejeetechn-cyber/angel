# WINGO v5.10.0.3 — FYERS Login/Live Packaging Incremental Release

Date: 2026-09-11

This is an incremental version of the verified v5.10.0.2 FYERS login/live packaging fix.
No trading-policy or live-execution safety changes are introduced by this version bump.

## Version identity
- Windows file version: 5.10.0.3
- Windows product version: 5.10.0.3
- Distribution: 5.10-toolbox-integrated-commercial3-fyers-resource-fix

## Retained FYERS fixes
- FYERS SDK writable logs use the WINGO LocalAppData runtime log directory.
- FYERS WebSocket `map.json` is preflighted before the frozen build.
- Nuitka explicitly includes `fyers_apiv3/FyersWebsocket/map.json`.
- Frozen Windows output is rejected if `map.json` is absent.
- Runtime package-resource preflight distinguishes PACKAGE ERROR from AUTH EXPIRED.
- Package-fatal transport failures stop reconnect warning storms.

## Safety
- Live execution lock unchanged.
- No credentials, PIN, OTP/TOTP, auth code, access token, or client secret added.

WINGO 5.11 - SLIM APP SOURCE

PRIMARY USE
-----------
Use your ONE Universal WINGO Toolbox. The Toolbox is intentionally NOT included here.

1. Extract this ZIP to a normal folder, for example C:\WINGO\WINGO_v5.11.
2. Open your existing Universal WINGO Toolbox.
3. Select this extracted WINGO_v5.11 folder as the WINGO source folder.
4. Confirm the Toolbox detects version 5.11.
5. Choose LOCAL TEST for owner testing, or PRODUCTION only with your real license server/key.
6. Build the application.
7. Expected output in .commercial_build\out\:
   - WINGO_v5.11_Setup.exe
   - WINGO_v5.11_PORTABLE.zip
   - SHA256SUMS.txt
   - BUILD_REPORT.txt
   - SECURITY_SCAN_FINAL.json
8. Close any running older WINGO, then run WINGO_v5.11_Setup.exe as Administrator.
   The installer uses the same WINGO AppId, so it upgrades the existing WINGO installation.

MANUAL FALLBACK
---------------
If you deliberately build without the Universal Toolbox, run BUILD_COMMERCIAL_WINDOWS.bat on a Windows build PC.
That PC needs Python 3.12 x64 and Inno Setup 6.

Build target: WINGO 5.11
Windows file version: 5.11.0.0
Patch scope: FYERS stale login UI + FYERS cash reference normalization.
Universal Toolbox: external / unchanged.

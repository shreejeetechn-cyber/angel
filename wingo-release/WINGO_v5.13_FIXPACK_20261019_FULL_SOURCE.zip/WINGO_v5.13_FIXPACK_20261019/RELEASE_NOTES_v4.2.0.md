# WINGO v4.2.0 — Unified Strategy Inspector Connections

This release promotes the verified v4.1.29 Inspector connection amendment to a
complete v4.2.0 package identity. Runtime, launchers, README, version marker,
root folder and ZIP filename all identify v4.2.0.

Connected read-only contexts:

- Signals and actual Paper positions.
- Profitability Matrix, including its detached Pop Out.
- Ranked Option Chain strategies.
- RSI Divergence while retaining Futures navigation on row double-click.
- Active Alerts and permanent Alert History.
- Paper P&L Ledger and frozen historical Backtest rows.
- MM Observer, Shadow MM, restricted Paper MM and Portfolio MM inventory.

Safety and lifecycle:

- Qt UI remains on the GUI thread and reuses existing data workers.
- Duplicate Inspector contexts focus the existing dialog.
- Historical Backtest rows never mix with live executable marks.
- MM drill-down remains observation/research/simulation only.
- Stage 0–7 gates remain intact and Live Execution remains locked.

Verification:

- Python parsing and compilation pass.
- Stage 0–7 regression suite passes.
- Final roadmap closure and persistent Alert Journal suites pass.
- Inspector routing/thread/static safety suite passes.
- Actual Windows GUI click verification remains documented in
  `QA_v4.2.0_INSPECTOR_CONTEXT_CONNECTIONS.txt`.

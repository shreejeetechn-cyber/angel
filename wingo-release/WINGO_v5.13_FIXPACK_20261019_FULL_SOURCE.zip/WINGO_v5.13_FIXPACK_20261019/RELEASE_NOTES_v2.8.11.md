# WINGO v2.8.11 — Daily FYERS Session Bootstrap

Every normal WINGO launch with a saved FYERS token now runs:

Validate Auth
-> Test History
-> Full FYERS Health Check
-> Auto-connect Main Live Feed when market session is OPEN
-> Resume Paper Option Feed only when open paper positions exist

A saved token is never trusted merely because it exists; profile validation is
the source of truth.

If token is missing or invalid, the chain stops before WebSocket startup.
After a new token is generated, WINGO automatically restarts the complete
sequence. Manual Auth/History/Health/Connect buttons remain available.

Safe Start continues to suppress automatic network startup.
Credential values are not intentionally logged.
Real execution remains locked.

# WINGO v3.7.22 table_font_hotfix

## Fixed

- Full-screen Focus `A-`, `A+`, and `AUTO FIT` buttons now absorb Qt's emitted `clicked(bool)` value.
- The captured source `QTableWidget` can no longer be replaced by `False`, preventing both reported exceptions:
  - `AttributeError: 'bool' object has no attribute 'setFont'`
  - `AttributeError: 'bool' object has no attribute 'columnCount'`

## Retained

- Midnight Dark, Royal Blue and Royal Green themes.
- Footer theme radios and local date/time.
- Arial readability, borderless tables, per-table font persistence and bounded Smart Auto-Fit.
- Feed/scanner/Paper behavior, central `.env`/shared `.venv`, runtime isolation and execution lock.


# WINGO v4.0.4 autonomous_ai_trade_planner

## Release focus
v4.0.4 is the AI decision-quality and trading-correctness release. It preserves the existing Scanner, Profitability, Signals, Futures/Options intelligence, Paper Trading, Cash Holdings and Strategy / Spread Inspector while adding a controlled evidence-learning layer. Real/live execution remains locked.

## Calculation and risk corrections
- Broker/segment-aware brokerage and statutory cost profiles for Upstox, FYERS and Shoonya.
- NSE/STT schedules use the 2026 effective dates carried in the cost profile.
- BUY entry liquidity consumes ASK depth; SELL entry consumes BID depth.
- Market direction is no longer confused with option order side (BUY PUT is bearish; SELL PUT is bullish).
- OI confirmation is direction-aware instead of availability-only.
- Option payoff bounds preserve unbounded profit/loss as unbounded.
- Current DTE is recalculated from expiry at exit-decision time.
- Portfolio emergency is first in the exit hierarchy; configured session-exit HH:MM is honored.
- Paper open-risk uses the same planned-stop basis used at admission.
- Cash manual entry validation can mark unrealistic/test entries as learning-ineligible.

## AI Trade Decision and Optimization
- Prediction evidence is separated from final trade decision logic.
- Planner records post-cost Net Expected Value, Return on Risk, Return on Capital, edge/cost ratio, sample reliability, uncertainty, OOD flag, size factor and optimization score.
- Negative/insufficient net EV, stale quotes, weak liquidity/confirmation, OOD-high-uncertainty and portfolio blocks produce explicit NO-TRADE reasons.
- Historical strategy/regime/sector buckets can feed decision reliability.
- Trade Decision Passport is persisted with paper positions.

## Trade Adjustment / Exit Intelligence
- New advisory states: HOLD / ADJUST / REDUCE / EXIT.
- Adjustment obeys a fresh-trade test and refuses loss-chasing changes when post-cost EV does not improve.
- Hard Risk & Safety exits remain authoritative and cannot be overridden by AI advisory.

## Self-Study / Learning
- learning_enabled=OFF now stops study and policy mutation.
- Closed-trade learning is gated by P&L validity, reconciliation and entry-data quality.
- Per-trade JSON/TXT study records include expected vs actual P&L, MFE/MAE, charges/slippage, process classification and lesson.
- Buckets include trades, sessions, win rate, PF, expectancy, average R, drawdown, losing streak, slippage and charges.
- Champion/Challenger state is bounded to policy evidence and never mutates hard risk limits or source code.
- Hourly/EOD reports carry richer self-study data and use persistent schedule state to avoid duplicate EOD generation after restart.

## Strategy / Spread Inspector
- Active inspector legs/underlying are pinned into subscription priority while the inspector is open.
- Quote state: LIVE / DELAYED / STALE / PARTIAL / NO QUOTE.
- Live underlying spot is preferred for Paper positions.
- Shows actual/planned R:R, strategy Greeks, profit-capture and breakeven-distance metrics where data exists.
- Shows HOLD / ADJUST / REDUCE / EXIT advisory for open paper positions.

## Profitability
- Visible Profitability rows are promoted into dynamic subscription priority.
- Blank LTP displays NO QUOTE rather than silently appearing empty.
- Filter UI reports visible/total rows and active-filter state.

## Dashboard GUI
- Rebuilt the market ribbon for NIFTY 50, BANK NIFTY and INDIA VIX.
- Equal card structure: caption, value, change/status, provider and freshness, sparkline.
- Corrected BANK NIFTY sparkline attribute mismatch.
- Added an ALARMS indicator linking to the independent Operator Alert & Safety Center.
- Market/session/provider metadata is separated from index values for clearer alignment.

## Operator Alert & Safety Center
This is intentionally separate from the AI Trade Engine. It tracks operator-facing data/risk/system alarms, acknowledgement, resolution and audit history. AI remains focused on trade decisions and learning.

## Compatibility and safety
- Existing v4.0.3 user state remains loadable through defaulted dataclass/config fields.
- Live execution is still locked.
- PySide6 is not installed in the release QA container, so Qt runtime rendering was validated statically rather than by a live GUI launch. Core Python compilation and non-Qt calculation regression are included in the v4.0.4 QA script.

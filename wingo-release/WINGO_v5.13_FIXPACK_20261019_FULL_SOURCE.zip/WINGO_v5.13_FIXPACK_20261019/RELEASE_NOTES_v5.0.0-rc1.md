# WINGO v5.0.0-rc1 — Final Multi-Exchange Safety Consolidation

## Scope

This release candidate consolidates the v5.0.0-dev2.1.x MCX runtime, breadth and signal-isolation hotfixes into one production-safety candidate. It does not add Stage 8 or live broker order submission.

## Delivered

1. **Paper multi-exchange safety**
   - `PaperPosition.exchange` is immutable and restored for legacy records.
   - NSE and MCX Paper positions can coexist in one account/ledger.
   - Exchange-tagged ticks cannot mark the other exchange's positions.
   - Paper ledger entries persist exchange, broker cost profile and cost-model version.
   - Open Paper legs remain transport-critical across the UI exchange switch.
   - If an inactive-exchange Paper position exits, the owning exchange's Signal Lifecycle store is restored/updated/saved separately.

2. **MCX-specific Paper cost model**
   - Cost calculation accepts `exchange` and `underlying`.
   - MCX FUT/OPT use commodity CTT, MCX transaction/stamp and broker-profile clearing schedules instead of NSE derivative transaction rates.
   - Cost receipts persist `exchange`, `underlying`, `cost_model_version` and effective-date metadata.
   - Profitability pre-trade round-trip estimates are exchange-aware.

3. **Liquid initial MCX autonomous universe**
   - `GOLD`, `SILVER`, `CRUDEOIL`, `NATURALGAS` only for autonomous Scanner/Auto Paper/Profitability evidence.
   - Full MCX futures/options contract inventory remains available for manual research.
   - Paper Engine independently blocks automatic MCX admission outside the four-symbol production universe.

4. **Atomic exchange reset**
   - UI switch renews provider generation gates before socket shutdown.
   - `LiveTickBuffer.bump_generation()` clears queued/latest old-context ticks.
   - `MultiProviderTickRouter.reset()` clears provider selection, failover/recovery and divergence memory.
   - Stale generation ticks are rejected.
   - Open cross-exchange Paper risk legs are re-added by subscription priority.

5. **Exchange/session/contract safety**
   - Separate runtime calendars: `markets/NSE/session_calendar.json` and `markets/MCX/session_calendar.json`.
   - Legacy global `market_holidays.json` is NSE-only fallback.
   - MCX 2026 partial morning/evening holiday matrix is bundled as safe fallback.
   - Commodity session classes support non-agri international, international agri and domestic agri closing times.
   - Unknown Muhurat/special-session clock windows stay safely closed until an explicit runtime override supplies times.
   - Autonomous derivatives require exact ISO expiry.
   - MCX autonomous entry is blocked within the conservative pre-expiry buffer and Paper exit is required before expiry/devolvement risk. Tender dates are not fabricated.

6. **Profitability evidence proof**
   - Acceptance no longer treats `NSE:RELIANCE-EQ` research backtest as MCX profitability evidence.
   - Evidence is loaded from the active exchange's Profitability Lab state.
   - MCX historical evidence is filtered to the four production underlyings.
   - Existing strict performance analytics supply closed-trade/session, expectancy, win-rate, PF, OOS and baseline-uplift gates.
   - `PROVEN` requires both the analytics gate and all rc1 safety prerequisites.
   - `auto_trade_eligible` remains false; Live Execution remains independently locked.

7. **Web/version hygiene**
   - Removed stale v4.5.3 static Web description.
   - Desktop/Web/safe/all launchers identify v5.0.0-rc1.
   - Static Web description is version-neutral; runtime version comes from the core.

## Acceptance safety rows

- MCX Production Universe
- Paper Multi-Exchange Safety
- MCX Paper Cost Model
- Atomic Feed Router Exchange Reset
- Exchange Session Holiday Isolation
- Web Version Source
- Profitability Evidence (separate from system acceptance)

## Safety invariants

- Live Execution: **LOCKED**
- Stage 8: **ABSENT**
- Profitability Auto Pop Out: **DISABLED**

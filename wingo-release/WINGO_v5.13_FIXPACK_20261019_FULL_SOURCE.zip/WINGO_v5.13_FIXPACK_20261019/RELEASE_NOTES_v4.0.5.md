# WINGO v4.0.5 autonomous_ai_trade_planner

## Release focus
v4.0.5 is a startup-stability hotfix for the v4.0.4 Operator Alert integration. It preserves all v4.0.4 trading, AI decision, optimization, adjustment, learning, reporting, dashboard and safety behavior. Live execution remains locked.

## Fixed
- Fixed startup `AttributeError: QTableWidget has no attribute setText` while building the Alerts page.
- Root cause: Dashboard used `self.dash_alerts` for two different widgets: the top ALARMS QPushButton and the Dashboard signal-alert QTableWidget.
- Renamed the top operator alarm control to `self.dash_alarm_button`.
- Renamed the Dashboard signal/event table to `self.dash_signal_alerts`.
- Alert Center refresh now updates only `dash_alarm_button`.
- Dashboard signal/event refresh and double-click navigation now use only `dash_signal_alerts`.

## Regression guard
- Added a static scan for duplicate `self.<attribute> = Q...()` assignments where the same attribute name is bound to different Qt widget classes.
- Added explicit checks that Alert Center status text targets the QPushButton and Dashboard signal rows target the QTableWidget.
- Existing v4.0.4 calculation/AI regression is rerun under v4.0.5 identity.

## Safety
- No live broker execution was enabled.
- Existing user state remains compatible.

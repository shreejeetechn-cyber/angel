# WINGO v3.1.0 — Multi-Provider FYERS + Upstox Data Feed

Build: `WINGO v3.1.0 Multi-Provider FYERS + Upstox Data Feed (Execution Locked)`

## Purpose

v3.1.0 adds a provider-independent market-data layer without replacing the
existing FYERS analysis stack. FYERS remains the default authoritative provider;
Upstox is added as an independent secondary feed for verification and guarded
fallback. Real broker execution remains locked.

## Provider topology

- One canonical WINGO symbol plan is created by the existing subscription manager.
- At most one realtime market-data socket is owned per provider:
  - one FYERS `FyersDataSocket` transport;
  - one Upstox `MarketDataStreamerV3` transport.
- No separate Paper FYERS socket is reintroduced.
- Open Paper strategy legs remain P1 subscription-critical symbols.
- `live_subscription_plan.json` records `transport_topology=ONE_SOCKET_PER_PROVIDER`.

## Upstox integration

New provider modules:

- `app/providers/upstox_instruments.py`
  - downloads/caches the Upstox NSE JSON instrument master;
  - maps WINGO canonical equity/index/monthly FUT/CE/PE symbols to Upstox
    `instrument_key` values;
  - supports ISO or epoch-millisecond expiry values;
  - preserves numeric-leading names such as `360ONE` / `3MINDIA`;
  - refuses to guess weekly derivative canonical symbols.
- `app/providers/upstox_provider.py`
  - profile/auth validation;
  - Historical Candle V3 validation and daily-candle adapter;
  - LTP V3 quote adapter;
  - option-chain REST adapter;
  - full health = profile + history + NSE instrument master.
- `app/providers/upstox_live.py`
  - official Upstox Python SDK streamer wrapper;
  - FULL-mode subscription ceiling guarded at 2,000 keys;
  - automatic reconnect enabled with bounded retry configuration;
  - every new socket-open rebuilds the complete desired subscription set;
  - dynamic plan changes use complete-set unsubscribe -> complete-set subscribe;
  - manual force-resubscribe supported.

## Authentication

Authentication page now includes Upstox controls:

- Open Upstox Login
- Generate Upstox Token
- Validate Auth
- Test History
- Full Upstox Health

The app secret/access token remain in the common root `.env`; auth codes are not
saved. Startup performs an independent Upstox health check when the app is
configured and an access token is available.

## Cross-provider routing

New `MultiProviderTickRouter`:

- primary provider defaults to FYERS;
- Upstox is verify-only by default;
- automatic failover is OFF by default;
- optional failover is decided per symbol, not from a provider-global heartbeat;
- a fresh unrelated index tick cannot hide a stale option leg;
- cross-feed divergence is calculated only while the comparison tick is reasonably
  fresh, avoiding stale-secondary false alarms;
- a moderately stale primary mark with excessive cross-feed divergence is blocked
  from failover;
- a sufficiently old primary mark is not treated as a reliable divergence reference;
- primary recovery immediately restores primary selection on the next accepted tick.

Common `.env` policy keys:

```text
WINGO_PRIMARY_MARKET_FEED=FYERS
WINGO_AUTO_MARKET_FAILOVER=0
WINGO_CROSS_FEED_MAX_DIVERGENCE_PCT=1.5
```

## Paper transport safety

Paper marking now consumes only the market tick accepted by the multi-provider
router. Every mark records its selected provider.

A position can drive automatic exit only when:

1. every required leg is fresh after the latest resubscription/reconnect;
2. every leg is active on the provider that actually supplied its mark;
3. router selection still agrees with the stored mark provider;
4. for a multi-leg position, all legs are coherently marked by the same selected
   provider during failover/recovery transitions;
5. the existing v2.8.16 Paper Mark Guard reports a valid/READY mark.

The Paper status UI now reports `PAPER DATA (MULTI)` and persists FYERS/Upstox
active sets, target legs, subscribed legs, fresh legs and logical Paper state.

## Option-chain fallback

New `MultiProviderOptionChainProvider`:

- FYERS chain remains first choice;
- if FYERS chain fails and Upstox is authenticated, WINGO can request one complete
  Upstox option chain as a fallback;
- legs from different providers are never mixed inside one chain;
- IV/Delta/Gamma/Theta/Vega/OI/prev-OI/bid/ask/volume are normalized into WINGO
  models;
- all-zero Greek bundles remain `UNAVAILABLE_ZERO_BUNDLE`;
- provider-only/weekly derivative keys that cannot be represented safely by the
  current WINGO canonical grammar cause the fallback chain to be rejected rather
  than guessed.

This does **not** claim full Upstox parity for every WINGO service. Scanner breadth,
Futures OI/basis intelligence and the primary historical research stack continue to
use their existing FYERS paths unless explicitly routed in a later release.

## Diagnostics

AI-readable diagnostics/state now include:

- multi-provider router policy/status;
- FYERS and Upstox transport state;
- per-provider active symbols;
- Upstox rejected mappings;
- selected-provider counts;
- divergence/failover telemetry;
- multi-provider Paper subscription/freshness state.

Credential redaction includes Upstox API key/secret/access-token terminology.

## Environment / launcher

No new virtual environment is created. Continue using:

`C:\Users\surya\OneDrive\Desktop\Shoonya_OI_Tracker\Wingo\.venv`

`START_WINGO.bat` checks for `upstox_client`; if missing, it installs the pinned
`upstox-python-sdk==2.28.0` into the existing shared `.venv`.

## Safety / verification boundary

- Real execution remains LOCKED.
- Dhan remains parked when its Data API subscription is unavailable.
- Whole-project source compilation and synthetic/static multi-provider QA passed.
- The QA environment did not contain PySide6 or `upstox_client`; therefore actual
  PySide rendering, FYERS REST/WebSocket and Upstox REST/WebSocket calls were not
  executed in the build container.
- Final Windows + live-provider acceptance is required.

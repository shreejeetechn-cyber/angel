# WINGO v3.7.4 Release Notes

## Stability & Diagnostics + Safe Exit

- Corrected false UI Self-Test failure caused by intentional static Profitability metric tables.
- Diagnostics now names failed checks and separates current-session incidents from historical log evidence.
- Reduced duplicate false-red incident counting and successful Acceptance ERROR-level logging.
- Added bounded FYERS `-300` exact-symbol isolation; no quarantine occurs on ambiguous/network failure.
- Reduced repeated identical Upstox subscription log noise.
- Separated technical **System Acceptance** from **Profitability Evidence**; automatic trading eligibility remains false.
- Added **Safe Quit & Exit**: save state, stop services/workers, close the session cleanly, then flush/close the log.
- Added final `SHUTDOWN COMPLETE` logging for controlled exits.
- Replaced font/emoji-dependent operational controls with clear text or SVG: execution/engine/order-flow states, Refresh, Focus, Safe Exit and provider status badges.
- Runtime diagnostics now audits icon assets and icon-only control hints/accessibility.

## Safety

- Real broker execution remains locked.
- Application source contains zero `.place_order()` calls.
- Profitability calculation modules remain byte-identical to v3.7.3 except presentation `page.py`.

## Verification

23/23 QA suites PASS, 562 PASS checks, 139 Python files compile, and 23/23 SVG icons parse. The exact delivery ZIP was fresh re-extracted and the same QA/compile/safety/icon checks passed again.

## Known separate item

Factory Fresh reset WinError 32 is not redesigned in this release.

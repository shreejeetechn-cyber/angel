# WINGO v4.3.7 — Web Phase 5 Wiring + Compact GUI Hotfix

- Corrects Profitability analytics worker status mapping to `alive`, `tick_backlog`, `batch_backlog`, `pending_rebuilds`, and `error`.
- Propagates top-level `STALE`/`OFFLINE` liveness to Profitability, Paper/P&L, and Session Health source pills while retaining previous child state for diagnostics.
- Makes **Refresh All Workspaces** a true Phase-2 + desktop Phase-5 refresh request through an allow-listed `WORKSPACES_REFRESH_ALL` command.
- Adds compact desktop-parity Web styling: Arial, Midnight Dark semantic colours, 225/64 collapsible sidebar, compact controls, denser ribbons/cards, 11px operational tables, thin borders.
- Adds Ctrl+B / sidebar toggle persistence.
- Keeps Profitability Manual/5-minute visible refresh semantics unchanged.
- Live execution remains locked; Stage 8 remains absent.

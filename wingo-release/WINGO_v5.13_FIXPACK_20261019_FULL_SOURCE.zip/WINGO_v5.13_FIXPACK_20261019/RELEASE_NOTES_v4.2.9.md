# WINGO v4.2.9 — Profitability LTP Subscription + Alias Hotfix

## Fixed
- Removed the historical 30-row live-LTP priority ceiling for an actively viewed Profitability matrix.
- Up to 500 visible Profitability symbols can now enter the dynamic subscription plan while the page or dedicated pop-out is visible.
- Canonical scanner keys and raw provider/display aliases now share the latest accepted live tick, so LTP does not disappear because of symbol-key differences.
- Profitability row rebuild selects the freshest available tick across canonical/display/provider aliases.
- Profitability pop-out open/close immediately refreshes the dynamic live-subscription plan.

## Performance discipline
- The full-matrix priority subscription is active only while Profitability is visible or popped out.
- Hidden Profitability pages do not keep the extra full-universe LTP footprint.
- Open Paper/validation symbols remain protected independently.

## Safety
- Stage 0 through Stage 7 retained.
- Stage 8 execution engine not present.
- Live execution remains locked.

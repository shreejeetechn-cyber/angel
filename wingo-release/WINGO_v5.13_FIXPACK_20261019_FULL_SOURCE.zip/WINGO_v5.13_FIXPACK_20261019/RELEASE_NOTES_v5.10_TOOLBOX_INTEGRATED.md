# WINGO v5.10 TOOLBOX INTEGRATED

v5.10 is an incremental commercial build/integration release promoted from the verified v5.09.1 FIX8 lineage.

## Release identity changes
- Application version advanced to **5.10**.
- Build name identifies **TOOLBOX INTEGRATED**.
- Windows installer output: `WINGO_v5.10_Setup.exe`.
- Portable output: `WINGO_v5.10_PORTABLE.zip`.
- Windows file/product version: `5.10.0.1`.
- Integrated WINGO TOOLBOX remains v1.0.2.

## Functional baseline retained
- FYERS + Upstox unified re-login hardening.
- Auth/network/websocket-stale separation.
- DPAPI/commercial security hardening.
- Cython native parity fix.
- Self-contained Windows MSVC activation and Toolbox converter integration.
- Trading, profitability, paper, risk and feed-routing logic are not intentionally changed by this version increment.

## Runtime boundary
Windows Nuitka/Inno Setup compilation and authenticated live-broker validation remain target-machine checks.

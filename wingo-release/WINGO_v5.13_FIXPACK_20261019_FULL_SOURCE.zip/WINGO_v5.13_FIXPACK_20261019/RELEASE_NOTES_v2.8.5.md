# WINGO v2.8.5 — Live Feed Recovery

## Root cause / behavior fixed

FYERS access tokens are daily. A token that worked yesterday can be invalid
the next morning. Previous WINGO Live Feed opened the WebSocket directly and
displayed provider authentication failures as a generic ERROR.

## Changes

- Local JWT expiry inspection before WebSocket startup.
- Read-only FYERS profile validation before opening the Data WebSocket.
- Live Feed status sequence:
  AUTH CHECK -> AUTH PASS -> CONNECTING -> CONNECTED ->
  SUBSCRIPTION SENT -> SUBSCRIBED.
- Expired/invalid token becomes explicit `AUTH EXPIRED`.
- Authentication shortcut added to Live Feed page.
- Server control/error dictionaries are no longer silently ignored.
- Subscription acknowledgement drives SUBSCRIBED state instead of optimistic UI.
- Duplicate symbols are removed before subscription.
- Access token remains in required `appid:accesstoken` WebSocket format.
- Error path stops the failed socket and restores retry controls.
- Live feed object is cleared on thread finish.
- Token generation stores only a non-secret `FYERS_TOKEN_GENERATED_AT`
  operational timestamp.
- No token/auth-code value is logged.

Execution remains locked.

# WINGO v5.00 RC dev3 — Full MCX Universe Candidate

## Scope
- Based on the verified v5.0.0-rc1.1 Full MCX Universe build.
- Version/build identity promoted to **v5.00 RC dev3**.
- Full active MCX scanner universe remains enabled; no hidden four-symbol allowlist.
- Full-MCX compatible Auto Paper and Profitability Evidence behavior is retained.
- NSE/MCX Signal Lifecycle isolation, Paper exchange ownership, MCX cost model, router generation fencing, session/holiday policy and contract-expiry safety are retained.
- Live Execution remains **LOCKED** and Stage 8 remains absent.

## Internal version identifier
`APP_VERSION = "5.00-RC-dev3"`

## Verification
This candidate must pass the inherited full-MCX, safety, signal-isolation, MCX-runtime, multi-exchange, canonical-F&O and predecessor regression suites before packaging.

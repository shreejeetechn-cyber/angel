# WINGO v3.4.4 - Final Session Readiness Gate

- Added an automatic fail-closed Session Readiness gate to the Profitability
  Data Matrix.
- Live-session READY requires a live provider, data age within 15 seconds,
  NIFTY/BANKNIFTY/VIX values, at least 70% breadth coverage, populated scanner
  rows, and Futures/Options results not older than 15 minutes.
- Outside market hours the gate reports ARMED only when auto-run is enabled,
  safe-start is off, one provider health check passes and execution is locked.
- Missing requirements show exact WAIT reasons; safe-start or disabled
  auto-run produces BLOCKED.
- Session readiness is included in Profitability Lab diagnostics.
- v3.4.3 stale-signal blocking and v3.4.2 Mode 2 remain intact.
- NSE-only scope is retained; BSE is excluded and live execution is locked.

# WINGO v3.7.18 clean_sorted

## Scope

This release addresses the GUI stalls captured during a 213-symbol manual full
RSI scan on 24 August 2026. Trading/scoring rules are unchanged and real broker
execution remains locked.

## Stability changes

- Crash-resume scanner checkpoints are coalesced on a daemon background writer.
- High-frequency checkpoints use `%LOCALAPPDATA%\WINGO\scanner_checkpoint` on
  Windows, avoiding OneDrive file-lock contention.
- A running scan writes one latest checkpoint; dated copies are reserved for
  terminal STOPPED/FAILED/SHUTDOWN states.
- Scanner rows are rendered in 200 ms batches with table repaint suppression.
- Scanner footer refresh is capped at four updates per second.
- Dashboard refresh is skipped while hidden and capped during an active scan.
- Dashboard scanner-history reads use an in-memory cache.
- Market-regime persistence is coalesced off the GUI thread.
- Completed full-snapshot/history persistence also runs off the GUI thread and
  reports its final PASS/WARN state back into session diagnostics.
- Upstox history requests use identity encoding, bounded connect/read timeouts
  and deterministic response closing.

## Packaging

- Runtime, launcher and README identity: `3.7.18 clean_sorted`.
- Clean archive entries are emitted in deterministic sorted order.
- Python caches, bytecode, runtime state, credentials and tokens are excluded.

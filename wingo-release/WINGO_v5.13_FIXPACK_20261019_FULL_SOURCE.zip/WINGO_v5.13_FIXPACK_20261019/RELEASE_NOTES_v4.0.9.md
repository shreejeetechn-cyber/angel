# WINGO v4.1.19

Dashboard density release.

- Compact status area fixed to 111 px.
- Exactly four horizontal information rows.
- Borderless/flat dashboard header surfaces.
- Market index information consolidated to one line per index.
- AI state consolidated to one line.
- Summary metrics and scan state consolidated to one line.
- Previous AI, paper-trading, learning, alerts and live-execution-lock behavior retained.

# WINGO v4.0.3 autonomous_ai_trade_planner

## RSI Intelligence Scanner → Strategy / Spread Inspector reliability

- Fixed Scanner rows opening an empty-looking Strategy / Spread Inspector when no autonomous `overall_best` strategy was attached.
- Scanner inspection now accepts the ranking engine's cached `analysis.best` recommendation (and first cached recommendation as a guarded fallback), not only the auto-paper routing winner.
- When no strategy exists yet, selecting **View Strategy / Legs** requests one on demand through WINGO's existing serialized Futures + Options analysis engine when live/provider prerequisites are satisfied.
- The inspector remains open while analysis is queued/running and refreshes automatically when legs become available.
- Scanner-only rows now show grade, direction, classification, bucket, score and M/W/D RSI plus a clear strategy-status message instead of an empty-looking legs area.
- WINGO still never fabricates option/futures legs. If market/provider/master conditions prevent analysis, the inspector reports the actual reason.
- Live execution remains locked; this change affects analysis/inspection only.

## Version identity

Runtime, launchers, README, package folder and current QA/release filenames are v4.0.3.

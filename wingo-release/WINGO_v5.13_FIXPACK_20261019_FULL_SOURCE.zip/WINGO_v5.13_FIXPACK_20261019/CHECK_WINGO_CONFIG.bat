@echo off
setlocal
cd /d "%~dp0"
set "SEARCH=%CD%"
set "ROOT="
:find
for %%I in ("%SEARCH%") do set "NAME=%%~nxI"
if /I "%NAME%"=="Wingo" (
  set "ROOT=%SEARCH%"
  goto found
)
for %%I in ("%SEARCH%\..") do set "NEXT=%%~fI"
if /I "%NEXT%"=="%SEARCH%" goto fallback
set "SEARCH=%NEXT%"
goto find
:fallback
for %%I in ("%CD%\..") do set "ROOT=%%~fI"
:found
echo WINGO root: %ROOT%
echo Shared venv: %ROOT%\.venv
echo Shared env : %ROOT%\.env
if exist "%ROOT%\.env" (echo ENV STATUS: EXISTS) else (echo ENV STATUS: MISSING)
echo.
pause

# WINGO v2.8.16 — Data Integrity + Paper Mark Guard

Build: **WINGO v2.8.16 Data Integrity + Paper Mark Guard (Execution Locked)**

## Why this release
The v2.8.15 AI diagnostics export exposed two integrity failures that needed hard guards before further paper automation trust: a numeric-leading Futures underlying (`360ONE`) was being truncated to `3`, and multi-leg paper positions could evaluate SL/Target after only one leg received a fresh tick.

## Futures / FYERS symbol integrity
- Fixed Futures underlying parsing so `NSE:360ONE26AUGFUT -> 360ONE` and other numeric-leading names are preserved.
- Cached Futures Master rows are re-derived from the exact FYERS futures symbol, repairing stale `underlying=3` cache entries.
- Added conservative local FYERS symbol validation before REST/WebSocket use. With a current F&O universe, corrupted equity symbols such as `NSE:3-EQ` are rejected locally.
- Dynamic subscription plans now retain rejected-symbol reason telemetry.
- FYERS WebSocket `-300 Please provide a valid symbol` is classified as a symbol warning; it no longer automatically labels an otherwise usable socket as reconnecting.
- Deterministic Futures symbol-integrity failures trip an Auto-10s circuit breaker to stop repeated bad REST calls/log spam.

## Multi-leg paper P&L integrity
- Entry prices are no longer treated as live leg marks.
- Every leg must receive a live mark before multi-leg P&L may drive auto exit.
- Leg marks must be coherent: maximum 20-second inter-leg skew and maximum 30-second oldest-mark age.
- Defined-risk multi-leg P&L is sanity-checked against max loss/max profit with a 10% tolerance. Impossible transient values are quarantined instead of becoming executable paper P&L.
- Persisted closed defined-risk positions are audited on startup. Impossible historical P&L is retained for audit but marked invalid and excluded from the daily realized-loss ledger/risk gate.
- Auto exit ignores WAITING_LEGS, STALE_LEG_MARKS and OUT_OF_BOUNDS positions.
- Repeated mark-guard warning logs are throttled.

## Options / Greeks integrity
- Provider rows where IV/Delta/Gamma/Theta/Vega are all numerically zero are labeled `UNAVAILABLE_ZERO_BUNDLE`; those values become unavailable instead of earning a false Greek score.
- Greek availability status propagates through liquidity candidates and strategy legs.

## Diagnostics / regime telemetry
- Logging severity now matches actual severity tokens instead of substrings inside field names such as `future_error` or `error_count`.
- AI Diagnostics now includes persisted market-regime weights, contribution breakdown and freshness.
- AI Diagnostics includes the current live-subscription plan and rejected local symbols/reasons.
- Signal export fields now include exact option symbol/strategy/asset/max-risk metadata.
- Paper export includes raw P&L, validity, mark status/issue, recent closed positions and quarantined positions.

## Environment and safety
- Requirements are unchanged from v2.8.15.
- Continue using the single shared root `.venv`; do **not** create a new environment for this build.
- Real execution remains locked.

## Local Windows acceptance
1. Extract this build under the existing Wingo tree and run `START_WINGO.bat`.
2. If the old impossible paper loss is present, confirm it is quarantined and no longer alone triggers `DAILY_LOSS_LIMIT`. Genuine valid daily losses still apply.
3. Load/refresh Futures Master and select `360ONE`; confirm the underlying remains `360ONE` and no `NSE:3-EQ` request appears.
4. Enable Auto 10s Futures refresh; confirm normal snapshots do not repeat the old symbol-integrity failure.
5. Confirm the live subscription plan contains no malformed symbols; if a local reject occurs, it should be explicit in the next AI diagnostics export.
6. For a new multi-leg paper position, confirm P&L/auto-exit waits until all legs have coherent live marks and no impossible giant transient P&L can close the trade.
7. Refresh Market Breadth, export AI Diagnostics, and confirm the report includes `market_regime` contributions/freshness plus `live_subscription_plan`.

## Verification boundary
Python compile/static/synthetic integrity tests passed in the build container. Actual PySide6 rendering/click behavior and live FYERS REST/WebSocket behavior were not executed here; those require the user's Windows/FYERS session acceptance.

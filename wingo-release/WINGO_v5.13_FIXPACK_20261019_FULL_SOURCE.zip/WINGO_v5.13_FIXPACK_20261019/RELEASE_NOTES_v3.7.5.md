# WINGO v3.7.5 Release Notes

## Data Integrity & Dashboard Hotfix

- Scanner insufficient monthly history is now a **BLOCKED / INSUFFICIENT_HISTORY** evidence state instead of a scan error. NIFTYFPI remains visible but cannot produce scoring/signals until the minimum monthly sample exists.
- Removed fixed scanner pacing that added large deterministic delay. Provider-aware short pacing remains, and transient provider/rate-limit retry logic remains authoritative.
- FYERS `-300` invalid-symbol handling remains isolate-only: exact/positively probed invalid symbols are blocked; anonymous or network failures never quarantine by guess.
- FYERS DNS/transport failures are classified separately as `NETWORK_WARN`, preserve desired symbol/depth plans, and enter reconnect flow.
- Added documented FYERS REST `depth()` payload validation (`ohlcv_flag=1`) and asynchronous depth payload self-test. A WebSocket depth ACK alone is no longer treated as proof of usable order-book data.
- FYERS depth `volume` / `ord` level fields and `totalbuyqty` / `totalsellqty` totals normalize into the existing order-flow model without modifying Profitability calculation engines.
- BANKNIFTY dashboard header now uses guarded canonical/fresh tick binding and can show a fresh verifier-provider mark for dashboard observability instead of remaining silent. Missing/stale states are explicit.
- Read-only market breadth/regime telemetry is allowed during Safe Start. Safe Start still blocks automatic execution/resume behavior.
- First accepted live tick can arm market breadth during market hours; Regime now exposes LIVE/STALE/INCOMPLETE and scanner-day context instead of silently showing old persisted data.
- Dashboard heatmap refresh tolerates malformed/missing RSI values instead of allowing one row to abort the refresh.

## Safety

- Real broker execution remains locked.
- Application source contains zero `.place_order()` calls.
- Protected Profitability calculation modules, execution gate and resilience core remain byte-identical to v3.7.4.

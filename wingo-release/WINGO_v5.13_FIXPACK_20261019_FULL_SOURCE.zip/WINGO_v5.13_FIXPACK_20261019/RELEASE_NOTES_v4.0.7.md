# WINGO v4.0.7 autonomous_ai_trade_planner

## Purpose
Correct the v4.0.6 Dashboard header so the real Qt implementation follows the approved neon reference image rather than only approximating its color direction.

## Changes
- Exact one-line operational composition: compact WINGO brand, SESSION, PRIMARY/ACTIVE, LAST FULL SCAN, UPDATED, ALARMS, F/U/D provider states.
- Runtime refresh paths no longer wipe the custom dashboard styles.
- SESSION/connection/scan/update labels use rich inline state coloring.
- Provider and alarm badges preserve high-opacity neon borders after refresh.
- Three market cards retain equal layout with teal/blue/purple accents and larger values.
- BANK NIFTY sparkline binding remains corrected.
- Live execution remains locked.

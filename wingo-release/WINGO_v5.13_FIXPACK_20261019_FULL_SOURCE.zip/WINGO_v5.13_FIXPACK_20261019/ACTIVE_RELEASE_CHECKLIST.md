# WINGO ACTIVE RELEASE CHECKLIST

Current release: **v5.13 AUTO UPDATE BOOTSTRAP**

## Offline source/build-kit gates
- [x] Release metadata targets 5.13 / 5.13.0.0
- [x] Live execution remains LOCKED
- [x] v5.13 canonical regression 82/82
- [x] v5.13 startup dependency regression 18/18
- [x] Auto-update client transactional QA PASS
- [x] Master Toolbox client-update QA PASS
- [x] Commercial packaging tools QA PASS
- [x] Commercial security QA PASS
- [x] WINGO client tree contains no update signing private key
- [x] Pinned dedicated update public key present
- [x] Wrong-base/corrupt/path-traversal packages rejected
- [x] Rollback + interrupted-update recovery validated synthetically

## Windows release-PC gates
- [ ] Build `WINGO.exe` + `WINGOUpdater.exe` with `BUILD_COMMERCIAL_WINDOWS.bat`
- [ ] Build `WINGO_v5.13_Setup.exe`
- [ ] Run final customer-dist security scan
- [ ] Verify SHA256SUMS on exact customer outputs
- [ ] Clean Windows install / activation / restart
- [ ] Compiled v5.13 -> next-version `.wupd` end-to-end update
- [ ] Real UAC + rollback + power-loss recovery test

## Connected runtime gates
- [ ] FYERS/Upstox login and live feed
- [ ] NSE/MCX fresh LTP and reconnect
- [ ] Real broker margin/economics checks
- [ ] Windows GUI heartbeat under live load

**Rule:** Source/build-kit PASS is not the same as compiled Windows runtime certification. Do not represent pending Windows/live-session gates as offline PASS.

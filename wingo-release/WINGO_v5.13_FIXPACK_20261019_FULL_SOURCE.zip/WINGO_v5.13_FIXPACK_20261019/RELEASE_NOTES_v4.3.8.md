# WINGO v4.3.8 — Profitability Intelligence Merge + Web Phase 5

This release merges the v4.2.13 Profitability Intelligence Blocks Hotfix onto the
v4.3.7 Web Phase 5 wiring/compact-GUI and v4.3.3 runtime-stability architecture.
It does not add broker execution authority.

## Restored v4.2.13 Profitability correctness

- Selected-script RSI Intelligence follows the first selected Profitability timeframe.
- TIMEFRAME / source / bar count / READY or NOT READY are shown explicitly.
- RSI14, EMA5, EMA13, slope, RSI-MACD/signal, Stoch RSI, EMA gap, Bollinger and lifecycle come from that selected timeframe.
- Intraday history still loading never silently substitutes Daily RSI values.
- RSI Graph uses the same selected timeframe and RSI series.
- Matrix refresh signatures cover every displayed matrix field plus selected-timeframe RSI detail.
- Alert summaries use journal-generation caching and one-pass active-symbol indexing.
- Shadow full-table rendering is lazy and only runs while the Shadow tab is visible.
- Performance and Paper blocks use full payload signatures so secondary metric changes cannot remain stale.

## Retained v4.3.3+ stability

- Live Profitability/CVD analytics remain on the dedicated WINGO-ProfitabilityAnalytics worker.
- GUI snapshots never drain the heavy analysis queue; the legacy drain_pending=False API is accepted as a nonblocking compatibility contract.
- Bounded rebuild slices, reverse alias lookup, O(1) CVD deduplication, Signals pre-filtering and Session Status signal guards remain intact.

## Retained Web Phase 1–5

- Authenticated localhost Web workspace, Login/Logout, CSRF and WebSocket remain intact.
- Phase-5 Profitability, Paper/P&L and Session Health projections remain wired.
- Refresh All Workspaces and compact desktop-parity browser UI remain intact.
- Profitability visible refresh remains Manual/custom-minute; default Manual cadence is 5 minutes.

## Safety

- Live Execution remains LOCKED.
- Stage 8 remains absent.
- No broker place_order call is introduced.

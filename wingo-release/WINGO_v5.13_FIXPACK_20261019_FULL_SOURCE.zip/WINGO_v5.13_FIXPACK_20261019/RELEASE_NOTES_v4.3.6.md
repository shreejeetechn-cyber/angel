# WINGO v4.3.6 Release Notes

**Build:** WINGO v4.3.6 Web Phase 5 Operational Workspace Parity (Live Execution Locked)

## Added
- Authenticated **Profitability Lab** browser workspace.
- Authenticated **Paper & P&L** workspace with positions, account/P&L summary and ledger projection.
- Authenticated **Session Health & Alerts** workspace.
- New protected endpoints: `/api/v1/operations`, `/api/v1/profitability`, `/api/v1/paper`, `/api/v1/session-health`.
- Truthful Phase-5 snapshot liveness states: READY / STALE / OFFLINE / MISSING.
- Bounded, sanitized desktop operational snapshot published through the existing local disk bridge.

## Preserved
- Web Phase 1 provider/routing dashboard.
- Web Phase 2 Scanner, Signals and Scheduled Entries workspace.
- Web Phase 3 safe localhost control plane.
- Web Phase 4 Login / Session / CSRF / Logout boundary.
- v4.3.3 Runtime Stability Hotfix architecture.
- Profitability Manual / 5-minute visible refresh policy.
- `C:\Wingo\.venv`, `C:\Wingo\.env` and shared `.wingo_state` conventions.

## Safety
No browser route submits broker orders or mutates Paper positions. Stage 8 is absent and live execution remains LOCKED.

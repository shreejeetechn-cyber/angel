# WINGO v3.5.0 - Complete Superpage Data Matrix

- Added persistent `COMPACT SUPERPAGE` and `ADVANCED MATRIX` presets.
- Compact mode is the default and exposes the decision-first mockup column set.
- Combined Stoch K/D into one compact sortable column.
- Added display-only STRONG LONG / STRONG SHORT / LONG / SHORT / NEUTRAL labels.
- Added green/red/amber cell-level semantic colours.
- NIFTY and BANKNIFTY cards now show direction; INDIA VIX shows level and
  rising/falling state.
- Coverage card now shows breadth/data coverage as the main value and average
  evidence coverage separately.
- Added NSE-only, paper/shadow, execution-lock, educational and auto-refresh
  footer indicators.
- Detached Superpage opens maximized for multi-monitor use.
- Retained the complete advanced matrix, six detailed tabs, automatic Session
  Readiness, 15-second stale blocking and all v3.4 provider bridges.
- Live execution remains locked and BSE remains excluded.

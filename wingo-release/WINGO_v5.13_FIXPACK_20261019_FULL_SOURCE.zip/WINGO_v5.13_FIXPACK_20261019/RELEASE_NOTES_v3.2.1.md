# WINGO v3.2.1 — Settings Persistence Hotfix

Build: `WINGO v3.2.1 Settings Persistence Hotfix (Execution Locked)`

## Corrected runtime failure

WINGO v3.2.0 could receive many `sectionResized` notifications while a table
layout was restored or resized. Each notification immediately attempted an
atomic write to the centralized `Wingo\.wingo_state\settings.json`. On Windows,
OneDrive or antivirus could briefly lock the destination during
`os.replace(...)`, producing `PermissionError: [WinError 5] Access is denied`
and the WINGO Runtime Error dialog.

## Hotfix behavior

- One in-process lock now serializes writes to each persisted JSON path.
- Atomic replace retries bounded transient Windows access/sharing violations.
- Each retry still uses a same-directory temporary file; the old valid JSON is
  preserved if every retry fails.
- Temporary files are removed after success or failure.
- Table layout writes use a 400 ms debounce, coalescing resize/sort event bursts.
- Layout restore is completed before persistence signals are connected, so
  startup restoration does not write settings back to disk.
- Layout persistence is non-critical UI state. A final filesystem failure is
  recorded by the controller without terminating WINGO.
- Pending table layout changes are flushed once during clean shutdown.
- Manual Settings save shows a retryable warning when a persistent external
  lock remains, instead of raising an unhandled exception.
- Scanner checkpoints/snapshots reuse the hardened atomic JSON writer.

## Compatibility and safety

- Existing centralized `.env`, `.venv` and `.wingo_state` are reused unchanged.
- Existing `settings.json` and table layout schema remain compatible.
- No cache or user state needs to be deleted for this hotfix.
- All v3.2.0 analysis, signal, paper-account, ledger and provider behavior is
  preserved.
- Real broker execution remains locked.
- BSE-related products remain excluded.

## Installation

Extract the package directly under:

`C:\Users\surya\OneDrive\Desktop\Shoonya_OI_Tracker\Wingo`

Start with `START_WINGO.bat`. Do not copy credentials into the extracted
project folder; WINGO continues to read the common `Wingo\.env`.

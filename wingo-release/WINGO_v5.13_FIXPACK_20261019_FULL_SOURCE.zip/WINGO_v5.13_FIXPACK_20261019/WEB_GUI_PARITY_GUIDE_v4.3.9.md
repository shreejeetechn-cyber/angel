# WINGO Web GUI Parity Guide — v4.3.9

The desktop Qt interface is the visual source of truth. The Web Phase-5 interface is intentionally compact and uses the same semantic colours, dimensions and typography where browser layout permits.

## Exact parity contracts

| Surface | Desktop | Web v4.3.9 |
|---|---:|---:|
| Expanded sidebar | 225 px | 225 px |
| Collapsed sidebar | 64 px | 64 px |
| Navigation row | 44 px min | 44 px min |
| Workspace bar | 38 px min | 38 px |
| Status footer | 38 px min | 38 px |
| Global font | Arial | Arial |
| Operational table font | 11 px | 11 px |
| Table header padding | 6 px 7 px | 6 px 7 px |
| Table cell padding | 3 px 6 px | 3 px 6 px |
| Compact control height | 26 px min | 26 px |

## Theme parity

Web palettes are exact semantic copies of `app/ui/theme_presets.py` for:

- Midnight Dark
- Royal Blue
- Royal Green

When desktop WINGO is connected, its current `ui_theme` is published through the local control heartbeat and the Web UI mirrors that theme automatically.

## Intentional differences

Browser-only Login/Logout, session state and WebSocket status have no desktop equivalent and remain visible in the workspace bar. The browser still exposes only the Phase-1–5 Web workspaces and safe allow-listed controls; it does not recreate every desktop page and does not unlock execution.

## Safety

Live execution remains LOCKED. Stage 8 is absent. Theme/UI parity does not add broker order, Paper mutation or credential routes.

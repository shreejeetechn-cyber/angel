# WINGO Web Phase 3 — Local Control Plane

## Start order

1. Keep the build inside the existing `C:\Wingo` structure.
2. Start desktop WINGO with `START_WINGO.bat`.
3. Start the browser control plane with `START_WINGO_WEB.bat`.
4. Open `http://127.0.0.1:8787/` if the browser does not open automatically.

Phase 3 uses the existing centralized `C:\Wingo\.env`, shared `C:\Wingo\.venv`, and central `.wingo_state` directory.

## New Phase 3 Control Center

The browser can request only these desktop actions:

- Full NSE F&O Scan
- Incremental priority Scan
- Stop Scan
- Profitability Lab manual refresh
- Market Breadth refresh
- Signals workspace refresh
- Scheduled Entries workspace refresh

The desktop process remains the sole owner of the trading/scanner/analytics runtime. Browser commands are passed through an allow-listed local disk bridge and expire after 5 minutes if they are not executed.

## Desktop bridge state

- `ONLINE`: a fresh desktop heartbeat was seen within 8 seconds; safe controls are enabled.
- `OFFLINE`: desktop WINGO is not running or its event loop is not producing the Phase 3 heartbeat; controls are disabled.
- Recent command state is shown as PENDING/RUNNING/PASS/FAIL.

## Profitability refresh

The existing Profitability visible refresh policy is unchanged. Manual mode still uses the configured minute cadence (default 5 minutes). A browser Profitability Refresh is an explicit manual request only; continuous live analytics remain on the dedicated v4.3.3 background worker.

## Safety boundary

Phase 3 does not expose broker order placement, Paper order creation, broker login/token entry, auth secrets, Stage 8, or any execution-unlock switch. Live execution remains LOCKED.

## Stop

Close browser tabs as needed. Use `Ctrl+C` in the web launcher window to stop the web server. Stop desktop WINGO normally from the desktop application.

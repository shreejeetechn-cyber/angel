# WINGO v4.1.20 — Stage 0 Precalculation

This release implements the first controlled stage of the profitability-first
roadmap. It changes Paper position admission; it does not promise profitable
trades and it does not enable live broker execution.

## Implemented

- Added a pure pretrade calculation module with signed multi-leg executable
  cashflows, immutable-style receipts, expiry and final repricing.
- Corrected the historical net-P&L cost double deduction.
- Removed score-as-currency and forced profitability promotion paths.
- Isolated insufficient-sample A/A+ bootstrap candidates as non-admissible
  Shadow observations.
- Added a final exact-contract BID/ASK reprice immediately before Auto Paper
  position creation.
- Added independent Paper Engine enforcement for automatic admission receipts.
- Added manual profitability-first preflight and final calculation.
- Kept all existing risk, cash, freshness, contract-lock and portfolio gates.
- Kept live execution locked.

## Safety semantics

The engine admits an Auto Paper trade only when a fresh final receipt says
`TRADE`, matches the signal and contract lock, is not research-only, and retains
expected net rupees per lot above the configured minimum. Every other result is
fail-closed and creates no position.

## Verification

- `qa/verify_v4_1_20_stage0_precalculation.py`
- v4.1.19 Paper acceptance and profitability regression suites
- v4.1.19 dashboard, focus, lifecycle and 82-point regression suites


# WINGO v3.7.8 — Profitability Indicator Controls + Dynamic Footer

## Scope

v3.7.8 is based on the verified v3.7.6 line (not the forced-OFF v3.7.7 experiment), so AI Diagnostics remains user-configurable and manual Export AI Diagnostics remains available.

## Profitability Page Indicator Header

- New **BASE — RSI 14** checkbox.
- Optional indicators: **BB 20,2, EMA5, EMA13, MACD, STOCH RSI, DIVERGENCE, EMA GAP, LIFECYCLE**.
- Fresh/default state: every indicator is ON.
- **ALL** toggles all optional indicators while Base RSI remains independently selectable.
- **Reset Default** restores every indicator to ON.
- User selections are persisted in Profitability Lab settings and restored after restart.
- Controls are **presentation/analysis visibility only**. Existing profitability score, acceptance, strategy selection and execution logic are unchanged.

## RSI Bollinger Status

The Profitability RSI panel now displays strict BB(20,2) presentation status using a complete 20-RSI window:

- NOT READY
- INSIDE BB
- CROSS ABOVE UPPER
- ABOVE UPPER
- CROSS BELOW LOWER
- BELOW LOWER
- RE-ENTERED FROM UPPER
- RE-ENTERED FROM LOWER

BB Upper, Mid and Lower values are shown when BB is enabled. The existing engine lifecycle/scoring behavior is not changed by this display helper.

## Graph / Matrix Behavior

- RSI, BB(20,2), EMA5 and EMA13 respond on the RSI graph.
- RSI/MACD/Stoch/Divergence/EMA Gap/Lifecycle checkboxes control their corresponding RSI Intelligence rows and matrix columns where applicable.
- Arial-first 10 px styling is used for the compact indicator strip and footer for Windows readability.

## Dynamic Footer

The Profitability footer now reports live page state, including:

`RSI14 ON/OFF | IND x/8 | BB status | REGIME label/confidence | selected script`

and on the right:

`AUTO-REFRESH | primary provider | LIVE/AGING/STALE | data age | clock`

## Shutdown Stability Hardening

The Profitability matrix/shadow chunk renderers now use weak queued callbacks, widget-destroyed generation invalidation and deleted-Qt-object guards. This directly addresses the previously observed shutdown race where a queued matrix callback touched a deleted `QTableWidget`.

During an intentional application shutdown, the crash report/log evidence is still preserved, but a secondary modal runtime-error dialog is suppressed so it cannot itself create a watchdog hang.

## Preserved Safety / Data Integrity

- Real broker execution remains locked.
- `.place_order()` calls in application source: **0**.
- v3.7.5 BANKNIFTY/Regime/FYERS-depth/NIFTYFPI safeguards remain intact.
- v3.7.6 compact dashboard/readability behavior remains intact.
- AI Diagnostics is **not forced OFF** in this build.

## Verification

See `QA_v3.7.8_PROFITABILITY_INDICATOR_CONTROLS.txt` and the full per-suite log.

### Environment limitation

Headless source/logic/regression QA is exhaustive for the packaged source, but this environment does not have PySide6/Windows GUI runtime. Final native Windows interaction (visual checkbox clicks, font rendering and close choreography) should still be observed on the target machine.

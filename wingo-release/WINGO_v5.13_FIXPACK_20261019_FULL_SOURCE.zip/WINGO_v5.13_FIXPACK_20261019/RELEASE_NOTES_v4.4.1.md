# WINGO v4.4.1 — Profitability Signature Stability Hotfix

Base: WINGO v4.4.0 full desktop-web parity.

## Fixed
- Restored the missing `@staticmethod` decorator on `ProfitabilityLabPage._row_refresh_signature`.
- Fixes runtime crash: `TypeError: ProfitabilityLabPage._row_refresh_signature() takes 1 positional argument but 2 were given`.
- Added a binding audit/regression guard so methods called as `self.<method>(...)` cannot silently lose their required binding/decorator contract.

## Retained
- Web Phase 6 desktop-web parity architecture.
- v4.2.13 selected-timeframe Profitability Intelligence.
- v4.3.3 background Profitability analytics/CVD stability protections.
- Live execution remains locked (LOCKED); Stage 8 remains absent.

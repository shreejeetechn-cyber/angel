# WINGO v4.0.2 autonomous_ai_trade_planner

## Strategy / Spread Inspector

- Scanner now includes **View Strategy / Legs** and double-click opens the inspector.
- Paper Trading > Positions now includes **View Strategy / Legs** and double-click opens the same inspector.
- Scanner view attaches the best current generated strategy/signal for the selected underlying. If no strategy has been generated, WINGO explicitly reports that instead of inventing legs.
- Paper view shows the actual opened position and its linked signal side-by-side.
- All strategy legs show entry price, live BID, ASK, LTP, bid/ask quantity, executable close side/price, leg P&L, P&L %, bid-ask spread, quote age and provider.
- Executable valuation is strict: BUY/long legs close at BID; SELL/short legs close at ASK. LTP is display-only and is never silently substituted for a missing executable quote.
- Debit and credit spreads share one signed spread/cashflow calculation and display entry spread/credit, current executable spread/buyback, spread change and total gross P&L.
- Signal details include lifecycle state, quality, score, entry/stop/target references, market/script trend, alignment, reason and selection reasons.
- Position details include actual fill/current net, capital, margin source, stop/target P&L controls, trailing status and reconciliation state.
- Existing v4.0.1 Cash Holdings and runtime round hotfix are retained.

## Safety

- Inspector is read-only. It does not place broker orders.
- Live execution remains locked.

### Responsive Inspector hotfix
- Strategy / Spread Inspector now sizes itself to the active screen's usable work area.
- Wide leg details scroll horizontally inside the leg table instead of expanding the dialog.
- Signal/Position and Risk/Reason panels stack on narrow screens.
- Spread/P&L metric cards reflow from 6 to 4, 3, or 2 columns as width decreases.
- This is a layout bugfix only; runtime version remains v4.0.2.

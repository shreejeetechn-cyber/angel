# WINGO v2.8.14 — FYERS Data Integrity + True Breadth

## Confirmed FYERS Option Chain v3 contract
- Option Chain requests now send `greeks=1`.
- Nested `greeks.iv` is parsed correctly with Delta/Gamma/Theta/Vega.
- Preserves `prev_oi`, `oich`, `oichp`, option price change, expiry W/M flags, India VIX, aggregate Call/Put OI, and the embedded underlying/future-price row.
- PCR OI is explicitly Put OI / Call OI and prefers FYERS aggregate totals.

## Futures Snapshot reliability
- Exact requested futures contract is mandatory; no silent Near-expiry substitution.
- Missing contract triggers one Futures Master refresh and exact retry; a persisted active-contract cache is available if master download fails.
- FYERS Market Depth with `ohlcv_flag=1` is the primary futures-price/OI/OHLC/bid-ask source.
- Quotes is futures-price fallback and remains the spot-price source.
- Batched Quotes retries individually only for missing symbols.
- FYERS `pdoi` / `oipercent` are preferred for OI change; WINGO previous snapshot is fallback.
- Last-good price fallback is displayed as STALE and cannot create a fresh Futures signal.

## True F&O Advance/Decline
- Breadth now fetches the individual-stock F&O universe via FYERS Quotes in batches of 50.
- ADVANCE = positive daily change; DECLINE = negative daily change; UNCHANGED = zero.
- Shows A/D ratio, net breadth %, and quote coverage.
- Snapshot persists to `.wingo_state/market_breadth.json`.
- Auto refresh every 90 seconds after FYERS Health PASS while market is open.

## Regime integrity
- Regime = 60% true breadth + 30% COMPLETE scanner baseline + 10% live NIFTY/BANKNIFTY confirmation.
- Partial scanner progress is never used as market breadth.
- Breadth coverage <70% => DATA INCOMPLETE; breadth older than 180s => DATA STALE. Both are non-directional and contribute zero strategy bias.
- Confidence is HIGH/MEDIUM/LOW using coverage/freshness/confirmations.
- India VIX is shown as volatility context but does not fabricate directional bias.
- Regime may modify Futures/Options recommendation scores only within a bounded +/-10 points; it never hard-overrides instrument evidence.

## Safety
- Real execution remains locked.
- Last-good/stale market data is display continuity only and cannot trigger a new Futures trade signal.

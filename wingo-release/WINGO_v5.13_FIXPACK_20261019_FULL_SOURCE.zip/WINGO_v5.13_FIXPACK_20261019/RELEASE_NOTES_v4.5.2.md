# WINGO v4.5.2 — Exclusive UI + Web-App Stability

Base: v4.5.1 Cross-Version Exclusive Unified Core.

## Implemented
- One active control GUI at a time: DESKTOP or WEB; Core remains continuous.
- Web control lease with heartbeat/expiry; second browser session cannot silently steal an active Web lease.
- Desktop→Web switch hides Desktop rendering; Web→Desktop performs one deferred repaint + AutoFit.
- `START_WINGO_ALL.bat` retired to prevent simultaneous Desktop/Web interactive control.
- Browser-native Web shell with grouped navigation, proper routes, browser history, responsive Grid/Flex layout, sticky tables and WebSocket status.
- Legacy Qt mirror retained only as a compatibility adapter for pages not yet backed by native domain endpoints; Desktop geometry/scale canvas is no longer the primary Web renderer.
- Hidden Desktop presentation work suppressed while WEB/NONE owns UI control.
- Live tick GUI ingress reduced to 1,000 raw events/slice and visible repaint capped to 120 symbols/slice.
- Signal live-reference lookup indexed by symbol; Signals table Qt rendering budgeted to ~5 ms/slice.
- Full Web workspace/dashboard `deepcopy()` removed via copy-on-write snapshots; WebSocket adds Core metadata using a shallow top-level copy.
- Cross-version run-state polling moved off the Qt MainThread.
- 30-second startup watchdog grace prevents Web-first/hidden-Desktop startup false-positive hang reports.
- FYERS subscription changes coalesced/rate-limited; warning-driven subscribe/unsubscribe churn receives bounded hold/retry handling.
- Profitability automatic second-monitor pop-out is disabled permanently by default. Manual Pop Out remains available.
- Web launcher no longer triggers hidden Desktop AutoFit.
- Live execution remains LOCKED; Stage 8 remains absent.

## Operational model
- `START_WINGO.bat`: Core ensure + Desktop control.
- `START_WINGO_WEB.bat`: Core ensure + browser; Web claims control after login unless Desktop currently owns it.
- Browser can explicitly switch control to Web.
- Web can explicitly switch control back to Desktop.
- Core continues while either UI is hidden/closed; explicit Core shutdown is separate.

# WINGO v5.0.0-dev2.1 — MCX Runtime Hotfix

Targeted repair on top of v5.0.0-dev2. No live execution capability is added.

## Repairs
- FYERS keyed JSON masters preserve the top-level provider symbol instead of discarding it.
- FYERS current named fields supported: `symTicker`, `exInstType`, `optType`, `strikePrice`, `minLotSize`, `tickSize`, `expiryDate`, `underExSymbol`.
- MCX acceptance refreshes the active exchange on every run and supplies the Upstox mapper to the MCX scanner universe.
- MCX runtime diagnostics expose FYERS/Upstox/common FUTURE-underlying counts and option-underlying counts.
- MCX option acceptance selects only underlyings that actually have active CE/PE contracts.
- Upstox history failures now expose exact instrument key, date range, raw candle count and HTTP status/error detail.
- Roadmap Closure reports WARN when implementation is complete but operational evidence is incomplete; it no longer presents `evidence=0/8` as a clean PASS.
- Scanner snapshot metadata persists MCX provider-universe coverage.

## Safety
- Canonical tradable `FnoInstrument` remains FUTURE/OPTION only.
- `FUTURE_PROXY` remains reference-only.
- Live Execution remains LOCKED.
- Stage 8 remains ABSENT.
- Profitability Auto Pop Out remains disabled.

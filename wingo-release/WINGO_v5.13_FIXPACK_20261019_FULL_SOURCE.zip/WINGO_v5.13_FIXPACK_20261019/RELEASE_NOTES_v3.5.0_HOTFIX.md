# WINGO v3.5.0 - Numerical/Data-Integrity Hotfix

This maintenance patch keeps the public runtime version at v3.5.0 and corrects
calculation/data-flow issues found during the post-build audit.

- Session VWAP now anchors from provider ATP plus cumulative volume when available.
- A mid-session cumulative baseline without ATP is no longer presented as a full-session VWAP.
- Repeated LTQ is not re-counted when cumulative volume is present but unchanged.
- Futures OI scoring now handles long buildup, short buildup, short covering and long unwinding consistently.
- Futures OI is paired with Futures price change when the derivative snapshot supplies both.
- FYERS/Upstox daily change percentage now reaches the Profitability Lab; Relative Strength can also derive it from LTP vs previous close.
- Paper automation applies configured slippage on both entry and exit fills.
- Acceptance summary only reports overall PASS when all summarized rows pass, while `candidate_available` separately reports whether any strict candidate exists.
- `START_WINGO.bat` now displays the v3.5.0 Complete Superpage build label.
- Live execution remains locked; no broker order-submission path was added.

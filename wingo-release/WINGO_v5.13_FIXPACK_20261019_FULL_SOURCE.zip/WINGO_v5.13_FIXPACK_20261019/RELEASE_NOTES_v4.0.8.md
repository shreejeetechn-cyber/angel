# WINGO v4.0.8

Dashboard-only refinement requested by operator:
- 30% colored border opacity.
- 12px centered dashboard header typography.
- Exactly two horizontal dashboard header lines.
- Three market cards remain equal and centered.
- Runtime feed/alarm refresh preserves the new opacity.
- Live execution remains locked.

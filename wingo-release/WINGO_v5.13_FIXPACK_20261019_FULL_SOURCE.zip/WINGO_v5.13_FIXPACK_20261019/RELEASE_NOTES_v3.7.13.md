# WINGO v3.7.13 — Profitability Matrix Readability

## Scope
Presentation/readability upgrade only for the Profitability Lab matrix. No trading, scoring, lifecycle, VWAP, flow, profitability-validation, or execution logic is changed.

## Matrix views
- `DECISION` is the default daily-use view.
- `RSI` focuses on RSI-family structure and lifecycle.
- `FLOW` focuses on VWAP, OI, E-CVD, depth, scores and data quality.
- `ALL 39` keeps the complete audit matrix.
- Legacy `SUPERPAGE` / `ADV MATRIX` saved settings migrate to `DECISION` / `ALL 39`.

## Cell-data auto fit
- Visible columns are sized from representative visible cell data, not from header length.
- Up to 60 visible rows are sampled and the 90th-percentile data width is used.
- Width caps prevent one long outlier from expanding the table.
- `Gate Reasons` has a larger safe cap and full content remains available by tooltip.
- Headers wrap inside the fitted cell width, up to three lines.
- No continuous `ResizeToContents`; automatic refit is limited to first/major load, view/indicator changes, quick-filter changes, reset, or explicit `AUTO FIT`.

## Quick matrix controls
- `PASS` — Candidate PASS only.
- `A+/A++` — top grades only.
- `CONFIRMED` — CONFIRMED or MOMENTUM STRONG lifecycle only.
- `FRESH` — current-session fresh lifecycle only, including rebuilt fresh cycles.
- `BEST FIRST` — presentation sort by Acceptance, Grade, Lifecycle, Freshness, Coverage, then Symbol.
- `AUTO FIT` — immediate cell-data refit.
- `RESET` — returns to DECISION with quick filters/presentation sorting cleared.

## Color-code safety
- Existing `_matrix_cell_color()` is byte-identical to v3.7.12.
- `app/ui/main_window.py`, including the global theme palette, is byte-identical to v3.7.12.
- Existing matrix/background/header color literals remain unchanged.
- New matrix toolbar controls inherit WINGO's existing button styling; no new color stylesheet is introduced.

## Protected logic
Byte-identical to v3.7.12: acceptance gate, Profitability score, indicator scanner, RSI intelligence, Fresh Lifecycle tracker/engine, VWAP engine/acceptance, cumulative delta, depth/order-flow state, strategy engine, shadow/performance analytics and weight optimizer.

## Safety
- FYERS SDK remains pinned to `fyers-apiv3==3.1.16`.
- Broker `.place_order()` calls: **0**.
- Real execution remains **LOCKED**.

## Verification
- 31 / 31 QA suites PASS.
- 816 PASS checks.
- 149 / 149 Python files compile.
- Color-code preservation QA PASS.
- Protected Profitability logic hashes PASS.
- Target Windows/PySide rendering remains the final native-environment check.

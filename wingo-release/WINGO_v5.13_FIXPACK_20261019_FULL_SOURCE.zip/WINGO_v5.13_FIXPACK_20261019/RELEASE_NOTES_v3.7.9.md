# WINGO v3.7.9 — Fully Functional Profitability Indicator Scanner Controls

## Scope

v3.7.9 upgrades the Profitability-page indicator checkboxes from presentation controls to full scanner controls.

### Checkbox contract

- **ON** = indicator is visible and participates in the Profitability scanner.
- **OFF** = indicator is hidden and excluded from the Profitability scanner.
- **RSI 14 is the Base indicator.** Turning Base RSI OFF automatically turns every RSI-derived child indicator OFF and disables those child controls.
- **ALL** toggles the optional child indicators only while Base RSI is ON.
- **Reset Default** restores Base RSI and all optional indicators to ON.
- Selection persists across restart.

### Scanner participation

The active RSI-family set is evaluated as an auditable confluence layer:

- RSI14
- BB(20,2)
- RSI EMA5
- RSI EMA13
- RSI MACD
- Stoch RSI
- Divergence
- EMA Gap
- Lifecycle

Unchecked indicators are removed from the confluence numerator/denominator and do not create missing-data penalties.

The selected confluence now participates in:

1. the RSI-family contribution to the Profitability score,
2. the selected-indicator scanner consensus gate,
3. lifecycle state logic where the corresponding indicator is enabled,
4. strict acceptance qualification,
5. strategy lifecycle gating when Lifecycle is enabled.

Lifecycle is intentionally excluded from the upstream RSI score to prevent circular scoring; it remains a downstream scanner/acceptance/strategy gate.

### Base RSI OFF behavior

Base RSI OFF removes the complete RSI-derived family from active scanning. The independent non-RSI families (market/sector context, VWAP, E-CVD, depth, OI) remain available and are renormalized rather than penalized for an intentionally disabled RSI family.

### UI / status

The Profitability footer now reports:

`SCANNER <PASS/BLOCK/WAIT/DISABLED> | ACTIVE n/9 | CONS xx% | BB <status> | REGIME ... | SEL ...`

The selected-script detail panel reports the active scanner state and consensus. Existing row/column/chart hide/show behavior remains tied to the same checkboxes.

### Safety

- Real broker execution remains locked.
- Application contains **0** broker `.place_order()` calls.
- v3.7.8 shutdown-safe matrix/shadow rendering protections are retained.
- AI Diagnostics remains user-configurable/manual-export capable; the forced-OFF v3.7.7 experiment is not inherited.

## QA

- 27 / 27 QA suites PASS
- 708 PASS assertions
- 144 / 144 Python files compile
- 0 compile failures
- 0 `.place_order()` calls
- Exact delivery ZIP is re-extracted and the same QA is rerun before release.

Native PySide6 is not installed in the build container, so final visual click/paint behavior remains a Windows target-machine acceptance item.

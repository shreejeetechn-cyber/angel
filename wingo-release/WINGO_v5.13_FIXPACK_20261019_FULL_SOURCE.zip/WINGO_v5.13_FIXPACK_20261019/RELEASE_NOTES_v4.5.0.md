# WINGO v4.5.0 — Unified Core Runtime + AutoFit Clean GUI

Base: WINGO v4.4.1 Profitability Signature Stability Hotfix.

## Unified Core

- Added a singleton localhost Core control endpoint on `127.0.0.1:8788`; binding this port is the single-instance lock.
- Embedded the authenticated Web server (`127.0.0.1:8787`) inside the same WINGO process as the proven Desktop engine.
- `START_WINGO.bat`, `START_WINGO_WEB.bat`, `START_WINGO_ALL.bat` and direct `main.py`/`web_main.py` entry points all start-or-attach to the same runtime.
- Web-first startup creates the Core with the Desktop window hidden. A later Desktop launch shows the same already-running runtime.
- Desktop-first startup starts the same Core with the Desktop visible; a later Web launch attaches and opens the browser.
- Closing the Desktop window hides it instead of stopping feeds/workers/Core.
- Added explicit `START_WINGO_CORE.bat`, `HIDE_WINGO_DESKTOP.bat`, and `STOP_WINGO_CORE.bat`.
- Reset/restart uses a singleton-safe deferred restart helper.
- The existing FYERS/Upstox feed/scanner/Profitability/Paper ownership remains in exactly one runtime; Web never opens a second broker socket.

## AutoFit clean GUI

- Added `UniversalTableController.clean_autofit_all()` and startup AutoFit for every registered Desktop table while preserving sort/filter/visibility choices.
- Web GUI includes **AutoFit GUI** enabled by default and scales the mirrored Desktop canvas responsively to the browser width.
- Existing Arial/compact table controls, themes, A-/A+, Focus, Copy, Export and Reset remain available.

## Retained stability/security

- v4.4.1 `_row_refresh_signature` binding hotfix retained.
- v4.2.13 selected-timeframe Profitability Intelligence retained.
- v4.3.3 background Profitability analytics/CVD isolation retained.
- Sensitive Web auth/broker fields remain memory-only/redacted.
- Stage 8 remains absent. Live Execution remains LOCKED.

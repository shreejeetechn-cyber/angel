# WINGO v3.6.2 — Roadmap Stability Hotfix

This release is a narrow runtime/UI stability follow-up to v3.6.1. It is based
on a real Windows hang/native-fault report captured by the Resilience Shield.
It does not change Profitability Lab scoring, lifecycle, VWAP/OI/CVD engines,
strategy selection, OOS validation, paper logic, or execution policy.

## Fixed from real field diagnostics
- Removed the custom `QTableWidgetItem.__lt__` comparator from the Profitability
  Data Matrix. Native Qt matrix sorting stays disabled; column sorting is now a
  stable Python-side row sort before rendering.
- Universal Table Tools respects externally sorted tables, including saved sort
  layout, ascending/descending actions and clear-sort behavior.
- RSI Intelligence, Market & Sector Context and Derivatives Context no longer
  depend on the 300-row matrix render completing. Selected-script detail is
  populated before wide-table rendering begins and again as its row appears.
- The three compact evidence panels are no longer subject to persisted row-hide
  or row-filter state. They show `SELECT A SCRIPT` initially and explicit N/A
  states if selected detail is unavailable instead of rendering as blank blocks.
- Runtime project/root/state/log paths are resolved once per process rather than
  invoking Windows/OneDrive `realpath` from live-tick status paths.
- Market holiday override is loaded once per session instead of stat/read calls
  from the live UI path.
- Heavy Profitability Lab market/sector/readiness context is coalesced to at most
  roughly 1 Hz while every accepted market tick still reaches VWAP/order-flow.
- Dashboard full refresh bursts are coalesced to a 500 ms cadence.
- Anonymous FYERS `-300` symbol warnings put subscription-plan changes on a
  bounded 15-second hold instead of repeated full unsubscribe/resubscribe churn.
  WINGO quarantines a symbol only when FYERS explicitly names the exact invalid
  candidate; it never guesses which member of an anonymous batch is invalid.

## Resilience retained
- Dedicated crash/hang/native reports remain enabled.
- Abnormal-exit Safe Start remains enabled.
- Watchdog remains diagnostic-only; it does not kill/restart WINGO.
- Live broker execution remains LOCKED.

## Development-roadmap position
v3.6.2 is a stability/UI hotfix inside the existing v3.6 development phase. It
does not start a new profitability phase and does not alter research-model
semantics. Real Windows market-hours acceptance testing remains required.

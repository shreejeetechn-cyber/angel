# WINGO v3.6.4 — Independent Window Zoom

This is a presentation-only follow-up to v3.6.3 inside the existing v3.6 Profitability Lab development phase. It fixes the field-reported behavior where zooming the detached Profitability Lab also changed the Main Dashboard.

## Independent window scaling
- Main WINGO and Profitability Lab Pop-Out now have separate zoom scopes.
- `Ctrl + Mouse Wheel`, `Ctrl + +`, `Ctrl + -`, and `Ctrl + 0` affect only the window under focus/mouse ownership.
- Main zoom continues to use the existing `ui_scale_percent` setting.
- Pop-Out zoom uses a separate `profitability_popout_ui_scale_percent` setting.
- First Pop-Out use inherits the current Main zoom only as its initial default; after that the two values persist independently.
- `Ctrl + Shift + Mouse Wheel` is an explicit optional convenience to step all registered WINGO windows together.
- QApplication font is no longer globally mutated, preventing zoom leakage between top-level windows.
- Scaling is applied only to the registered root window and its child pages/widgets.
- Main Dashboard keeps its own `ZOOM n%` footer indicator; Profitability Pop-Out now has its own `ZOOM n%` toolbar indicator/reset.

## Compatibility and safety
- v3.6.3 responsive scaling range remains 80/90/100/110/120/130%.
- Settings persistence remains debounced at 450 ms.
- Profitability Lab draggable Matrix/Details and RSI/Market/Derivatives splitters remain unchanged.
- v3.6.2 native sorting crash fix remains unchanged.
- v3.6.1 Crash/Hang Shield remains unchanged.
- Profitability calculations, market-data feeds, scoring, lifecycle, VWAP, OI, CVD, depth, strategy, OOS validation, paper automation and execution policy are unchanged.
- Live broker execution remains locked.

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "SEARCH=%CD%"
set "WINGO_ROOT="
:find_root
for %%I in ("%SEARCH%") do set "NAME=%%~nxI"
if /I "%NAME%"=="Wingo" (set "WINGO_ROOT=%SEARCH%"&goto found)
for %%I in ("%SEARCH%\..") do set "NEXT=%%~fI"
if /I "%NEXT%"=="%SEARCH%" goto fallback
set "SEARCH=%NEXT%"
goto find_root
:fallback
for %%I in ("%CD%\..") do set "WINGO_ROOT=%%~fI"
:found
set "PY=%WINGO_ROOT%\.venv\Scripts\python.exe"
"%PY%" -m app.core.unified_launcher --hide-desktop
endlocal

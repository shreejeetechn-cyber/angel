# WINGO Web Phase 4 — Authenticated Local Workspace

## Start order

1. Keep the build inside the existing `C:\Wingo` structure.
2. Start desktop WINGO with `START_WINGO.bat`.
3. Start the browser workspace with `START_WINGO_WEB.bat`.
4. Open `http://127.0.0.1:8787/`.

Phase 4 continues to use the shared `C:\Wingo\.venv`, centralized `C:\Wingo\.env`, and central `C:\Wingo\.wingo_state` directory.

## First login

If `WINGO_WEB_PASSWORD` is not configured, WINGO generates an 18-character random first-run password. The launcher prints it and writes a temporary copy to:

`C:\Wingo\.wingo_state\web_auth\FIRST_RUN_WEB_LOGIN.txt`

The temporary plaintext file is deleted immediately after the first successful login. The persistent credential file stores only a PBKDF2-HMAC-SHA256 hash.

For a permanent centrally managed credential, add these optional values to `C:\Wingo\.env` and restart the web launcher:

- `WINGO_WEB_USERNAME=admin`
- `WINGO_WEB_PASSWORD=<your strong password>`
- `WINGO_WEB_SESSION_HOURS=8` (1–24 hours; default 8)

## Logout

The `Logout` button is in the top-right header. Logout invalidates only the WINGO Web browser session. It does **not** stop desktop WINGO, disconnect FYERS/Upstox, delete broker tokens, or alter paper/live runtime state.

## Security boundary

- Localhost only (`127.0.0.1` / `localhost`).
- HttpOnly + SameSite=Strict browser session cookie.
- CSRF token required for every authenticated state-changing REST call.
- Absolute session expiry; web-server restart also invalidates all browser sessions.
- Login failures are rate-limited.
- Web command history records the authenticated local web username.
- Broker order placement, broker secrets, Stage 8 and execution unlock remain unavailable.
- Live execution remains LOCKED.

## Phase 1–3 inheritance

Phase 4 retains provider status, market ribbon, Scanner, Signals, Scheduled Entries, WebSocket status, safe desktop control commands, desktop heartbeat gating, 5-minute command TTL, and the v4.3.3 runtime-stability architecture.

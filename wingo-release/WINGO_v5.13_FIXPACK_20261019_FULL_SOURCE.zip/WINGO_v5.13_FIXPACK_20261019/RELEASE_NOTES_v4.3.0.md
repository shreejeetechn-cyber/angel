# WINGO v4.3.0

## Local Web Dashboard — Phase 1

- Adds a standalone localhost browser interface while retaining the complete desktop application.
- Adds a FastAPI backend that produces credential-safe dashboard snapshots.
- Performs real read-only FYERS and Upstox REST authentication and index-quote checks every 30 seconds.
- Streams snapshots to the browser using WebSocket and falls back to REST polling after a browser-stream interruption.
- Shows NIFTY 50, BANK NIFTY and INDIA VIX only when the configured primary/failover decision has a verified provider.
- Adds provider-specific and all-provider manual health refresh actions.
- Uses a direct Upstox index-key check so Phase 1 does not download the full instrument master merely to populate the ribbon.
- Binds to `127.0.0.1` only and rejects non-local clients and Host headers.
- Keeps broker secrets server-side and redacts credential-like provider error text.
- Retains the 30-second recovery interval and 20-attempt provider reconnect limits.
- Retains v4.2.12 morning authentication, v4.2.11 stability and v4.2.10 Profitability MTF/manual refresh behavior.
- Live execution remains locked; Stage 8 remains absent.

## Not included in Phase 1

Scanner, Signals, Scheduled Entries, Profitability, Paper and Settings web pages are intentionally deferred to later phases. Their desktop implementations remain available.

# WINGO v2.9.0 — Historical Backtest Foundation

## Roadmap phase
Phase 10 starts with historical validation of the existing WINGO underlying scanner. This build intentionally does **not** fabricate historical option-chain premiums, Greeks, true breadth, transaction costs, margin, or broker execution.

## Non-look-ahead scanner replay
- Recomputes Daily / Weekly / Monthly RSI as-of each historical daily close.
- Weekly and monthly RSI include only the current partial period close available on that historical date; no future week/month close is leaked backward.
- Reuses the production scanner classification path (`classify`, price/volume/OBV features, `classify_extended`).
- Historical signals are emitted on **eligible directional state entry/re-entry**, suppressing repeated daily duplicates while the same qualifying state persists.
- Entry is the **next trading session open**, not the signal-day close.

## Validation controls
Backtest workspace supports:
- selected FYERS cash underlying, or current loaded WINGO F&O universe;
- date range (`YYYY-MM-DD`);
- RSI period;
- minimum grade `A+`, `A` (A/A+), or `B` (B/A/A+);
- direction filter `ALL`, `LONG`, `SHORT`;
- primary horizon 5 / 10 / 20 trading sessions;
- bounded universe maximum.

## Metrics
Every signal stores direction-adjusted forward returns for 1 / 3 / 5 / 10 / 20 trading sessions. Primary-horizon analysis includes:
- win rate;
- expectancy;
- median return;
- average win / average loss;
- profit factor (undefined/infinite when there are gains and no losses, rather than a numeric sentinel);
- MFE / MAE from daily high/low path;
- grade breakdown;
- LONG / SHORT breakdown;
- sequential signal-equity index and drawdown diagnostic.

The signal-equity diagnostic is **not** a capital-aware portfolio simulation because historical signals may overlap.

## FYERS history cache / reports
- Daily history is fetched in provider-safe chunks through the existing scanner history client.
- Per-symbol daily history is cached under `.wingo_state/backtest/history_cache/`.
- Cache stores requested coverage boundaries so weekend/holiday end dates do not force needless refetches.
- Warm-up automatically expands with the selected RSI period.
- Full result JSON and signal CSV are persisted under `.wingo_state/backtest/reports/`.
- Latest report is persisted as `.wingo_state/backtest/latest_backtest.json`.
- Backtest progress is persisted to `.wingo_state/backtest/progress.json`; GUI polls it once per second so long F&O-universe runs remain observable.
- Large backtest results are summarized in application logs instead of serializing the entire signal ledger into `wingo.log`.

## Diagnostics
AI Diagnostics includes a bounded `HISTORICAL BACKTEST SUMMARY` section with parameters, aggregate metrics, error sample and per-symbol sample. Full signal history remains in the backtest JSON/CSV report rather than consuming the diagnostics line budget.

## Preserved systems
- v2.8.17 one-FYERS-WebSocket transport architecture preserved.
- Paper multi-leg mark guard preserved.
- True F&O market breadth / regime preserved.
- FYERS Option Chain nested IV/Greeks handling preserved.
- Shared root `.venv` and `.env` architecture preserved.
- Real broker execution remains **LOCKED**.

## Verification boundary
Whole-project compile, AST/UI static audit and synthetic non-look-ahead/cache/universe tests pass in the build environment. PySide6 GUI rendering and live FYERS history calls could not be executed in the build container; Windows + live FYERS acceptance remains required.

# WINGO v4.2.7 — Clean AMIT Profitability Mode

- Adds a fifth Profitability Matrix preset: **AMIT**.
- Existing DECISION, RSI, FLOW and ALL 39 presets remain unchanged.
- AMIT is read-only/presentation-only and does not feed Profitability scoring, acceptance, Stage 0, Paper entry/exit or broker execution.
- Adds bounded daily price EMA5/EMA25 context sourced from existing scanner history.
- Adds RSI Bollinger lower/upper/status using the existing RSI series.
- Reuses Hybrid Aggressor CVD 1m/3m/5m/15m, MTF state and True Aggressor %.
- AMIT state shows BULLISH READY only when Price > EMA5 > EMA25, RSI re-enters from lower BB, and CVD MTF is bullish; bearish is the exact mirror. Otherwise it reports WATCH/WAIT with the factual reason.
- Price EMA context is DAILY scanner context; no intraday candle series is fabricated.
- Stage 8 remains absent and live execution remains locked.

# WINGO v4.0.0 autonomous_ai_trade_planner

## Autonomous Paper intelligence

- Risk-aware autonomous candidate evaluation is connected to the existing Paper entry funnel.
- Option-chain alternative generator uses executable BUY ASK / SELL BID and creates bounded vertical spreads without inventing missing prices.
- Every final planner cycle produces a complete selected/rejected decision passport.
- Auto Paper Entry and Exit remain ON; live broker execution remains locked.
- Controlled learning persists strategy/regime/sector evidence and Champion/Challenger state.
- Hourly and EOD TXT/JSON/CSV/HTML reports are generated under the centralized `.wingo_state/intelligence_reports` directory.

## Clean GUI

- New `AI Trade Intelligence` page has ten scrollable tabs and a non-overlapping sticky action footer.
- Dashboard has a dedicated AI status ribbon, AI Study shortcut, responsive card grid and clickable Paper Capital/P&L navigation.
- Paper Capital opens Account & Costs; Total P&L opens the persistent P&L Ledger.
- Universal table controls retain their dedicated toolbar row above every table header.
- Footer switches to compact theme labels and hides optional progress text at the minimum supported width.

## Margin and safety

- Upstox basket-margin and FYERS SDK margin adapters are available through one non-averaging margin authority.
- Provider failures use an explicitly unverified conservative fallback.
- Naked/undefined-risk selling, stale data, failed reconciliation and live execution remain protected boundaries.

This build optimizes Paper/Shadow policy only. It does not claim autonomous live trading or guaranteed profitability.

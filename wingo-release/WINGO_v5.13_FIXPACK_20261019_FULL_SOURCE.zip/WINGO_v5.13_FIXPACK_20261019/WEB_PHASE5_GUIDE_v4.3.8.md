# Web Phase 5 Wiring + Compact GUI — v4.3.8

Phase 5 retains authenticated localhost-only observation and safe operational control. v4.3.8 preserves the v4.3.7 compact wiring and merges the v4.2.13 Profitability Intelligence correctness/performance contracts without changing browser execution authority.

## Refresh All Workspaces
The header action now force-refreshes the Phase-2 persisted reader and, when desktop WINGO is online, queues `WORKSPACES_REFRESH_ALL`. Desktop WINGO refreshes Profitability, Signals and Scheduled Entries, then forces a new bounded Phase-5 projection. Paper/P&L and Session Health are projected directly from current runtime models.

## Compact parity
Default Web density follows desktop conventions: Arial, Midnight Dark semantic colours, 225px expanded / 64px collapsed sidebar, compact controls, thin table borders and 11px operational tables. Use the sidebar button or Ctrl+B to collapse/expand navigation.

## Safety
No broker order route, paper position mutation, credential export, or Stage-8 execution control is exposed. Live execution remains LOCKED.


## v4.3.8 Profitability Intelligence merge

- Selected-script RSI Intelligence uses the first selected timeframe and exposes TIMEFRAME / source / bars / READY state.
- Intraday selections never silently substitute Daily RSI while history is pending.
- RSI graph follows the same selected timeframe.
- Matrix signatures cover every displayed field plus selected-timeframe RSI detail.
- Alert summaries use generation caching and linear active-symbol indexing.
- Shadow full-table rendering is lazy and only runs when the Shadow tab is visible.
- Performance and Paper blocks use complete signatures.
- v4.3.3+ background Profitability analytics worker remains authoritative; GUI snapshots do not drain heavy queues.

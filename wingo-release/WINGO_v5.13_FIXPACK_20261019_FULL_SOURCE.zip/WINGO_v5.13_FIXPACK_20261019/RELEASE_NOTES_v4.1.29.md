# WINGO v4.1.29 — Unified Persistent Alert Journal & Matrix Status

This release prevents transient alerts from disappearing without an audit
trail and makes each script's alert state visible directly in Profitability
Matrix.

Windows startup hotfix:

- Alert timestamps use India's fixed UTC+05:30 offset without importing the
  optional IANA `tzdata` database during startup.
- This prevents `ZoneInfoNotFoundError: Asia/Kolkata` when `tzdata` was not
  installed into the active Windows virtual environment.
- `tzdata` remains listed in `requirements.txt`, but WINGO startup and alert
  history no longer depend on it.

RSI Divergence navigation hotfix:

- Double-clicking a divergence row now uses WINGO's central Futures router.
- Removed the invalid `fut_underlying` widget reference; the actual Futures
  selector is `fut_script` and is managed by the guarded router.
- If the Futures master is not ready, the existing sync-and-select workflow is
  used instead of raising an unhandled GUI exception.

Strategy / Spread Inspector connections:

- Added one central read-only Inspector route across Signals, Profitability
  Matrix, ranked Option strategies, RSI Divergence and Alerts.
- Added P&L Ledger and Backtest drill-down. Backtest records stay frozen as
  historical context and are never mixed with a live executable mark.
- Added diagnostic drill-down for MM Observer, Shadow MM, restricted Paper MM
  and Portfolio MM inventory. These views remain observation/simulation only.
- Inspector dialogs reuse existing feed/worker data and stay in the Qt GUI
  thread; no second GUI thread was introduced.
- Reopening the same context focuses its existing Inspector instead of creating
  duplicate windows and duplicate subscription pressure.
- Corrected Alert acknowledge/resolve selection to read the Alert Key column.

Persistent journal:

- Daily append-only JSONL files with 90-day retention.
- UTC and IST timestamps for every lifecycle transition.
- Stable cycle ID and unique event ID.
- Complete source, severity, script, signal, position, strategy, direction,
  entry, stop, target, current value, risk limit, message and context fields.
- A human-readable `single_line_summary` on every event.
- Duplicate refresh observations do not create duplicate `RAISED` cycles.
- Disappearing Dashboard alerts are stored as `RESOLVED`.

UI:

- Alerts page: `Active Alerts` plus `Permanent History`.
- History filters: script, severity, source and event action.
- Full JSON detail on hover and filtered CSV/JSONL export.
- Profitability Matrix `Alerts` column displays `A:x · T:y` or `CLEAR`.
- Static severity colour, no blinking.
- Aggregate `ALERTED | ACTIVE | CRIT | TODAY | SYSTEM` summary.
- Double-click an alert cell to open that script's permanent history.
- Double-click Matrix `Symbol` or `Best Strategy` to inspect its strategy.
- Double-click Signal, ranked Option, Backtest, P&L Ledger, Alert or MM inventory
  rows to open their corresponding read-only Inspector context.

Safety:

- This is observability/audit functionality only.
- No broker submission, automatic Live promotion or Live execution authority is
  added.
- Stage 0-7 roadmap closure remains intact and Live execution remains locked.

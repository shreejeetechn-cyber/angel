# WINGO v4.2.13 — Profitability Intelligence Blocks Hotfix

This release repairs the selected-script blocks below the Profitability Matrix
without changing trading scores, acceptance rules or broker execution authority.

## Selected-timeframe RSI block

- `RSI Intelligence` now identifies the first selected timeframe, source, bar
  count and readiness.
- RSI14, RSI EMA5/EMA13, slope, RSI-MACD/signal, Stoch RSI, EMA gap,
  Bollinger(20,2) and RSI lifecycle come from that selected timeframe.
- An intraday selection with history still loading shows `NOT READY`; it never
  silently substitutes Daily values.
- The RSI Graph uses the same selected timeframe and series.

## Refresh and responsiveness

- Matrix change detection covers every displayed field and selected-TF RSI detail.
- GUI snapshots no longer drain all pending MTF symbol rebuilds synchronously.
- Historical alert summaries are indexed linearly and cached by journal generation.
- Shadow rows arrive through normal controller status updates; the full table is
  rendered lazily only when its tab is visible.
- Performance and Paper blocks use full signatures and update on their active tabs.

## Retained safety

- v4.2.12 Upstox Analytics Token and official FYERS manual-TOTP browser flow remain intact.
- TOTP secrets, PINs and OTPs are not stored.
- Stage 0 through Stage 7 remain present; Stage 8 is absent.
- Live Execution remains locked and broker `place_order` calls remain zero.

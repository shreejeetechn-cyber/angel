# WINGO v5.13 Commercial Release Checklist

## Bootstrap update components
- [x] `app/updater/*` integrated
- [x] `wingo_updater_entry.py` integrated
- [x] dedicated update public key pinned in `assets/update_public_key.pem`
- [x] Dashboard update banner integrated
- [x] Settings → Updates integrated
- [x] local/LAN Future Update Folder support
- [x] manual offline `.wupd` support
- [x] detached updater-helper launch
- [x] transaction journal / backup / rollback / recovery
- [x] exact base-target + SHA256 + Ed25519 verification

## Windows packaging
- [x] builder metadata targets 5.13.0.0
- [x] `WINGOUpdater.exe` onefile Nuitka build step present
- [x] updater uses UAC admin manifest
- [x] customer artifact gate requires update public key and updater EXE
- [x] portable ZIP is created after executable signing
- [ ] execute Windows commercial build on release PC
- [ ] verify `WINGO_v5.13_Setup.exe`
- [ ] verify `WINGO_v5.13_PORTABLE.zip`
- [ ] verify real Authenticode signature if configured/required

## Master publishing
- [x] Universal Toolbox v2.3.0 CLIENT UPDATE creator
- [x] version-marker validation
- [x] signing-key/public-key match validation
- [x] package-first publication
- [x] `latest.json` published LAST
- [ ] retain signing private key only on secure Master/Admin PC
- [ ] back up signing private key securely before first production publication

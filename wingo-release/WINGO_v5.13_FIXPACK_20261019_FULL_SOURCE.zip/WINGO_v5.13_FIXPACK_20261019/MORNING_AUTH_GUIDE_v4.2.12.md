# WINGO v4.2.12 Morning Authentication Guide

## FYERS: normal morning login

1. In the broker developer application, register the same redirect URI used by `FYERS_REDIRECT_URI` in the common `.env`.
2. For automatic desktop capture, use an accepted URI such as `http://127.0.0.1:8765/callback`. Host, port and path must match exactly.
3. Start WINGO normally. When the saved token is missing or rejected, WINGO opens the official FYERS login once.
4. Enter TOTP/OTP on the official FYERS page. Do not enter it inside WINGO.
5. After the browser success page appears, return to WINGO. It captures the one-time code, generates the access token and starts validation automatically.
6. If automatic capture is unavailable, paste the complete redirect URL into **Paste FYERS redirect URL or auth_code**, then select **Generate FYERS Token**.

## FYERS: optional refresh-token renewal

1. If a refresh token is available, enter the current account PIN in the masked field.
2. Select **Renew with PIN**.
3. WINGO clears the field immediately and uses the PIN only for that request. It does not save the PIN.
4. If renewal fails or the refresh token has expired, use the normal official-browser login above.

## Upstox: recommended read-only Analytics Token

1. Generate an Analytics Token in the Upstox Developer Apps area.
2. Paste it into **Paste read-only Upstox Analytics Token**.
3. Select **Save Analytics Token**.
4. WINGO selects Analytics mode and validates the token against market data. The token is used only for the existing market-data paths; live order execution remains locked.

## Upstox: daily OAuth fallback

1. Select **Open Upstox Login**.
2. Complete the official broker login.
3. A registered loopback redirect is captured automatically. If it cannot be captured, paste the redirect URL and select **Generate Upstox Token**.

## Feed recovery behavior

- The supervisor checks recovery every 30 seconds.
- Each live provider retains up to 20 reconnect attempts.
- If one feed is unavailable, the configured provider/failover policy governs the other feed.
- If both feeds are stale or disconnected, WINGO does not invent data or unlock execution. It keeps status degraded/disconnected and waits for bounded recovery or fresh authentication.
- After the reconnect limit is reached, that socket cycle is abandoned. Correct authentication or connectivity, then use the existing manual reconnect/start control or restart WINGO to begin a fresh bounded cycle.

WINGO 5.11.1 - DASHBOARD READABILITY HOTFIX

Apply only to WINGO 5.11 source using Universal Toolbox SOURCE UPDATE.
Then perform a clean Windows build and create an INSTALLED_UPDATE by comparing the compiled 5.11 runtime with the compiled 5.11.1 runtime.

Scope is UI readability only:
- no dashboard layout redesign
- no Market Breadth graphics
- three Market Breadth rows only
- no ambiguous provider/status abbreviations
- Arial 10 minimum on compact dashboard/status text

Production keys, license database, broker credentials and user data are not included or modified.

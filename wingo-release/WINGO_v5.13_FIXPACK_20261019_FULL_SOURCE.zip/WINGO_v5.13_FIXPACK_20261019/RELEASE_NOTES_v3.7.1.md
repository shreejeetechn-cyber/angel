# WINGO v3.7.1 — Superpage Visual Parity

This is a **presentation-only refinement** of v3.7.0. It uses the approved Profitability Data Matrix mockup as the large-screen visual benchmark while retaining v3.7 responsive/resizable behavior.

## Compact Superpage changes
- Added the strong `WINGO | PROFITABILITY DATA MATRIX | MODE 2 - NUMERICAL` visual hierarchy.
- Compact scan matrix now matches the mock's **19-column** structure; Grade remains in the large Decision band rather than duplicating it in the matrix.
- Tighter terminal-style matrix/shadow styling: flatter panels, crisp grid lines, compact headers/rows, stronger selected-row contrast.
- Summary strip remains six cards on large screens and reflows at existing responsive breakpoints.
- Compact diagnostic subtitle and Session Readiness panel are hidden by default; all diagnostics remain available in Advanced mode.
- Filters are hidden by default in Compact mode and exposed by a small `Filters` control.

## Selected-script evidence parity
- RSI Intelligence now uses the paired four-column layout of the approved mock:
  - RSI14 / RSI Slope
  - RSI EMA5 / RSI-MACD
  - RSI EMA13 / Stoch K/D
  - EMA Gap / Divergence
  - RSI Lifecycle Status
- Market & Sector Context uses the compact five-row target set.
- Derivatives Context uses the compact six-row target set.
- All three evidence titles include the selected symbol.
- Directional evidence values use green/red/amber semantic hierarchy.

## Decision / reasons / validation
- Decision and Reasons now share one horizontal, mouse-resizable band like the approved visual target.
- Long Score is emphasized green; Short Score red; Grade/Bias/Strategy are semantically colored.
- Reasons use compact Segoe UI text rather than a generic code-editor treatment.
- Shadow Validation headers and directional value coloring follow the mock hierarchy.
- Decision/Reasons vs Shadow Validation remains vertically resizable.
- New splitter proportions persist; existing installations receive a one-time presentation-only migration to the v3.7.1 defaults.

## Preserved safety and behavior
- Profitability calculation engines are unchanged from v3.7.0.
- v3.6.2 custom-`__lt__` sorting crash fix remains intact.
- v3.6.1 Crash/Hang Shield remains unchanged.
- Main/Pop-Out independent UI density remains unchanged.
- Full-screen table Focus and mouse-resizable Dashboard remain unchanged.
- Live broker execution remains locked; no application `.place_order()` call exists.

## Known boundary
This environment cannot run the Windows PySide6 GUI, so visual parity is verified by source/layout contracts and regression checks. Final pixel/monitor acceptance should still be done on the user's Windows machine. The previously reported Factory Fresh `wingo.log` WinError 32 restart issue is **not** part of this visual release.

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title WINGO v5.10 TOOLBOX INTEGRATED Direct Commercial Builder
cls
echo ================================================================
echo WINGO v5.10 TOOLBOX INTEGRATED DIRECT WINDOWS BUILD - NO EXE CONVERTER
echo ================================================================
echo.
echo This launcher bypasses the external WINGO EXE CONVERTER completely.
echo Visual Studio activation is handled inside the PowerShell pipeline.
echo.
call BUILD_COMMERCIAL_WINDOWS.bat
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo [FAILED] Direct build returned exit code %RC%.
) else (
  echo [SUCCESS] Direct build completed.
)
echo.
pause
exit /b %RC%

# WINGO v2.8.9 — Startup Crash + Dashboard Lifetime Fix

The visible `dash_filter ... QComboBox already deleted` exception was a secondary error.

Root cause: v2.8.8 added `_option_underlying_key(symbol)` and `_option_expiry_label(value)` as MainWindow methods without `self` or `@staticmethod`. Calling them through `self` aborted `_build_ui()` while Options Workspace was being constructed. The temporary Dashboard page was then destroyed, but its timer was parented to MainWindow and survived, so later timer callbacks dereferenced dead Dashboard widgets.

Fixes:
- Both Options Workspace helpers are explicit `@staticmethod`.
- All project class methods are statically audited for this binding mistake.
- Dashboard timer is owned by the Dashboard page.
- Dashboard refresh checks page lifetime with `shiboken6.isValid()`.
- Dashboard filter mode is cached as plain Python state; timer refresh never dereferences the combo.
- Delayed dashboard refresh is ignored after page destruction/while closing.
- Runtime error dialog is single-instance to prevent modal error storms from recurring timers.

All v2.8.8 Options Workspace, Dashboard routing, Term Structure, Session Audit, and Paper Automation features remain present. Real execution remains locked.

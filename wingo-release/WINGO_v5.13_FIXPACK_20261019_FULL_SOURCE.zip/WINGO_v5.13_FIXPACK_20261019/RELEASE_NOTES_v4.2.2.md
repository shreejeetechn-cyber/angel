# WINGO v4.2.2 — Universal Page Pop-Out

WINGO now supports a manual multi-monitor workspace for every one of its 31
navigation pages while retaining a single set of live engines.

## Universal page workspace

- Choose a target display in the page toolbar and click **Pop Out Current
  Page**.
- Use the **Workspace** menu to focus, move, dock or dock all detached pages.
- Right-click any navigation button to open that page directly on a selected
  monitor.
- Use `Ctrl+Shift+P` to detach the current page and `Ctrl+Shift+D` to dock it.
- Each detached window includes Monitor, Next Monitor, Full Screen, Always on
  Top and Dock Back controls.
- Optional **Restore layout** reopens pages that were detached at the previous
  clean shutdown. Missing displays recover to the primary screen.

The actual page widget is moved between the main page stack and its detached
window. It is not duplicated, so feeds, scanner, signals, Paper positions,
alerts, risk and market-maker controllers remain single shared instances.

## Runtime integration

- Detached Dashboard refresh remains active.
- Detached Futures Snapshot and Option Chain selections remain in the dynamic
  subscription plan.
- Detached Alerts retains active/history refresh behavior.
- Safe Quit docks all live page widgets before timers and workers are frozen.
- Diagnostics reports page-registry/pop-out health and includes detached page
  tables in universal-table health checks.

## Dependency failure correction

The earlier crash report showed `ModuleNotFoundError: tzdata`, followed by an
`Asia/Kolkata` `ZoneInfoNotFoundError`. `START_WINGO.bat` now runs a
standard-library preflight across the complete pinned `requirements.txt`. If a
package is missing or mismatched, it repairs the existing shared `.venv`, then
verifies again before startup. This covers PySide6, dotenv, requests, FYERS,
Upstox and tzdata instead of checking only the two broker SDKs.

## Safety boundary

This release changes GUI placement and dependency reliability only. It adds no
broker submission path, does not promote a strategy and does not guarantee
profit. Live Execution remains locked.


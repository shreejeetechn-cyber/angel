# Web Phase 5 Wiring + Compact GUI — v4.3.7

Phase 5 retains authenticated localhost-only observation and safe operational control. v4.3.7 hardens field/liveness wiring and aligns the Web density with the desktop compact GUI.

## Refresh All Workspaces
The header action now force-refreshes the Phase-2 persisted reader and, when desktop WINGO is online, queues `WORKSPACES_REFRESH_ALL`. Desktop WINGO refreshes Profitability, Signals and Scheduled Entries, then forces a new bounded Phase-5 projection. Paper/P&L and Session Health are projected directly from current runtime models.

## Compact parity
Default Web density follows desktop conventions: Arial, Midnight Dark semantic colours, 225px expanded / 64px collapsed sidebar, compact controls, thin table borders and 11px operational tables. Use the sidebar button or Ctrl+B to collapse/expand navigation.

## Safety
No broker order route, paper position mutation, credential export, or Stage-8 execution control is exposed. Live execution remains LOCKED.

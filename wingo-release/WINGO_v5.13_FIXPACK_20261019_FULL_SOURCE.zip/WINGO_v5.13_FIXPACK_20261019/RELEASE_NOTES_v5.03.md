# WINGO v5.03 — MCX Futures Signal Decoupling

Base: WINGO v5.02 Profitability Policy v2 Verified

## Repair
- MCX Auto Strategy option lookup now uses the canonical commodity root (for example COPPER / CRUDEOIL) instead of the MCX FUTURE_PROXY spot alias, which intentionally has no fabricated spot symbol.
- Option discovery is guarded. Missing MCX option expiry/contracts no longer abort the entire Auto Strategy worker.
- Valid Futures snapshots continue into `_auto_strategy_success()` and can create FUTURE signals in `FUTURES-ONLY` mode.
- Strategy cache records `option_context_status`, lookup symbol and option-context errors for diagnostics.
- Futures rationale records `OPTION CONTEXT <status> — FUTURES-ONLY` when option enrichment is unavailable.
- Normal downstream profitability, trend, cash, risk and Paper admission controls remain unchanged.

## Retained
- Profitability Policy v2: OFF / ADVISORY / BALANCED / STRICT / AUTO.
- Full MCX universe and NSE + MCX dual-provider core.
- MainThread async hotfix and inline daily broker authentication.
- Live Execution LOCKED; Stage 8 absent.

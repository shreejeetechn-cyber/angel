@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title WINGO v5.13 Commercial Windows Builder

cls
echo ================================================================
echo        WINGO v5.13 COMMERCIAL WINDOWS BUILDER
echo ================================================================
echo.
echo This window will stay open on SUCCESS or ERROR.
echo Build folder: %CD%
echo.

rem -----------------------------------------------------------------
rem Basic prerequisites - fail visibly instead of closing instantly.
rem -----------------------------------------------------------------
where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Windows PowerShell was not found.
  goto :FAIL
)

where py.exe >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python Launcher ^(py.exe^) was not found.
  echo Install Python 3.12 x64 on the BUILD PC and enable the Python launcher.
  goto :FAIL
)

py -3.12 -c "import sys; print(sys.executable); assert sys.version_info[:2] == (3,12)" > "%TEMP%\wingo_pycheck.txt" 2>&1
if errorlevel 1 (
  echo [ERROR] Python 3.12 x64 is required on the BUILD PC.
  type "%TEMP%\wingo_pycheck.txt" 2>nul
  goto :FAIL
)
echo [OK] Python 3.12 detected.

set "ISCC="

rem 1) Already available on PATH.
for /f "delims=" %%I in ('where ISCC.exe 2^>nul') do if not defined ISCC set "ISCC=%%I"

rem 2) Standard all-users install locations.
if not defined ISCC if defined ProgramFiles(x86) if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if defined ProgramFiles if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

rem 3) Winget/current-user install location.
if not defined ISCC if defined LOCALAPPDATA if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"

rem 4) Registry discovery (HKCU/HKLM, including 32-bit uninstall registry).
if not defined ISCC (
  for /f "usebackq delims=" %%I in (`powershell.exe -NoProfile -Command "$roots=@('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'); $p=$null; foreach($r in $roots){ if(Test-Path $r){ Get-ChildItem $r -ErrorAction SilentlyContinue ^| ForEach-Object { $v=Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue; if(-not $p -and $v.DisplayName -like 'Inno Setup*' -and $v.InstallLocation){ $c=Join-Path $v.InstallLocation 'ISCC.exe'; if(Test-Path $c){ $p=$c } } } } }; if($p){Write-Output $p}"`) do if not defined ISCC set "ISCC=%%I"
)

if not defined ISCC (
  echo [ERROR] Inno Setup 6 was installed but ISCC.exe could not be located.
  echo.
  echo Run this PowerShell command and send the output if it still fails:
  echo   Get-ChildItem "$env:LOCALAPPDATA\Programs","$env:ProgramFiles","${env:ProgramFiles(x86)}" -Recurse -Filter ISCC.exe -ErrorAction SilentlyContinue ^| Select-Object -ExpandProperty FullName
  echo.
  goto :FAIL
)

echo [OK] Inno Setup 6 detected: %ISCC%
echo.

rem 5) FIX6: MSVC detection/activation is performed inside the PowerShell
rem build pipeline itself. Do NOT invoke VsDevCmd.bat from this wrapper.
rem This avoids nested quoting failures in GUI launchers/converters.
echo [INFO] MSVC activation will be handled by packaging\BUILD_WINDOWS_COMMERCIAL.ps1.
echo.

rem -----------------------------------------------------------------
rem If both variables already exist, use them. Otherwise present a menu.
rem -----------------------------------------------------------------
set "ALLOW_LOCALHOST="
if defined WINGO_LICENSE_PUBLIC_KEY if defined WINGO_LICENSE_SERVER_URL goto :VALIDATE_LICENSE_INPUTS

:MODE_MENU
echo Choose build mode:
echo.
echo   [P] PRODUCTION  - real Ed25519 public key + HTTPS license server
echo   [L] LOCAL TEST  - auto-generate local keys; use http://127.0.0.1:9443
echo                     NOT for customer distribution.
echo   [Q] Quit
echo.
choice /C PLQ /N /M "Select P, L or Q: "
if errorlevel 3 goto :CANCELLED
if errorlevel 2 goto :LOCAL_TEST
if errorlevel 1 goto :PRODUCTION

goto :MODE_MENU

:PRODUCTION
echo.
echo PRODUCTION BUILD selected.
echo Example public-key path:
echo   C:\secure\wingo-license-keys\license_public_key.pem
echo.
set /p "WINGO_LICENSE_PUBLIC_KEY=Enter FULL path to license_public_key.pem: "
if not defined WINGO_LICENSE_PUBLIC_KEY (
  echo [ERROR] Public-key path cannot be empty.
  goto :FAIL
)
set /p "WINGO_LICENSE_SERVER_URL=Enter HTTPS license server URL: "
if not defined WINGO_LICENSE_SERVER_URL (
  echo [ERROR] License server URL cannot be empty.
  goto :FAIL
)
set "ALLOW_LOCALHOST="
goto :VALIDATE_LICENSE_INPUTS

:LOCAL_TEST
echo.
echo LOCAL TEST BUILD selected.
echo This mode is only for owner/development testing.
echo.
set "LOCAL_KEY_DIR=%CD%\.local_license_keys"
set "LOCAL_KEY_VENV=%CD%\.license-keygen-venv"
set "WINGO_LICENSE_PUBLIC_KEY=%LOCAL_KEY_DIR%\license_public_key.pem"
set "WINGO_LICENSE_SERVER_URL=http://127.0.0.1:9443"
set "ALLOW_LOCALHOST=-AllowHttpLocalhost"

if exist "%WINGO_LICENSE_PUBLIC_KEY%" (
  echo [OK] Existing local development public key found.
  goto :VALIDATE_LICENSE_INPUTS
)

echo [STEP] Creating isolated key-generation environment...
if not exist "%LOCAL_KEY_VENV%\Scripts\python.exe" (
  py -3.12 -m venv "%LOCAL_KEY_VENV%"
  if errorlevel 1 (
    echo [ERROR] Could not create the key-generation virtual environment.
    goto :FAIL
  )
)

"%LOCAL_KEY_VENV%\Scripts\python.exe" -m pip install --disable-pip-version-check "cryptography>=46.0,<47.0"
if errorlevel 1 (
  echo [ERROR] Could not install cryptography for local key generation.
  goto :FAIL
)

"%LOCAL_KEY_VENV%\Scripts\python.exe" "%CD%\tools\generate_license_keys.py" --out "%LOCAL_KEY_DIR%"
if errorlevel 1 (
  echo [ERROR] Local Ed25519 key generation failed.
  goto :FAIL
)

if not exist "%WINGO_LICENSE_PUBLIC_KEY%" (
  echo [ERROR] Local public key was not generated as expected.
  goto :FAIL
)

echo.
echo [WARNING] Local private key created at:
echo   %LOCAL_KEY_DIR%\license_private_key.pem
echo Keep it private. Do NOT copy it into a customer build.
echo.

goto :VALIDATE_LICENSE_INPUTS

:VALIDATE_LICENSE_INPUTS
if not exist "%WINGO_LICENSE_PUBLIC_KEY%" (
  echo [ERROR] License public key not found:
  echo   %WINGO_LICENSE_PUBLIC_KEY%
  goto :FAIL
)

if /I "%WINGO_LICENSE_SERVER_URL:~0,8%"=="https://" goto :INPUTS_OK
if /I "%WINGO_LICENSE_SERVER_URL%"=="http://127.0.0.1:9443" (
  set "ALLOW_LOCALHOST=-AllowHttpLocalhost"
  goto :INPUTS_OK
)
if /I "%WINGO_LICENSE_SERVER_URL%"=="http://localhost:9443" (
  set "ALLOW_LOCALHOST=-AllowHttpLocalhost"
  goto :INPUTS_OK
)

echo [ERROR] Production license URL must use HTTPS.
echo Local test mode may use only localhost/127.0.0.1.
echo Entered: %WINGO_LICENSE_SERVER_URL%
goto :FAIL

:INPUTS_OK
echo.
echo ================================================================
echo BUILD INPUTS
echo ================================================================
echo Public key : %WINGO_LICENSE_PUBLIC_KEY%
echo License URL: %WINGO_LICENSE_SERVER_URL%
if defined ALLOW_LOCALHOST echo Mode       : LOCAL TEST ^(not for distribution^)
if not defined ALLOW_LOCALHOST echo Mode       : PRODUCTION
echo ================================================================
echo.
echo [STEP] Starting commercial build...
echo The detailed compiler/pip output will appear below.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\packaging\BUILD_WINDOWS_COMMERCIAL.ps1" -LicensePublicKey "%WINGO_LICENSE_PUBLIC_KEY%" -LicenseServerUrl "%WINGO_LICENSE_SERVER_URL%" -InnoSetupCompiler "%ISCC%" %ALLOW_LOCALHOST%
set "BUILD_RC=%ERRORLEVEL%"

if not "%BUILD_RC%"=="0" (
  echo.
  echo ================================================================
  echo [BUILD FAILED] Exit code: %BUILD_RC%
  echo ================================================================
  echo Read the LAST error shown above.
  echo No successful installer should be assumed from this run.
  goto :FAIL_PAUSE
)

if not exist ".commercial_build\out\WINGO_v5.13_Setup.exe" (
  echo.
  echo [ERROR] Build process returned success but Setup.exe was not found.
  goto :FAIL_PAUSE
)

echo.
echo ================================================================
echo [SUCCESS] WINGO COMMERCIAL BUILD COMPLETE
echo ================================================================
echo Output folder:
echo   %CD%\.commercial_build\out
echo.
echo Expected files:
echo   WINGO_v5.13_Setup.exe
echo   WINGO_v5.13_PORTABLE.zip
echo   WINGOUpdater.exe
echo   SHA256SUMS.txt
echo   BUILD_REPORT.txt
echo   SECURITY_SCAN_FINAL.json
echo.
start "" explorer.exe "%CD%\.commercial_build\out"
echo Press any key to close this builder.
pause >nul
exit /b 0

:CANCELLED
echo.
echo Build cancelled by user.
echo Press any key to close.
pause >nul
exit /b 0

:FAIL
echo.
echo ================================================================
echo [PRE-BUILD CHECK FAILED]
echo ================================================================
:FAIL_PAUSE
echo.
echo The window is being kept open so you can read the error.
echo Press any key to close.
pause >nul
exit /b 1

# WINGO v3.7.2 — Slim Market Ribbon

A presentation-only hotfix on top of v3.7.1 Superpage Visual Parity.

## Profitability Page
- NIFTY 50, BANKNIFTY, INDIA VIX, BREADTH, COVERAGE and DATA AGE now remain in one slim horizontal ribbon on normal desktop and Profitability Pop-Out widths.
- The ribbon switches to a 3-column fallback only below 680 px.
- Market cards are capped at 52 px height with denser spacing and compact typography, preserving vertical space for the Profitability Data Matrix.
- All v3.7.1 visual-parity layout, independent Pop-Out density, resizable splitters and table Focus mode remain intact.

## Safety
- No Profitability calculation/scoring logic changed.
- Crash/Hang Shield remains active.
- Live broker execution remains locked.

# WINGO v3.1.2 — Multi-Provider Historical RSI Scanner

Build: `WINGO v3.1.2 Multi-Provider Historical RSI Scanner (Execution Locked)`

## Root cause repaired

v3.1.1 could authenticate both FYERS and Upstox but the RSI scanner instantiated
only `FyersMarketDataProvider`. An expired FYERS token therefore produced one
authentication error per F&O symbol even while Upstox History V3 was healthy.

## Implementation

- Added provider-independent `history_candles` parity for FYERS and Upstox.
- Added actual profile + History API preflight before the symbol loop.
- Added primary-to-secondary historical fallback using the existing canonical
  symbol and Upstox instrument-master mapping.
- A failed primary attempt is discarded completely before the whole symbol is
  rebuilt on the fallback provider; cross-provider candle mixing is prohibited.
- Authentication-expired providers are quarantined for the rest of the scan.
- Both providers unavailable produces one fail-fast error, not 208 duplicates.
- Added independent `WINGO_AUTO_HISTORY_FAILOVER=1` policy; realtime failover
  behavior remains unchanged.
- Scanner rows/CSV/snapshots/diagnostics record provider and fallback metadata.
- Scanner UI shows the History Provider used for every successful symbol.
- A zero-row full-universe run is blocked from replacing the previous baseline.
- Empty preflight-failure checkpoints are removed; partially completed scans
  still retain their recoverable checkpoint.

## Safety boundary

- Real order execution remains locked.
- No credentials are packaged or exported.
- Existing shared `Wingo\.env`, `Wingo\.venv`, state and prior baseline are not
  overwritten by package extraction.
- Live-provider acceptance must still be run on Windows with the user's tokens.

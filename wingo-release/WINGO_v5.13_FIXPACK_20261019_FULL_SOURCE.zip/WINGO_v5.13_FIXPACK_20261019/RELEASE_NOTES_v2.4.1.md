# WINGO v2.4.1 — Dashboard Pro UI / Functionality Fix

Critical fixes:
- Fixed Live Feed crash: `live_value` and `live_detail` are now real widgets.
- Added `live_ticks` runtime cache and stores every normalized market tick.
- Dashboard NIFTY/BANKNIFTY values now read from the live tick cache.
- Fixed Dashboard navigation: app uses `nav_buttons`, not nonexistent `nav`.
- Dashboard FYERS status now follows real WebSocket callback state.
- Live Feed error/close/finish states are safe and visible.

Live Feed UI:
- Removed obsolete Phase 2C POC wording.
- Added production status strip:
  - Data Source
  - Market Session
  - Connection
  - Subscribed Symbol Count
  - Last Tick
- Kept the existing detailed live quote table.

Reference-image alignment:
- The app now follows the same information hierarchy more closely:
  top status → cards/status → detailed table → dashboard drill-down.
- Dashboard remains backed by real WINGO state; no fake market numbers.

Safety:
- Real order execution remains locked.

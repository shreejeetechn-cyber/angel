# WINGO v4.2.12

## Morning Authentication + Upstox Analytics Token

- FYERS morning authentication now opens the official FYERS login page. The user enters TOTP/OTP only on that broker page.
- A registered HTTP loopback redirect can be captured automatically after OAuth state verification. Manual redirect/auth-code paste remains available when loopback capture cannot be used.
- A captured FYERS code is exchanged automatically, followed by the existing Auth → History → Full Health → Live Feed startup sequence.
- Optional FYERS refresh-token renewal accepts the account PIN as a masked, transient value. PIN, OTP, TOTP and authorization codes are not persisted or intentionally logged.
- Upstox adds a read-only Analytics Token mode for longer-lived market-data access. Daily Upstox OAuth remains available as a fallback.
- Analytics-token validation uses a market-data endpoint instead of the account-profile endpoint.
- The existing user-selected 30-second supervisory recovery interval is retained.
- FYERS and Upstox reconnect limits remain 20 attempts.
- v4.2.11 stability fixes and v4.2.10 Profitability MTF/manual refresh behavior are retained.
- Stage 8 remains absent and live execution remains locked.

## Important

Automatic redirect capture works only when the broker application is registered with the exact HTTP loopback URI configured in the common `.env`, including host, port and path. Otherwise use the existing paste fallback.

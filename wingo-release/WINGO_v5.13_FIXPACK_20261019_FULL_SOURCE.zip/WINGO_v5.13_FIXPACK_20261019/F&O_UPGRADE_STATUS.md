# WINGO F&O_UPGRADE — VERIFIED STATUS

**Base:** WINGO Desktop v3.7.15  
**Compatibility version:** 3.7.15  
**Build identity:** F&O_UPGRADE  
**Scope:** Signal + Paper F&O only

## Verified delivery state
- Automatic option expiry search: up to 3 expiries.
- Automatic Futures expiry search: up to 3 (NEAR/NEXT/FAR), NEAR preference retained unless materially outscored.
- Strategy-aware expiry, strike and bounded spread-width selection implemented.
- Explicit missing-Delta fallback implemented.
- Exact Signal→Paper contract locking implemented.
- Paper quote freshness maximum: 30 seconds.
- Bid/ask-aware Paper entry simulation implemented.
- All strategy legs available in hover/details; two-leg compact row display; four-leg compact row + full hover.
- Capital Required / Deployed / Notional / ROC / Margin Source visible in Paper.
- Signal source / expiry rank / quote age / selection evidence visible.
- Existing F&O/Signal state colors reuse the unchanged WINGO palette.
- Signal table header click sorting: ASC/DESC toggle + visible sort indicator.
- Universal table saved-sort restore is compatible with Signal external sorting.

## Protected
- Profitability Lab remains separate and byte-identical to v3.7.15 baseline.
- WINGO THEME color map unchanged.
- Execution gate unchanged.
- FYERS SDK 3.1.16.
- `.place_order()` = 0.
- Real execution = LOCKED.

## QA before packaging
- 35 / 35 QA scripts PASS.
- 966 `PASS:` assertions.
- 154 / 154 Python source files compile.

## Runtime limitation
The container can validate source, engines, persistence models and headless F&O/Paper behavior, but it cannot reproduce the user's exact Windows display/DPI, live broker market session, or physical PySide6 click interaction. Those target-runtime checks remain appropriate after extraction on Windows.

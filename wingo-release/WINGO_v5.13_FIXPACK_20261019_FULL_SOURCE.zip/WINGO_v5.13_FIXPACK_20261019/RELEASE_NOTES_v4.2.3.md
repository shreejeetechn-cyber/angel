# WINGO v4.2.3 — Stability + Semantic Table Colour Code

This patch is a stability/readability release on top of v4.2.2. It does not add
broker execution authority. Stage 0 through Stage 7 remain the approved scope;
Stage 8 is not present and Live Execution remains locked.

## Stability fixes

- Canonical NSE symbol normalization now accepts local/bare forms such as
  `DABUR`, `RELIANCE-EQ`, and derivative identities before provider validation.
- Cash-equity transport validity is separated from F&O-universe eligibility.
  A valid non-F&O watchlist equity is no longer rejected merely because it is
  absent from the derivatives universe.
- Multi-provider routing now exposes runtime health (`HEALTHY`, `DEGRADED`,
  `STALE`) separately from startup authentication health.
- Per-symbol failover uses recovery hysteresis. `failover_count` measures actual
  provider transitions; `failover_tick_count` separately measures secondary
  accepted traffic.
- FYERS and Upstox transport closure is worker-owned and idempotent. Upstox no
  longer calls SDK disconnect from the GUI thread, and modern feeds no longer
  start a duplicate shutdown helper against the same native socket.
- Backtest atomic JSON persistence retries transient Windows/OneDrive
  `PermissionError` locks with bounded exponential backoff.
- Backtest input accepts a bare NSE cash symbol and canonicalizes it before the
  existing equity-only validation.

## Semantic table colour code

The selected theme remains authoritative. No trading rule depends on colour.

- Positive / active / bullish / pass: theme green + soft bullish background.
- Negative / bearish / failed / blocked / stale: theme red + soft bearish background.
- Warning / waiting / weakening / estimated: theme amber + neutral-soft background.
- Informational / new / shadow / acknowledged: theme cyan + accumulation-soft background.
- Muted / closed / resolved / off: theme muted text + panel-alt background.

Colour coding is applied to the highest-value status cells in:

- Signals
- Scheduled Entries
- Paper Positions
- Cash Holdings
- Persistent P&L Ledger
- Active Alerts and Permanent Alert History
- Diagnostics and UI Self-Test

The Dashboard provider ribbon also reports configured-primary runtime health and
actual failover-transition count.

## Safety

- Paper remains simulated.
- Market Maker stages remain evidence/readiness gated.
- Live execution remains locked.

# WINGO v3.7.11 — Runtime Quality Hotfix

## Scope
This release is a narrow quality/stability cleanup over v3.7.10. Trading strategy calculations, Profitability scanner math, broker execution policy and FYERS SDK 3.1.16 pin are unchanged. Real execution remains locked.

## Fixes
- Signals table refresh no longer uses `ResizeToContents` on the 25-column live table. Refreshes are bulk-populated with painting/sorting temporarily suspended, and dashboard/subscription follow-up work is debounced off the immediate table-population path.
- FYERS startup logging now distinguishes `TOKEN MISSING` from `TOKEN PRESENT — WAITING FOR VALIDATION`; an unvalidated secondary provider is no longer falsely described as token-unavailable.
- FYERS transport state and symbol-health state are separated. `SYMBOL PROBE INCONCLUSIVE - ACTIVE PLAN RETAINED` is recorded as a warning without overwriting a live/connected transport state.
- FYERS anonymous `-300` probing keeps conservative no-guess quarantine behavior, while adding bounded rotating exact single-symbol REST checks after group probing. Only an explicit single-symbol provider rejection is quarantined.
- Button Readability audit excludes `QTabBar`-owned scroll helper buttons created internally by Qt while continuing to audit WINGO push/tool buttons and icon-only controls.
- Diagnostics session events now include failing UI-row detail, so an actual offending control is visible in AI diagnostics instead of only the check name.
- AI diagnostic problem summary merges the current watchdog run-state HANG/CRASH problem with session incidents; a current GUI hang is no longer historical-only in the summary.
- Acceptance now preserves core diagnostics WARN/FAIL severity and can include the GUI-thread UI Self-Test summary. System acceptance becomes FAIL for a technical FAIL, WARN for a technical WARN, and PASS only when all technical steps pass.
- README/build identity updated to v3.7.11.

## Explicitly unchanged
- `fyers-apiv3==3.1.16`.
- Profitability indicator scanner behavior and calculations.
- Paper/live execution safety policy.
- Broker `.place_order()` calls remain absent; real execution remains locked.

## Runtime validation note
The 10.1-second Windows GUI stall seen in v3.7.10 motivated the wide-table refresh mitigation. The uploaded AI diagnostics did not contain the full MainThread stack from the separate hang report, so this release does not claim that the exact original stall root cause was proven. The watchdog remains enabled to verify the improvement on the target Windows machine.

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title WINGO v5.10 Local License Server
cls
echo ================================================================
echo WINGO v5.10 - LOCAL LICENSE SERVER
echo ================================================================
echo.
echo Correct health endpoint: http://127.0.0.1:9443/health
echo Keep this window open while testing local activation.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%CD%\internal\license_server\START_LICENSE_SERVER.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo [FAILED] License server exited with code %RC%.
if "%RC%"=="0" echo [STOPPED] License server stopped normally.
pause
exit /b %RC%

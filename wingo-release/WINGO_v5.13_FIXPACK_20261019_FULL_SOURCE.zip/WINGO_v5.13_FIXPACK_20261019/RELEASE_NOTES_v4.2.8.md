# WINGO v4.2.8 — Performance Optimization + Incremental Scanner Cache

## Scope
Performance-only successor to v4.2.7. No strategy threshold, profitability score, Stage 0-7 gate, Paper risk rule or execution permission is relaxed. Stage 8 remains absent and Live Execution remains locked.

## Changes

1. **Rolling Hybrid Aggressor CVD**
   - 1m/3m/5m/15m deltas and slopes use rolling per-window state.
   - Repeated LTT/LTQ deduplication and TRUE/HYBRID/I-CVD provenance are unchanged.

2. **Live analysis coalescing**
   - Raw events still update VWAP/CVD/depth immediately.
   - MainWindow batch path queues one expensive Profitability rebuild per affected symbol per 750 ms.
   - Direct single-tick calls remain immediate for diagnostics/legacy contracts.

3. **Lazy AMIT**
   - AMIT-specific Price EMA5/EMA25 and RSI-BB evaluation runs only in AMIT mode.
   - DECISION, RSI, FLOW and ALL 39 remain unchanged.

4. **Incremental scanner history cache**
   - First scan seeds the normal ~620-day raw daily candle history per provider/symbol.
   - Subsequent scans fetch only a 7-day overlap through today and merge by timestamp.
   - Cache is provider-specific so fallback candles are never mixed inside one RSI history.
   - Windows default cache location is local app data, away from OneDrive-backed project state.

5. **Reduced hidden UI work and persistence churn**
   - Stage 1-7 tables repaint only while visible/selected/popped out.
   - Stage engines continue processing even when their pages are hidden.
   - Stage snapshots use bounded active cadence and 5-second idle persistence.
   - Profitability row sorting is revision-cached.

## Safety
- Live execution: LOCKED
- Stage 8 execution engine: NOT PRESENT
- No broker submission path added

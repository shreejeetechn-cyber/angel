# WINGO v3.7.12 — Fresh Lifecycle Cycle

## Scope
This release implements the approved **automatic Fresh Cycle** behavior for the Profitability Lab lifecycle. It is not a separate user mode and does not add a toggle.

## Fresh lifecycle contract
- RSI/EMA and other indicator history is retained for calculation warm-up and continuity.
- Lifecycle **trading state is session-scoped** to the current IST/NSE trading day.
- A new trading day never inherits yesterday's `ENTRY READY`, `CONFIRMED`, `MOMENTUM STRONG`, `EXHAUSTING`, or `EXIT` state.
- The first current-session cycle is `#1`.
- `EXIT` closes the current cycle; a later genuine setup starts `#2`, then `#3`, etc.
- Same-day persisted lifecycle state is used only to reconstruct the current session after an intraday WINGO restart. The first fresh reconstruction is labelled `FRESH — REBUILT`.
- A live-data stale period (>15 seconds) revokes lifecycle freshness. On recovery, the first otherwise-confirmed evaluation is forced through `ENTRY READY` before a later fresh evaluation may restore `CONFIRMED`.

## Fresh evidence requirements
Lifecycle freshness is evaluated from current-session timestamps:
- live underlying tick,
- market/context update for active lifecycle stages,
- session VWAP for `CONFIRMED` / `MOMENTUM STRONG` / later stages,
- aligned current order-flow evidence for confirmed trade-candidate stages.

The lifecycle exposes:
- `session_day`
- `cycle` and `cycle_id`
- `cycle_started_epoch` and `cycle_age_seconds`
- `fresh` and `freshness`
- `freshness_reasons`
- per-family evidence ages
- `source` (`CURRENT SESSION`, `REBUILT CURRENT SESSION`, or stale/history)

## Profitability acceptance
When the v3.7.12 lifecycle freshness contract is present, a Profitability candidate cannot PASS with a stale lifecycle. `CONFIRMED` or `MOMENTUM STRONG` must also be current-session fresh. Older historical/backtest fixtures that predate the freshness metadata retain their prior semantics for regression compatibility.

## UI
- Advanced Matrix adds `Life Fresh` and `Cycle` columns.
- Selected-script Details shows lifecycle freshness, session/source, cycle ID, and cycle age.
- Compact Superpage context shows `Lifecycle | Freshness | #Cycle` for the selected script.

## Deliberately unchanged
The following v3.7.11 calculation/safety modules were byte-compared and remain unchanged:
- Profitability scoring and weights
- RSI intelligence
- raw lifecycle stage formula (`lifecycle_engine.py`)
- VWAP engine and VWAP acceptance thresholds
- E-CVD, depth and order-flow formulas
- strategy selection
- shadow/performance analytics
- paper automation formulas
- live execution gate
- FYERS SDK pin (`fyers-apiv3==3.1.16`)

Real broker execution remains **LOCKED** and application source contains zero broker `.place_order()` calls.

## Verification
- 30 / 30 QA scripts PASS
- 787 `PASS:` verification lines
- 147 / 147 Python files compile
- 0 broker `.place_order()` calls
- protected calculation modules listed above remain byte-identical to v3.7.11

# WINGO v4.2.6 — Hybrid Aggressor CVD + Multi-Timeframe Flow Provenance

## Scope

This release improves order-flow classification without pretending that quote-inferred flow is exchange-provided aggressor data.

## Aggressor classification

1. `EXPLICIT_PROVIDER` — only when the normalized provider payload actually contains BUY/SELL aggressor side. This is the only path classified as TRUE CVD.
2. `PRIOR_QUOTE` — new trade at/through the previous ask => BUY; at/through previous bid => SELL.
3. `PRIOR_MIDPOINT` — trade above/below previous midpoint when it is inside the spread.
4. `CURRENT_QUOTE` — weaker fallback when no prior book exists.
5. `TICK_RULE` — final fallback versus the prior trade price.
6. `UNCLASSIFIED` — no directional volume is invented.

Repeated quote updates carrying the same last-trade timestamp/price/quantity are deduplicated.

## Labels

- `TRUE CVD` — explicit provider aggressor only.
- `HYBRID CVD` — session contains both explicit and inferred aggressor volume.
- `I-CVD` — inferred aggressor volume only.
- `E-CVD` — unavailable/warming legacy estimated state.

The internal legacy `label` remains `E-CVD` for inferred flow so historical scoring/gates do not silently upgrade inferred data into true CVD.

## Multi-timeframe flow

Adds 1m, 3m, 5m and 15m delta/slope/growth plus an MTF summary such as `BULLISH 3/4`, `BEARISH 4/4`, or `MIXED`.

## Data Matrix

Adds:
- CVD Type
- Delta 1m
- Delta 3m
- Delta 5m
- Delta 15m
- CVD MTF
- Session CVD
- True Agg %

## Safety

Stage 0-7 retained. Stage 8 execution engine is not present. Live execution remains locked.

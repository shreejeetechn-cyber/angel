# WINGO v5.01 — MainThread Async + Inline Daily Login

WINGO v5.01 promotes the verified v5.00 RC dev3 MainThread Async Hotfix to the next release identity.

## Retained verified changes

- Compact inline FYERS + Upstox daily OAuth login inside the WINGO Authentication page.
- Central shared `Wingo\.env` remains authoritative for broker configuration and validated daily tokens.
- OTP/TOTP/PIN are entered only on broker-hosted authentication pages and are not persisted by WINGO.
- MainThread disk writes are routed through the background persistence queue.
- Scanner runtime snapshot persistence is asynchronous.
- Autonomous-learning study/save runs off the GUI thread.
- Signals rendering reuses one market-regime snapshot per refresh instead of recalculating it per row.
- Full MCX scanner universe, Stage 0–7 safety, Stage 8 absence and Live Execution LOCKED remain unchanged.

## Version

`APP_VERSION = "5.01"`

# WINGO v5.0.0-dev2.1.2 — Signal Lifecycle Exchange Isolation Hotfix

- Signal Lifecycle persistence moved from global `.wingo_state/signals.json` to exchange-isolated files:
  - `.wingo_state/markets/NSE/signals.json`
  - `.wingo_state/markets/MCX/signals.json`
- NSE retains read-only compatibility fallback to legacy global `signals.json`; the next NSE save writes the market-isolated file. MCX never reads the legacy NSE file.
- Exchange switching now persists the previous exchange engine before context change, restores a fresh target-exchange lifecycle engine, rebuilds signal live references, and refreshes the Signals workspace.
- Web projection and AI diagnostics read only the active exchange signal store. Diagnostics also report NSE/MCX persisted counts.
- Forward-validation research explicitly reads both signal stores so global paper outcome research remains correlatable.
- Factory/reset Signal category clears both exchange stores plus the legacy compatibility file.
- Production hardening validates both exchange signal JSON files.
- Signal creation/ranking/state transitions/paper eligibility are unchanged.
- Live Execution remains LOCKED. Stage 8 remains ABSENT. Profitability Auto Pop Out remains disabled.

# WINGO v5.0.0-dev2.1.1 — Dashboard Breadth Legend Hotfix

- Fixes blank Dashboard breadth legend after switching to MCX.
- MCX now renders Advance / Decline / Unchanged as explicit `N/A` because NSE breadth is intentionally not applied to MCX.
- NSE continues to render true Advance/Decline/Unchanged counts and percentages.
- Exchange switching forces an immediate Dashboard refresh so the legend cannot remain in its pre-switch empty state.
- No change to FnoInstrument, FUTURE_PROXY, provider routing, storage isolation, Live Execution lock, Stage 8, or Profitability Auto Pop Out.

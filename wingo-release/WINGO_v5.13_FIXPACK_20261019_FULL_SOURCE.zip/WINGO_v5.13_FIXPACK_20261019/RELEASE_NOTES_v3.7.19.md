# WINGO v3.7.19 runtime_isolation

## Scope

This release addresses the Windows native hang/access-violation evidence seen
after an otherwise healthy Upstox-only market session. It retains v3.7.18 as
the untouched rollback baseline. Trading/scoring policy is unchanged and real
broker execution remains locked.

## Runtime isolation

- Provider callbacks enqueue copied payloads without touching Qt widgets.
- A 250 ms GUI timer drains raw events and repaints each accepted symbol once.
- Raw accepted ticks still feed VWAP, estimated cumulative delta, depth and
  shadow-validation logic in order through a batch controller path.
- Live-table cells are reused instead of allocating every cell on every tick.
- Worker-result logs are compact and on-screen log history is bounded.
- Rotating file logging and session-audit writes run on background writers.

## Feed and workload control

- Startup order is UI → primary → secondary → breadth → scanner → strategy.
- Broker/REST workloads are limited to two concurrent jobs.
- Breadth and automatic strategy work pause during the full RSI scanner.
- Feed modes: `DUAL`, `PRIMARY_STANDBY`, and `PRIMARY_ONLY`.
- Per-provider live enable flags allow a clean Upstox-only or FYERS-only test.
- FYERS REST depth probing is off by default; actual WebSocket depth payloads
  are validated and their delivered level count is reported.
- Upstox full quotes provide a provider-neutral Futures Snapshot fallback,
  including OI and top bid/ask when mapped data is available.

## Central environment examples

Add these only to the shared `Wingo\.env`, never inside this build folder:

```dotenv
WINGO_PRIMARY_MARKET_FEED=UPSTOX
WINGO_FEED_MODE=DUAL
WINGO_ENABLE_UPSTOX_LIVE=1
WINGO_ENABLE_FYERS_LIVE=1
WINGO_AUTO_MARKET_FAILOVER=1
WINGO_AUTO_HISTORY_FAILOVER=1
WINGO_CROSS_FEED_MAX_DIVERGENCE_PCT=1.5
WINGO_FYERS_REST_DEPTH_PROBE=0
```

For an isolated Upstox-only test, use `WINGO_FEED_MODE=PRIMARY_ONLY` with
`WINGO_PRIMARY_MARKET_FEED=UPSTOX`. Restore `DUAL` after the test.

## Acceptance boundary

Automated source/core/package verification is included. A live Windows market
session remains required to confirm provider latency and native SDK behavior.

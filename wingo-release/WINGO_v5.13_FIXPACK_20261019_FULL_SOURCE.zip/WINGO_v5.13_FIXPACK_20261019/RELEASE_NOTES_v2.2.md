# WINGO v2.2 Scanner Intelligence

Added:
- classified/consolidated F&O RSI scanner
- bullish/bearish/neutral color coding
- accumulation/distribution/consolidation states
- breakout/breakdown watch states
- A+/A/B/C/X grades and action buckets
- 20D range, volume ratio, return and OBV bias
- summary category counters and filters
- classified CSV export + local scan history
- Futures Snapshot page
- script + expiry dropdown
- Spot/Future/lot/contract value
- Basis/Basis %
- Future OI/Delta OI/Volume where provider exposes fields
- buildup classification
- near/next/far comparison
- scanner -> futures drill-down
- fixed accidental scanner state-reset bug

Safety:
- No real order execution.
- Missing data stays N/A.

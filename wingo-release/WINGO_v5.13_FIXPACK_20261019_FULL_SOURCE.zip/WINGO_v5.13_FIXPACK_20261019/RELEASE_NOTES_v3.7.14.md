# WINGO v3.7.14 — Profitability Matrix Filters & Auto-Fit Viewport Fill

## Scope
UI-only follow-up to v3.7.13, limited to the requested Profitability Matrix filter controls and Auto Fit / Reset right-side blank-space correction.

## Added
- Dedicated **Raw Bias** dropdown filter over the displayed `Raw Bias` / `final_bias` column.
- Dedicated **Final Bias** dropdown filter over the displayed `Final Bias` / `bias_strength` column.
- Dedicated **Stage** dropdown filter over the lifecycle column.
- Dedicated **Life Fresh** dropdown filter over lifecycle freshness.
- Filter values refresh from the current matrix row data while preserving the active selection when it is still available.
- New dropdown filters combine with Search, Grade, Acceptance, PASS, A+/A++, CONFIRMED, FRESH, hidden-row state, and existing presentation sorting.

## Auto Fit / Reset correction
- Cell-data measurement remains the base sizing rule; header text still does not drive widths.
- After compact data-fit widths are calculated, unused table viewport width is assigned to one suitable explanatory flex column (normally Gate Reasons; Acceptance/Divergence fallback).
- The matrix no longer leaves a large unused strip at the right after Auto Fit / Reset when visible fitted columns are narrower than the viewport.
- Every column is **not** stretched: compact numeric/data columns remain compact.
- Wrapped headers remain applied after the final viewport-fill width is known.
- Window resize uses the existing debounced Auto Fit timer rather than continuous `ResizeToContents`.
- Qt last-section auto-stretch remains disabled so it cannot fight the controlled data-fit logic.

## Safety / unchanged logic
- Existing matrix color function unchanged.
- Global main-window/theme color source unchanged.
- All 39 matrix columns retained.
- Profitability scoring, acceptance, lifecycle, RSI intelligence, VWAP, CVD/depth, strategy and performance logic unchanged.
- FYERS SDK remains pinned to 3.1.16.
- Live execution remains locked; no `.place_order()` call is introduced.

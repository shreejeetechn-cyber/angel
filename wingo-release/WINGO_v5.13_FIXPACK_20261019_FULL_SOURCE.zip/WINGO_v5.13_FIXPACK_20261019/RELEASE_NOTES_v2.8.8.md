# WINGO v2.8.8 — Dashboard Router + Options Dropdown + Term Structure Fix

## Dashboard command routing
- Top Opportunities double-click now asks: Futures Snapshot or Options Workspace.
- Alerts double-click uses the same router.
- RSI Heatmap tiles are double-clickable and use the same router.
- Dashboard Option Chain button opens the selected opportunity directly in Options Workspace.
- Navigation actions are written to the Session Audit through the normal WINGO log.

## Options Workspace
- Dashboard routes also transfer scanner direction, grade, score and M/W/D RSI into a visible context strip and underlying scoring controls.
- Replaced manual-only FYERS symbol field with an editable F&O Script dropdown.
- Dropdown is populated from bundled/live scanner universe plus index underlyings.
- Futures Master sync also refreshes the Options script list.
- Script selection loads the Expiry dropdown.
- Expiry display is human-readable where the provider returns epoch values, while preserving the raw API value.
- Dashboard / Watchlist / Futures routing auto-selects the script and loads expiries.
- Added Futures Snapshot shortcut for two-way navigation.

## Futures Intelligence / Term Structure
- Changing script clears the old Term Structure rows so stale data cannot appear under a new script.
- Term Structure is no longer silent.
- Dedicated block status: IDLE / LOADING / READY / PARTIAL / NO DATA / NO CONTRACTS / FAILED.
- If Futures Master is empty, Near/Next/Far first syncs the master and retries.
- Zero-row provider result is an explicit failure instead of a green empty READY state.
- Contract-level failures remain visible as rows with their error reason.
- Added Options Workspace shortcut.
- Fixed futures-contract table selection: expiry combo now selects by exact FYERS future-symbol data, not raw expiry text against labels like `YYYY-MM-DD | NEAR`.

Real broker execution remains locked.

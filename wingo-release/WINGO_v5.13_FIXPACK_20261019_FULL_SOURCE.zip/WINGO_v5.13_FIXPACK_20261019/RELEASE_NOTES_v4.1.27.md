# WINGO v4.1.27 — Stage 7 Broker Sandbox/Read-Only Operational Rehearsal

Stage 7 completes the controlled Stage 0-7 roadmap with an evidence-gated,
zero-capital operational rehearsal. It has no broker SDK/client and cannot
submit a network order.

## Implemented

- Separate `Broker Rehearsal` page and persistent Stage 7 controller.
- Stage 6 forward portfolio evidence gate with no manual/profit-only bypass.
- Deterministic local sandbox submit/ACK/open/partial/fill/reject/cancel flow.
- Raw broker status to canonical WINGO state mapping.
- Correlation by WINGO client tag, local order ID and SANDBOX order ID.
- Duplicate/out-of-order event idempotency and illegal-regression detection.
- Requested = filled + cancelled + remaining reconciliation.
- ACK, first-fill, cancel and terminal latency p50/p95/max with SLA checks.
- CANCEL ALL, disconnect/reconnect mismatch detection and stale-state timeout.
- Read-only JSON/JSONL import restricted to explicitly marked SANDBOX events.
- Restart cancellation of stale local rehearsal states and operator review latch.
- Stage 7 diagnostics, acceptance and focused/legacy regression coverage.

## Hard safety boundary

- Starts evidence-gate locked and cannot be manually promoted.
- Local sandbox requests never leave the process.
- Broker read-only mode cannot submit or cancel an external order.
- Non-SANDBOX/writable events, orphan IDs and unmapped states halt rehearsal.
- Capital, Stage 5/6, directional Paper and F&O P&L impact remain zero.
- External broker requests remain zero and Live Execution remains locked.
- Any future live scope is a separately authorized production project.

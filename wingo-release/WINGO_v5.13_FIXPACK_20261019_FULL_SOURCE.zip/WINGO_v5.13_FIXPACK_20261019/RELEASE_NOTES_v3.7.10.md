# WINGO v3.7.10 — FYERS SDK 3.1.16 Upgrade

## Scope
- Upgraded `fyers-apiv3` from **3.1.15** to **3.1.16**.
- No trading execution enablement; real execution remains locked.
- Profitability indicator scanner behavior from v3.7.9 is unchanged.

## FYERS SDK compatibility
- Official/source package reference: `fyers_apiv3-3.1.16.tar.gz`.
- Verified source SHA-256: `0d58cbc5f70dd679f9979d2b840b09ab3e58ea824622be74d27324efdaaa0013`.
- WINGO usage remains compatible with the v3.1.16 public contracts used by this app:
  - `fyersModel.FyersModel(client_id, token, is_async, log_path)`
  - `FyersModel.depth(data=...)`
  - `FyersDataSocket(..., reconnect_retry=...)`
  - `subscribe(..., data_type="SymbolUpdate"|"DepthUpdate")`
  - `unsubscribe(...)`
- Existing depth parser retains FYERS response compatibility including singular `ask`.

## Environment upgrade behavior
- `requirements.txt` pins `fyers-apiv3==3.1.16`.
- `START_WINGO.bat` verifies the exact installed version and installs 3.1.16 only when missing/mismatched.
- `run_wingo.ps1` performs the same exact-version check.
- `setup_common_venv.ps1` continues installing the pinned requirements file.
- Direct-launch safety: the FYERS provider rejects an incompatible SDK version rather than silently using it.

## Preserved safeguards
- FYERS `-300` handling remains symbol-specific and does not guess-quarantine.
- Network/DNS/transport classification and reconnect-plan restoration remain intact.
- REST depth payload self-test and live DepthUpdate handling remain intact.
- NIFTYFPI insufficient-history block behavior remains intact.
- BANKNIFTY/Regime dashboard freshness guards remain intact.
- Profitability indicator checkboxes remain fully functional scanner controls.
- Shutdown-safe Profitability rendering remains intact.
- Broker `.place_order()` calls remain zero.

## Verification
- 28/28 QA suites PASS.
- 725 PASS assertions/check lines across the regression suite.
- 145 Python files compile successfully.
- Fresh delivery ZIP is re-extracted and the same acceptance suite is rerun before delivery.

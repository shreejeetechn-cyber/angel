# WINGO v4.5.0 Unified Core Guide

## Start modes

- `START_WINGO.bat` — ensure Core, show Desktop, apply table AutoFit.
- `START_WINGO_WEB.bat` — ensure Core, keep/show no duplicate Desktop, open `http://127.0.0.1:8787/`.
- `START_WINGO_ALL.bat` — ensure one Core, show Desktop and open Web.
- `START_WINGO_CORE.bat` — run/attach Core without opening a client.
- `HIDE_WINGO_DESKTOP.bat` — hide Desktop only; Core/Web/feeds continue.
- `STOP_WINGO_CORE.bat` — explicit full runtime shutdown.

## Lifecycle

Either Desktop or Web may start first. The first launcher starts `unified_main.py`; later launchers probe `127.0.0.1:8788` and attach to that same PID. A second Core cannot bind the singleton control port.

The embedded Web server runs on `127.0.0.1:8787`. Desktop and Web therefore observe/control the same provider sessions, scanner, signals, Profitability, Paper state and scheduled entries.

Closing the Desktop window only hides it. Use **Shutdown Core** for a full stop.

## AutoFit

Desktop tables retain the universal table controller and have AutoFit enabled/recomputed on Core startup. The Web mirror adds a default-on **AutoFit GUI** control that scales the Desktop canvas to the available browser width without changing the underlying Desktop geometry.

## Safety

Live/broker order execution remains locked and Stage 8 is absent. Web authentication, CSRF, localhost-only binding and memory-only sensitive-field transport remain enabled.

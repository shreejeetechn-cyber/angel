# WINGO v4.3.5 — Web Phase 4 Authenticated Control Workspace

Build: `WINGO v4.3.5 Web Phase 4 Authenticated Control Workspace (Live Execution Locked)`

## Phase 4

- Adds localhost Web Login, authenticated browser sessions and a top-right Logout button.
- Adds PBKDF2-HMAC-SHA256 credential storage; plaintext passwords are not stored in `credentials.json`.
- Adds secure first-run random password bootstrap when `WINGO_WEB_PASSWORD` is absent.
- Adds optional centralized `.env` credentials: `WINGO_WEB_USERNAME`, `WINGO_WEB_PASSWORD`, `WINGO_WEB_SESSION_HOURS`.
- Adds HttpOnly + SameSite=Strict session cookie and CSRF protection for every authenticated state-changing REST request.
- Adds absolute browser-session expiry and login attempt rate limiting.
- Authenticates the WebSocket status stream.
- Attributes Phase 3 safe control commands to the authenticated local web username.
- Logout affects only the browser session; desktop WINGO and broker sessions remain untouched.

## Inheritance

Web Phase 1–3 views and safe controls are retained. v4.3.3 runtime-stability fixes remain retained, including background Profitability/CVD processing and GUI stall hardening.

## Safety

No broker order placement, auth-secret submission, Stage 8 action or execution-unlock endpoint exists. Live execution remains LOCKED.

# WINGO v3.7.24 stable_profitability_risk

## Stable Profitability Data Matrix

- Replaced per-tick full-table rebuilds with changed-cell-only rendering.
- Preserves first-seen row order until the user explicitly selects a sort or BEST FIRST.
- Retains selection and scroll position across rare structural row changes.
- Avoids rebuilding unchanged filter choices and Shadow tables.
- Pauses the RSI Graph renderer while the Graph tab is hidden.
- Reuses existing table items and batches visible updates to prevent blinking.

## Paper Risk Intelligence

- Risk Capital now follows current Paper equity by default.
- Added an explicit `Sync Capital with Paper Equity` control on Risk Engine.
- Manual Paper rejection now shows requested lots/units, proposed risk, per-trade allowance,
  existing open risk, post-entry portfolio risk, one-lot risk, affordable lots and minimum
  capital for one lot.
- Risk blocks are presented as safety decisions rather than `RuntimeError` messages.
- Auto Paper uses the same numerical risk evaluation and logs one-lot affordability evidence.
- Auto-entry counters are contract-tested to increment once per successful open.

## Safety

- Paper and Shadow workflows only.
- Live broker execution remains locked.
- BSE instruments remain excluded.
- v3.7.23 lot-size currency accounting and v3.7.22 table callback hotfix are retained.

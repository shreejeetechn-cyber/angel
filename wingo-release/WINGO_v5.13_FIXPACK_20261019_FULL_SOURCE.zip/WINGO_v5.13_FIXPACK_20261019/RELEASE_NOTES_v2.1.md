# WINGO v2.1 — Live Paper Automation Bridge

## Added
- one dedicated FYERS WebSocket for all open paper option symbols
- automatic paper premium marking from live option ticks
- automatic paper P&L updates
- configurable paper stop-loss %
- configurable paper target %
- automatic paper exit on stop/target
- automatic Signal -> EXIT synchronization on paper exit
- optional automatic paper entry from qualifying A/B signals
- Risk Engine gate before automatic paper entry
- duplicate paper-entry protection
- maximum open paper-position control
- persistent paper automation settings
- automatic re-subscription when open-position symbol set changes
- manual mark remains available as fallback

## Safety
- no broker order endpoint
- controlled execution remains locked
- live market data is real; trades/P&L are simulated

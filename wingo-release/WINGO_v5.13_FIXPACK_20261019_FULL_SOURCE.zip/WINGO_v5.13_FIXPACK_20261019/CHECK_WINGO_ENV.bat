@echo off
setlocal
cd /d "%~dp0"

set "SEARCH=%CD%"
set "ROOT="

:find_root
for %%I in ("%SEARCH%") do set "NAME=%%~nxI"
if /I "%NAME%"=="Wingo" (
    set "ROOT=%SEARCH%"
    goto found
)
for %%I in ("%SEARCH%\..") do set "NEXT=%%~fI"
if /I "%NEXT%"=="%SEARCH%" goto fallback
set "SEARCH=%NEXT%"
goto find_root

:fallback
for %%I in ("%CD%\..") do set "ROOT=%%~fI"

:found
set "PY=%ROOT%\.venv\Scripts\python.exe"

echo WINGO root: %ROOT%
echo Python: %PY%
echo.

if not exist "%PY%" (
    echo ERROR: Common .venv not found.
    pause
    exit /b 1
)

"%PY%" --version
"%PY%" -c "import PySide6, requests, dotenv; from fyers_apiv3 import fyersModel; print('PySide6:', PySide6.__version__); print('requests:', requests.__version__); print('FYERS SDK: OK')"
echo.
pause

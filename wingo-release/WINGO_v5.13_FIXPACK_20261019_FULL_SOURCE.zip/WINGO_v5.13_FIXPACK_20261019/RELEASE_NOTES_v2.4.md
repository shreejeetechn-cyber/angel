# WINGO v2.4 — Dashboard Pro

## Dashboard Pro
- Professional command-center dashboard based on the original WINGO roadmap concept.
- Uses real in-memory WINGO state; no dummy market/scanner values are hard-coded.

### Header
- Market OPEN/CLOSED indicator
- NIFTY 50 live LTP when available from current live feed
- BANKNIFTY live LTP when available
- FYERS live-feed connection state
- Last dashboard refresh time

### Summary cards
- Total F&O scanned
- Bullish
- Bearish
- Neutral
- Accumulation
- Distribution
- A+/A setups
- Open paper positions

### Top Opportunities
- Symbol
- Monthly RSI
- Weekly RSI
- Daily RSI
- Classification
- Grade
- Consolidated Score
- Bucket
- Double-click drill-down to Scanner
- One-click selected symbol -> Futures Snapshot

### Analytics
- Market breadth table
- Recent signals
- RSI heatmap / strength view
- Grade distribution
- Paper P&L summary

### Refresh
- Auto refresh every 5 seconds
- Immediate refresh after scanner / signal / paper updates where applicable

## Safety
- Live execution remains locked.

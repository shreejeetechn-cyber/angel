# WINGO v3.4.0 - Validated Profitability Pipeline

## Phase 1 - Live Acceptance

- Freshness, provider, grade and coverage hard gates.
- Independent RSI, market, sector, VWAP, E-CVD, depth and OI confirmations.
- PASS/WARN/BLOCK, confirmation count and exact gate reasons in Data Matrix.

## Phase 2 - Shadow Profitability

- Cost-adjusted expectancy, win rate, payoff, profit factor and drawdown.
- MFE/MAE tracking and breakdown by direction, grade and strategy.
- Minimum 30 closed outcomes across five market sessions.
- Pre-v3.4 records without strict acceptance/evidence remain visible but are
  excluded from the validation sample.

## Phase 3 - Adaptive Optimizer

- Uses closed shadow evidence only.
- Requires the high-profit validation gate.
- Adjustments are conservatively clipped to +/-15 percent.

## Phase 4 - Paper Automation

- A++/A+ and strict-acceptance candidates only.
- Stop, target, maximum-hold and bias-reversal lifecycle.
- Slippage, cost, realized/unrealized P&L and simulated equity.
- Underlying-direction simulation only; it does not claim option-contract P&L.
- Live broker execution is locked and the module has no execution/provider imports.

## Scope

- BSE remains excluded.
- Central credentials remain in `Wingo\.env`.
- The v3.3.1 lazy-loading startup hotfix remains active.

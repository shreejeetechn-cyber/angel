# WINGO v3.0.0 — Research Validation + Production Hardening

## Scope
This consolidated release implements the remaining validation roadmap after v2.9.0 while keeping live broker execution locked.

## 1) Historical market-context validation
- Full F&O-universe research runs can reconstruct **true historical advance/decline breadth** from the cached cash-equity histories already fetched by the backtest.
- NIFTY 50 and BANKNIFTY daily confirmation is added from FYERS history.
- Each historical signal is enriched with a `historical_market_context` block.
- The context model is explicitly labelled `RESEARCH_PROXY_TRUE_BREADTH_PLUS_INDEX`.
- WINGO does **not** claim this is an exact replay of the live regime engine because historical scanner-state breadth and historical India VIX are not silently fabricated.
- Historical context statistics report win rate, expectancy and profit factor by BULLISH / BEARISH / MIXED / DATA INCOMPLETE bucket.

## 2) Conservative stop / target optimization
- Tests a bounded default grid:
  - Stops: 0.40%, 0.50%, 0.60%, 0.75%, 1.00%
  - Targets: 0.80%, 1.00%, 1.20%, 1.50%, 2.00%
- Uses the already measured primary-horizon MFE / MAE for each historical signal.
- If daily OHLC shows that both stop and target were reachable but cannot reveal intraday ordering, the optimizer uses **STOP_FIRST**.
- Ranking uses expectancy with a drawdown penalty rather than win rate alone.
- Full optimizer grid is persisted to a separate CSV report.

## 3) Backtest dashboard / reporting
Backtest workspace now adds:
- **Run Full Roadmap Suite**
- **Refresh Forward / Audit**
- Research-suite status line covering historical context, best stop/target pair, paper forward validation, futures forward collection and production audit.

Reports now include:
- JSON full research payload;
- signal CSV with historical context fields;
- optimizer-grid CSV;
- standalone dark HTML research report with equity curve, context comparison, optimizer result, forward validation and production audit.

## 4) Live paper forward validation
- Reads persisted paper positions and signal metadata.
- Excludes `pnl_valid=false` / quarantined paper outcomes from the valid research sample.
- Normalizes valid paper outcomes to **R-multiples** when defined risk/reference risk is available.
- Produces aggregate R metrics plus strategy and signal-type breakdowns.
- Historical underlying-backtest expectancy (%) and paper expectancy (R) are intentionally not treated as scale-equivalent; the report explicitly states the comparison boundary.

## 5) Futures forward validation
- Every LIVE futures snapshot can be appended to a bounded research JSONL ledger.
- Ledger rotates at ~10 MB to avoid unlimited growth.
- No historical futures OI/basis is fabricated from cash candles.
- Directional accuracy of actual FYERS buildup labels is evaluated forward at 5m / 15m / 30m once enough real snapshots exist.
- Buildup direction mapping used for forward validation:
  - LONG BUILDUP / SHORT COVERING => bullish
  - SHORT BUILDUP / LONG UNWINDING => bearish

## 6) Production hardening
New non-destructive production audit checks:
- critical JSON state parseability;
- free disk space;
- stale temp-file count;
- log/session/backtest-report counts;
- execution-lock expectation;
- market-session state.

Additional hardening:
- Optional `.wingo_state/market_holidays.json` override support for regular-session gating.
- Existing atomic JSON persistence, rotating application logs, safe shutdown, unified FYERS DataSocket, paper mark guard and dynamic subscription architecture remain preserved.
- Startup performs a lightweight non-destructive production audit.

## 7) AI Diagnostics
AI-readable diagnostics now also includes a bounded section for:
- roadmap research-suite status;
- historical market-context validation;
- best stop/target optimization result;
- latest live-paper/futures forward validation;
- latest production audit.

## Preserved safety / architecture
- Shared root `.venv` and `.env` remain unchanged.
- One FYERS market-data WebSocket transport architecture preserved.
- Futures 360ONE/numeric-leading-symbol integrity fix preserved.
- Paper multi-leg fresh-mark / P&L guard preserved.
- True live F&O breadth and regime preserved.
- FYERS Option Chain Greeks/IV handling preserved.
- Real broker execution remains **LOCKED** and no order-submission endpoint was added.

## Verification boundary
Static compile/AST, synthetic market-context, optimizer, futures-forward, full-suite persistence/reporting, one-WebSocket ownership and execution-lock tests pass in the build environment. PySide6 GUI rendering and live FYERS REST/WebSocket calls were not available in the build container; Windows/live-FYERS acceptance is still required.

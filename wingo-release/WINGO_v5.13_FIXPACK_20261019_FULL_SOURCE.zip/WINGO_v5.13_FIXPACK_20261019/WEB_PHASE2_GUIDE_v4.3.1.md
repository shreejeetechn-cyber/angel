# WINGO Web Phase 2 — उपयोग गाइड

## शुरू करें

1. Build को मौजूदा `Wingo` folder structure के अंदर रखें ताकि shared `.env`, `.venv` और `.wingo_state` मिल सकें।
2. `START_WINGO_WEB.bat` पर double-click करें।
3. Browser में `http://127.0.0.1:8787/` खुलेगा। Launcher window खुली रखें।
4. बंद करने के लिए launcher window में `Ctrl+C` दबाएँ।

## Workspaces

- **Scanner**: latest persisted full/runtime scan दिखाता है। Grade, direction और history provider filters उपलब्ध हैं।
- **Signals**: persisted signal lifecycle दिखाता है। State, signal type और quality filters उपलब्ध हैं।
- **Scheduled Entries**: Stage-2 passive entry intents, matching signal और Paper position को जोड़कर lifecycle दिखाता है। Status filter में Waiting/Ready, Filled और Failed groups हैं।

हर table में search, column-header sorting, 50-row pages और Previous/Next controls हैं। Header पर दोबारा click करने से sort direction बदलती है।

## Refresh

- **Refresh workspaces** disk पर मौजूद Scanner, Signals और Scheduled Entries state तुरंत दोबारा पढ़ता है।
- सामान्यतः बदलाव दो सेकंड के अंदर WebSocket से अपने आप दिखाई देते हैं।
- **Check all feeds** FYERS और Upstox के read-only auth/market-data health checks चलाता है।

## Empty या error स्थिति

- `MISSING`: संबंधित persisted file अभी मौजूद नहीं है। Desktop WINGO में उस workflow को चलाने के बाद data आएगा।
- `EMPTY`: file valid है, लेकिन उसमें display योग्य rows नहीं हैं।
- `ERROR`: file malformed, unreadable या safety size limit से बड़ी है। WINGO कोई नकली row नहीं बनाता।

Web Phase 2 scanner या signal engine स्वयं नहीं चलाता। यह desktop-generated centralized state का read-only view है।

## Feed reconnect और सुबह का token

- Broker token/OTP/TOTP setup existing desktop morning-auth workflow में ही करें; browser में secrets enter या display नहीं होते।
- Feed supervisor का interval 30 seconds और per-feed reconnect limit 20 attempts रहता है।
- Limit पहुँचने पर उस recovery cycle में connection abandoned/failed दिखेगा; supervisor के अगले eligible cycle या manual **Check now** से नया health attempt किया जा सकता है।
- दोनों feeds unavailable होने पर market ribbon blank रहता है; पुराना या fabricated tick current नहीं दिखाया जाता।

## Safety

Web app localhost-only और read-only है। यह entry edit, cancel, broker order submit या live execution unlock नहीं कर सकता। Stage 8 मौजूद नहीं है।


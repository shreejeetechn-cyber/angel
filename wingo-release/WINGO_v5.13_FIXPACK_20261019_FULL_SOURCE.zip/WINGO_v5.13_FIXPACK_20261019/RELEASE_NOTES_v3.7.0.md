# WINGO v3.7.0 — Professional Responsive Trading UI

Presentation-focused release on top of v3.6.4. The v3.6 Profitability research model, Crash/Hang Shield and live-execution lock remain in force.

## Professional responsive layout
- Main Dashboard market/provider cards reflow at width breakpoints instead of being squeezed.
- Main Dashboard summary cards reflow 8 → 4 → 2 → 1 columns as available width changes.
- Ctrl+Mouse Wheel remains window-scoped, but now uses density-aware factors: spacing/row geometry changes more than typography, preserving readability at compact settings.
- Main WINGO and Profitability Pop-Out retain independent persisted UI density.

## Mouse-resizable working areas
- Dashboard Top Opportunities vs right-side context uses a native horizontal splitter.
- Dashboard Breadth vs Alerts uses a native vertical splitter.
- Dashboard Heatmap / Index Trend / Score-Grade / Paper Performance use a native horizontal splitter.
- Dashboard splitter proportions persist with a 500 ms debounced settings write.
- Profitability Matrix vs detail area remains resizable.
- Profitability RSI / Market-Sector / Derivatives panels remain independently resizable.
- Profitability Reasons vs Shadow Validation is newly resizable and persisted.
- Splitter handles are visually highlighted on hover.

## Full-screen table focus
- Every table managed by WINGO's UniversalTableController gets a visible `□` Focus control.
- Table Tools and right-click menus also expose `Focus / Full Screen`.
- Focus mode is a live model mirror (`QTableView`) and does not reparent/remove the live source table.
- Source filters/hidden rows and hidden columns are mirrored on opening.
- Selection is shared where Qt permits; double-click is relayed to the source table action.
- Focus opens on the source window's monitor, including detached Profitability Pop-Out screens.
- `Esc` or `F11` exits focus mode.

## Safety / scope
- No broker `place_order()` call exists in application source.
- `ExecutionGate` remains unchanged and live execution remains locked.
- Crash/Hang Shield (`app/core/resilience.py`) is unchanged.
- Profitability calculation engines (RSI, lifecycle, VWAP, CVD, depth, scoring, strategy, OOS/performance and paper logic) are unchanged. `controller.py` changed only to persist the additional presentation splitter size.
- The v3.6.2 Python-side Profitability Matrix sorting fix remains intact.

## Known limitation not changed in this UI release
- The previously observed Windows Factory Fresh auto-restart `WinError 32` log-file locking workflow is not part of v3.7.0 and remains a separate pending reset-manager fix.
- Live Windows/PySide6 plus authenticated FYERS/Upstox market-hours behavior still needs on-machine acceptance testing; this Linux QA environment does not contain PySide6/broker SDK runtime sessions.

# WINGO v2.8.3 — Reliability & Readability Hardening

No new live-trading capability. Real broker submission remains locked.

Reliability fixes:
- Settings are now read dynamically at refresh time; newly generated FYERS/Dhan tokens are visible in the same running session.
- Stale/deleted dotenv keys are no longer silently retained from a previous dotenv load.
- Generic QThread cleanup is attached to `finished`, so UI callback exceptions cannot leak worker references.
- Duplicate identical background jobs are suppressed.
- Safe shutdown waits for active background threads instead of destroying running QThreads.
- Scanner Stop is a real STOPPED state. Partial scans are not saved as completed previous-scan baselines and do not show 100%.
- Futures/NSE/Options/Backtest/Acceptance/Validation failure states restore buttons/statuses.
- Paper live feed can be manually force-reconnected after error; ERROR/OFFLINE state is reflected in footer/UI.
- Persisted automation restarts its timer when WINGO restarts.
- Settings saves merge existing keys and preserve sidebar state.
- Shared `.env` setup now creates/copies the file at the WINGO root expected by the launcher.
- `run_wingo.bat` now uses robust WINGO-root discovery.

Dashboard correctness:
- Best Contract is cached after scoring and keyed by the exact underlying.
- Option score uses `opportunity_score`.
- New Signals counts only lifecycle state `NEW`.
- Index sparklines append only on new index ticks; full dashboard rebuild remains throttled.
- Session label is explicit that UI OPEN/CLOSED is the regular-session window.

Readability/UI:
- Minimum micro text increased (8/9 px usages hardened upward).
- Brighter blue/red/purple accent text on the dark theme.
- Compact button stylesheet avoids hard-height/padding clipping.
- Navigation uses bundled monochrome SVG icons; collapsed mode is icon-only with tooltips.
- Large page margins are normalized for a compact terminal layout.
- Old Phase/v1/v2 user-facing labels are removed/reworded.
- Diagnostics now includes a UI/control readiness matrix.
- Watchlist is functional and persistent; Scanner can pin selected symbols.

Additional hardening from final re-audit:
- Sensitive log output is recursively redacted for access tokens, refresh tokens, secret keys, auth codes, PIN/TOTP/password fields.
- Token/auth provider error messages no longer interpolate raw provider response dictionaries.
- FYERS auth-code, Dhan PIN and Dhan TOTP inputs are masked; sensitive fields clear after token success/failure.
- Persisted dataclass configs tolerate old/extra keys instead of breaking startup after an upgrade.
- New lifecycle signals are prioritized in Dashboard Alerts so the `NEW SIGNALS` card and visible event stream stay semantically aligned.
- Dense table labels use ASCII-safe `Chg`/`Chg %` forms instead of small delta glyphs.
- Dashboard custom-drawn text is >=9pt; page/panel spacing and global control padding are normalized for a sleeker layout.
- Diagnostics now reports subsystem states (`READY`, `BUSY`, `PASS`, `FAIL`, expected `DISABLED`) and includes Watchlist/Settings/Execution safety checks.

# WINGO v3.9.0 autonomous_shadow_intelligence

- Paper Auto Entry and Auto Exit start ON for evidence collection. Safe Start still suppresses automatic startup.
- A+/A signals may create one `SHADOW_BOOTSTRAP_AUTO` position when the promoted sample is still empty; all market, freshness, contract, policy, cash and risk gates remain active.
- Live broker execution remains locked and no broker order-placement path is included.
- Paper risk uses planned stop risk plus estimated round-trip costs and a 10% gap/latency buffer.
- Risk per trade accepts decimal percentages.
- Defined-risk option payoff bounds are recalculated from actual simulated leg fills.
- Exit audit records planned trigger, observed executable P&L and overshoot.
- Paper Positions can copy complete detail or export the selected position with every leg to JSON.
- Diagnostic exports include full Paper legs, costs, slippage, reconciliation and exit-trigger evidence.
- Universal table controls now occupy a dedicated toolbar row above the table; they no longer overlay column headers.

Broker/exchange margin remains explicitly identified by its source. When a provider-verified basket margin is unavailable, WINGO continues to label and use its conservative local defined-loss/estimated capital value; it never presents an estimate as broker-confirmed margin.

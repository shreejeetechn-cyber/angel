# WINGO v3.2.3 — Status Wiring + Acceptance/Data Guards

Build: `WINGO v3.2.3 Status Wiring + Acceptance/Data Guards (Execution Locked)`

## Runtime status contract

- The footer now includes FYERS and UPSTOX plus Scanner, Options, Futures,
  Paper and Data.
- Healthy initialized services show green `READY`; fresh realtime work shows
  green `LIVE`; work in progress/reconnect/staleness is amber; a confirmed
  failure is red. The UI does not manufacture green states.
- Options readiness comes from validated provider startup, not only a manual
  Option Chain timestamp.
- Futures readiness comes from the cached/live active contract master. Fresh
  snapshots still show `LIVE` and stale live-session snapshots still alert.
- Autonomous combined Futures + Options runs now update both freshness clocks,
  so the footer represents automatic intelligence as well as button clicks.
- An empty Paper book reports `ENGINE READY` rather than implying the engine
  has not been initialized.
- During a closed NSE session, validated/armed services report `READY` instead
  of treating the absence of ticks as an error.

## Acceptance and audit correctness

- Acceptance paper simulation now uses the current split Futures/Options
  exchange-charge configuration fields.
- Removed obsolete `brokerage_cap_per_order` and `exchange_charge_pct` fields
  that caused a deterministic `TypeError`.
- The background worker now retains Acceptance's declared PASS/WARN/FAIL in
  the session audit instead of overwriting it with callback PASS.

## Provider and trend-data guards

- `NSE:NIFTYFPI-INDEX` remains in the six-index scanner/history universe.
- FYERS live SymbolUpdate locally rejects only that provider-incompatible code,
  preventing repeated `-300 Please provide a valid symbol` resubscribe noise.
  The shared canonical plan and other providers remain unchanged.
- A restored previous-day complete scanner baseline can populate the UI but
  contributes zero weight to the current trend trade gate. Only a current-day
  completed scan may add the scanner regime contribution.
- Existing three-minute live breadth freshness gating remains enforced.

## Retained scope and safety

- All v3.2.2 ledger/tax/slippage, manual paper money, table tools, trend radio
  controls, cache/restart UI, RSI divergence A+/B+ page, NSE-only coverage and
  dashboard VIX/provider status work remains included.
- BSE and BSE-related products remain excluded.
- Credentials remain only in the common Wingo-root `.env`; runtime state stays
  in `.wingo_state`; the shared `.venv` is unchanged.
- Real broker execution remains locked.

# WINGO v5.00 RC dev3 — MainThread Responsiveness Hotfix

This hotfix keeps the RC dev3 product identity, inline daily broker login, Full MCX universe, Stage 0–7 contracts, and Live Execution lock unchanged.

## Changes
- MainWindow persistence hot paths now queue JSON writes on the existing `WINGO-Persistence` coalescing worker.
- Incremental scanner runtime snapshots are built in memory and persisted asynchronously.
- Autonomous learning `study()` runs through `FunctionWorker`; dashboard, reports and auto-paper ranking consume the latest completed state instead of recalculating on the GUI thread.
- Signals table computes one market-regime snapshot per refresh and reuses it for all rendered rows.
- Dashboard index tick aggregation has a 500 ms cache to avoid repeatedly scanning large router tick maps.
- Shutdown still performs a bounded background persistence flush before exit.

## Scope
No broker authentication protocol, feed provider protocol, MCX universe policy, profitability safety contract, or Live Execution gate was changed.

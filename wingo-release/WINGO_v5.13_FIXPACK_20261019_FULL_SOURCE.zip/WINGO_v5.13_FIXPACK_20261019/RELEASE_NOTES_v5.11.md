# WINGO 5.11

Small targeted release.

- Clears stale FYERS login-required/login-failed UI state after a validated FYERS Auth/History/Health PASS.
- Normalizes prefixed NSE cash references such as `NSE:RELIANCE` to FYERS transport form `NSE:RELIANCE-EQ`.
- Retains the FYERS WebSocket `map.json` packaging gate from the previous hotfix.
- Universal Toolbox is not bundled and is not versioned with this app release.
- Live execution remains locked.

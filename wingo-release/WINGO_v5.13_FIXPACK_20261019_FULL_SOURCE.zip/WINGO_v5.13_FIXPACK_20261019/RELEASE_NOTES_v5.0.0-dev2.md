# WINGO v5.0.0-dev2 — Multi-Exchange F&O + MCX Dual Provider Core

Development build based on the verified v5.0.0-dev1 canonical F&O core.

## Acceptance contract
1. Canonical `FnoInstrument` remains FUTURE/OPTION only and requires exact ISO expiry.
2. FYERS MCX named JSON master support added.
3. FYERS named JSON masters are primary; legacy NSE headerless CSV is compatibility fallback only. MCX never uses positional/NSE fallback.
4. Upstox MCX `MCX_FO` BOD master supported.
5. Exact FUT/CE/PE canonical identity maps to Upstox `instrument_key`.
6. Combined NSE+MCX Upstox registry supports mixed live transport mapping.
7. Futures Snapshot supports MCX through FYERS and Upstox provider routes.
8. MCX has no fabricated `-EQ`; scanner reference role is `FUTURE_PROXY`.
9. MCX Spot/Basis fields are not applicable (`None` / N/A state).
10. MCX near/next/far term structure supported.
11. Existing Options workspace operates in MCX context.
12. MCX chain is constructed from MCX_FO master + Full Quotes + Option Greeks; Put/Call Option Chain endpoint is not used for MCX.
13. One global `NSE | MCX` selector is in the first Desktop/Web header; Futures/Options controls are not duplicated.
14. Subscription planning is exchange-aware and cross-exchange safe.
15. MCX scanner uses the nearest exact future as a `FUTURE_PROXY` reference series.
16. NSE breadth/index/VIX regime is zero-weight and not applied to MCX manual Futures/Options analysis.
17. Live Execution remains LOCKED; Stage 8 remains absent.
18. Profitability Auto Pop Out remains disabled; manual pop-out remains available.

## Storage isolation
Market-specific state is routed below `.wingo_state/markets/NSE` and `.wingo_state/markets/MCX`. Legacy state fallback is NSE-only.

## Safety
This development build does not unlock live execution and does not synthesize MCX cash/spot identities.

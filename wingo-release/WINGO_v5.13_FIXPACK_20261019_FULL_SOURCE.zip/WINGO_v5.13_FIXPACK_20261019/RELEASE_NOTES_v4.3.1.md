# WINGO v4.3.1 — Local Web Dashboard Phase 2

## Delivered

- Adds browser workspaces for Scanner, Signals and Scheduled Entries.
- Reads the existing centralized `.wingo_state` files without changing desktop engines or duplicating state.
- Publishes normalized workspace updates through the existing local WebSocket and dedicated read-only REST APIs.
- Adds search, categorical filters, sortable columns, 50-row pagination and explicit loading/missing/empty/error states.
- Derives Scheduled Entries from persisted Stage-2 passive intents, signal records and Paper positions using the existing desktop lifecycle semantics.
- Adds a manual **Refresh workspaces** action and two-second background change detection.

## Data and security boundary

- The browser receives only a fixed whitelist of fields, with credential-like text redacted.
- Each source file is size-bounded and each workspace is capped at 1,000 browser rows.
- Absolute state paths, raw provider responses, tokens, PINs, OTP/TOTP values and authorization codes are not exposed.
- No missing row is fabricated. Missing, empty and malformed state are shown as such.
- The web app is still localhost-only.

## Execution boundary

Phase 2 is monitoring-only. It cannot run the scanner, create signals, edit schedules, submit or cancel broker orders. Stage 8 is absent and live execution remains locked.


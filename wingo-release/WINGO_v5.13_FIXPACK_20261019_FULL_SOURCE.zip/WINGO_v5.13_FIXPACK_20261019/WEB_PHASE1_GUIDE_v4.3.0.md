# WINGO v4.3.0 Web Phase 1 Guide

## Starting

1. Confirm the centralized `Wingo\.env` and shared Python 3.12 `Wingo\.venv` are present.
2. Double-click `START_WINGO_WEB.bat`.
3. Wait for the browser to open `http://127.0.0.1:8787/`.
4. Do not close the launcher window while using the web dashboard.

The first launch may take longer because the launcher verifies and, if necessary, installs the pinned web dependencies in the existing shared environment.

## Reading the dashboard

- **Live status** means the browser WebSocket is connected to the local WINGO backend.
- **CONNECTED** on a broker card means its real authentication and index market-data checks passed.
- **TOKEN REQUIRED** means authentication must be completed through the existing desktop morning-auth flow.
- **ERROR** means the last real broker check failed. The message is sanitized before it reaches the browser.
- **Active market feed** follows the centralized primary-feed and automatic-failover settings.
- The market ribbon remains blank when no provider is currently verified.

## Manual refresh

- Select **Check all feeds** to request both broker checks.
- Select **Check now** on one provider card to request only that provider.
- Automatic checks continue every 30 seconds.

## Stopping

Return to the launcher window and press `Ctrl+C`. Closing only the browser tab does not stop the local backend.

## Security and network boundary

- Phase 1 is accessible only from the same Windows PC.
- It is not exposed to the internet or other LAN devices.
- Credentials remain in the centralized server-side `.env`; the API exposes presence flags only.
- Port `8787` is separate from the OAuth loopback example on port `8765`.
- Live broker order execution is not present.

# WINGO v5.08 — Calculation Integrity + Lean Compute + Memory Stability

## Main changes
- Hardened MCX Option contract economics: broker lot, qty multiplier and economic quantity are explicit and separated.
- Hardened option quote freshness: provider quote timestamp is authoritative; analysis/completion time cannot make stale/missing market data fresh.
- Bounded Profitability analytics and session/log queues to prevent runaway RAM growth.
- Added process/system memory and queue/backlog diagnostics with pressure-aware non-critical throttling that preserves critical calculation sequences.
- Removed repeated dotenv parsing from provider-liveness hot paths through signature-cached settings refresh.
- Refactored CVD storage to one canonical rolling stream while preserving exact 1m/3m/5m/15m outputs.
- Reduced duplicate RSI/OBV work with deterministic parity tests.
- Reduced repeated Profitability historical evidence/context scans using indexing/revision caching.
- Added Paper/Signal revision-keyed snapshots and bounded Web JSON parsing cache.
- Hardened exchange-aware DTE and weekly/monthly timestamp handling; made futures OI reference semantics explicit.
- Hardened Profitability resize/autofit behavior and retained v5.07 pop-out lifecycle cleanup.
- Reused latest tick/observation maps across Stage 2-6 and reduced redundant Stage-1 decision receipts without skipping underlying microstructure processing.
- Staggered recurring heavy timers and added live compute timing diagnostics.

## Offline release gate
- 480/480 active assertions PASS.
- 329/329 Python AST PASS.
- 1000-tick Stage 1-7 stress median approximately 14 ms in the offline synthetic environment; maximum below 100 ms budget.
- 5000-signal bounded rendering and 20-minute-equivalent CVD soak PASS.

## Safety
- Live Execution remains LOCKED.
- Stage 8 remains ABSENT.
- No OTP/TOTP/PIN/password storage or generation added.

## Runtime-only pending
Real Windows/broker-session validation remains required for live LTP, live broker lot/multiplier consensus, authenticated margin, hard reconnect recovery, live multi-popout heartbeat and real exchange-session boundaries.

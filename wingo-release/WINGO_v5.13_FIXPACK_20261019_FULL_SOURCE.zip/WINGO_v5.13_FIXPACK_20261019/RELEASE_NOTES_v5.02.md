# WINGO v5.02 — Profitability Policy v2

WINGO v5.02 is the incremental release identity for the verified Profitability Policy v2 hotfix previously built on v5.01. Functional policy behavior is unchanged from that verified hotfix; this promotion makes it the next official WINGO version.

## Profitability Policy v2

- First-class Profitability Policy ON/OFF control.
- Policy modes: ADVISORY, BALANCED, STRICT, AUTO.
- `Show blocked opportunities` defaults ON.
- Scheduled Entries are calculated and attached before Auto Paper admission, so profitability/promotion failure does not make the Scheduled Entries workspace blank.
- Scheduled rows can show CALCULATED, LOW SAMPLE, BLOCKED, FILLED and terminal states.
- AUTO profitability qualification uses source-separated AUTO evidence; MANUAL results cannot qualify AUTO Paper.
- Sparse AUTO evidence falls back only within AUTO history.
- Blocking reasons and advisory reasons are reported separately.
- Unknown spread/depth/liquidity metadata remains explicit rather than silently treated as known-good or known-bad.

## Recommended baseline

- Minimum sample: 8
- Minimum sessions: 5
- Min expected ₹/lot: 1.00
- Min edge/cost: 1.50
- Min payoff: 1.20
- Min profit factor: 1.30
- Max spread: 2.50%
- Top candidates/cycle: 3

Legacy looser saved sample/session/profit-factor floors are raised once to the recommended baseline and spread is capped at 2.50%; stricter user values are not loosened. Existing stop/target/trailing preferences remain unchanged.

## Safety retained

- Stage 0–7 retained.
- Stage 8 execution engine absent.
- Live Execution LOCKED.
- Inline FYERS/Upstox daily login unchanged.
- Full MCX universe unchanged.
- MainThread async persistence/stall hotfix retained.
- Central Wingo root `.env` remains external and is not packaged.

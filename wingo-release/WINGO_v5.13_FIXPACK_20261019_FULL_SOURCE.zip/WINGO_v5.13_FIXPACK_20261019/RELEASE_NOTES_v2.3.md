# WINGO v2.3 Contract Workspace

## Option Workspace
- Added visible Expiry dropdown.
- Existing raw timestamp input is hidden.
- Underlying symbol can load available FYERS expiries.
- AUTO / NEAREST option remains.
- Selected expiry is used for option-chain fetch.

## Futures Contract Snapshot
- After Sync FYERS Futures Master, a consolidated contracts list appears.
- Columns: Script, Expiry, Lot Size, Future Symbol, Status.
- Search by script / expiry / symbol.
- Single-click: selects Script + Expiry.
- Double-click: opens full Spot/Future/Basis/OI/Volume snapshot.
- Existing Near/Next/Far comparison remains.
- Scanner -> Futures drill-down filters the consolidated list to the selected script.

## Safety
- No live order execution.

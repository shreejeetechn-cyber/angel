# WINGO v4.3.2 — GUI Stall Hotfix

## Scope
Targeted stability patch over the verified v4.3.1 Local Web Dashboard Phase 2 build. Live execution remains locked.

## Fixes
- Signals table refresh is now debounced/coalesced instead of rebuilding immediately for every refresh request.
- Signals rows are rendered in small Qt event-loop chunks so the GUI heartbeat continues while large signal books are painted.
- Unchanged non-semantic table cells are retained; semantic cells are rebuilt safely to preserve theme/status colouring.
- Refresh requests received during rendering are merged into one follow-up pass.
- Auto-strategy queue completion continues to perform one logical Signals refresh, but that refresh is now non-blocking.
- Profitability MTF history batches have a finite 60–180 second cooperative deadline (scaled by requested universe) and return partial results instead of remaining RUNNING indefinitely.
- Generic FunctionWorker dispatch now forwards cancellation/deadline controls only to jobs that explicitly support them.

## Root cause addressed
The v4.3.1 hang report captured MainThread inside `_run_next_auto_strategy -> _refresh_signals_table -> _table_tone` with a GUI heartbeat older than 10 seconds. This build removes the monolithic MainThread table rebuild without changing feed selection, strategy scoring, paper policy, or live-execution lock.

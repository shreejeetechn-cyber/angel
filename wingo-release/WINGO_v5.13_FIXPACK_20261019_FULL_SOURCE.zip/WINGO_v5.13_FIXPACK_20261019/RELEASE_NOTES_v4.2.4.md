# WINGO v4.2.4 — Bearish Alignment + Exploratory Paper Bootstrap + Stage-2 Top-of-Book

## Purpose
This patch closes the gap where WINGO could correctly identify a STRONG BEARISH market yet fail to convert that information into a directional Paper opportunity. Live execution remains locked.

## Changes
- Normalizes display-strength regime labels for trading logic: STRONG BEARISH → BEARISH, STRONG BULLISH → BULLISH.
- In AUTO Paper only, DEFAULT policy becomes WITH_TREND when the market is HIGH-confidence STRONG BULLISH/BEARISH. Manual/default research views remain balanced.
- Treats long BUY_CALL / BUY_PUT as defined-risk strategies; they no longer require a spread rebuild only because they are single-leg.
- Adds safe cold-start exploratory Paper collection. A/A+ aligned setups may take at most one 1-lot AUTO_BOOTSTRAP position when promotion history is insufficient. This is explicitly not profitability-validated and never unlocks live execution.
- Exploratory bootstrap still requires market alignment, VWAP alignment, liquidity, fresh data, risk/capital/session gates and defined risk. Sector/OI are recorded but are not hard bootstrap gates.
- Separates full market-maker readiness from directional Stage-2 Paper readiness. Real top-of-book bid/ask + quantity + fresh timestamp + Greeks can produce DEGRADED directional readiness without pretending 5-level depth exists.
- Stage 2 may join the real best bid/ask in DEGRADED mode. It does not invent queue quantity, does not create a broker order and still requires later trade-through for a fill.
- Higher market-maker stages continue to require full READY depth.
- Paper P&L is split into TODAY, SESSION, AUTO, MANUAL, STAGE-2, BOOTSTRAP and LIFETIME views. Carried open positions are excluded from Session delta when no trustworthy session-start mark exists.
- Smart Passive Paper now shows a visible empty-state explanation and archived Stage-2 intents instead of a blank table.

## Safety
- Stage 8 execution engine remains absent.
- Live execution remains locked.
- No broker submission path is added to Stage 2.

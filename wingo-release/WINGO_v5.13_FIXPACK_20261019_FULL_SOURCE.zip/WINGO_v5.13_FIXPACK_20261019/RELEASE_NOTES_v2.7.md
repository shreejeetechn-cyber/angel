# WINGO v2.7 — UI Final Alignment

Visual alignment pass against the original roadmap dashboard reference.

Changes:
- Collapsed sidebar upgraded with readable icon-like glyphs.
- Collapsed sidebar width increased for clarity.
- Top market strip tightened.
- NIFTY/BANKNIFTY sparkline cards compacted.
- Summary cards rebalanced:
  Total F&O, Bullish, Bearish, Neutral, A+/A, New Signals,
  Active Positive, Total P&L.
- Dashboard filter/regime row made compact.
- Top Opportunities typography/column handling improved.
- RSI values displayed at one decimal.
- True tile-based RSI heatmap replaces table-style heatmap.
- Added dedicated Index Trend panel.
- Breadth and Alerts panels rebalanced.
- Paper Performance area widened.
- Footer status font/spacing improved.

No scanner/market-data algorithms changed.
Realtime scan updates from v2.6 are preserved.
Execution remains locked.

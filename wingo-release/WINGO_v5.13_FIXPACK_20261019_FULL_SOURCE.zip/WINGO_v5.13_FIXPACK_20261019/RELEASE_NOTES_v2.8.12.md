# WINGO v2.8.12 — Persistent Scanner + Dynamic Subscriptions

## Daily market lifecycle

After FYERS daily bootstrap passes Auth, History and Full Health, WINGO now:

1. Restores the latest scanner snapshot into the Dashboard immediately.
2. Loads Futures Master automatically for dynamic futures subscriptions.
3. During market hours, automatically starts the scanner policy engine.
4. If today's complete baseline exists, it skips a zero-based full rescan.
5. If a prior baseline was interrupted, it resumes only pending symbols.
6. If no current baseline exists, it starts the full F&O universe scan.
7. After the baseline is ready, scheduled automation refreshes only the priority universe.

## Persistent scanner state

State lives under `.wingo_state/scanner/`:

- `latest_full_scan.json` — canonical daily full-universe baseline.
- `latest_runtime.json` — latest incremental overlay used by Dashboard restore.
- `latest_checkpoint.json` — in-progress full scan checkpoint.
- `checkpoints/YYYY-MM-DD.json` — daily checkpoint audit copy.
- `snapshots/YYYY-MM-DD_full.json` — canonical daily baseline copy.
- `snapshots/YYYYMMDD_HHMMSS_full.json` — bounded recent baseline history (last 10).

A checkpoint is written every five processed symbols and again on clean shutdown.
After a restart, completed symbols are retained and only pending symbols are scanned.
A completed baseline with failed symbols does not cause successful symbols to be rescanned: failed symbols remain eligible for retry on the next session/incremental cycle.

## Dashboard restore

The Dashboard is no longer dependent on a scanner starting from zero. It restores the best available persistent scanner state first, then receives fresh incremental/live overlays. Legacy `scanner_history.json` is supported as a visual-only fallback for the first v2.8.12 migration.

## Dynamic Main Live WebSocket subscriptions

The Main Live Feed is auto-managed. The manual symbol field is read-only. The planner prioritizes:

1. NIFTY and BANKNIFTY core indices.
2. Active lifecycle signal underlying/option symbols.
3. Current Futures/Options workspace underlying.
4. Up to 6 liquid A/B contracts from the currently analyzed Option Scanner.
5. Up to 15 A+/A scanner opportunity underlyings.
6. Up to 8 Near futures for selected/top opportunity scripts after Futures Master is available.
7. Watchlist scripts.

Main-feed soft cap: 50 symbols.
Removed contexts receive a 5-minute anti-churn grace period before unsubscribe.
FYERS subscriptions are changed in-place; the socket is not restarted merely because the desired symbol set changed. Provider subscription acknowledgement remains the source of truth.

## Futures / Options live bridge

- Near futures can be subscribed progressively while the full underlying scan is running because Futures Master now loads immediately after FYERS health passes.
- Futures Spot/Future LTP and derived basis/contract value can be updated by subscribed ticks between REST snapshots. Depth/OI/buildup remain provider snapshot analytics.
- Option Scanner continues to fetch/normalize the chain through the supported FYERS option-chain API. Only shortlisted analyzed contracts are promoted to the Main WebSocket; the complete option chain is not streamed.
- Option live ticks update shortlisted contract premium/LTP. Greeks/IV/OI remain tied to the last option-chain snapshot until the next analysis refresh.

## Incremental monitoring

Scheduled scanner automation no longer launches a repeated full-universe scan. It refreshes a bounded priority set (max 30) made from:

- unresolved scanner errors (bounded retry set),
- A+/A and WATCH candidates,
- watchlist,
- active signals,
- selected Futures/Options workspace symbols.

The daily full-baseline timestamp remains intact when an incremental refresh completes.

## Safety

- Real execution remains locked.
- Paper Option Feed remains separate and subscribes only OPEN paper positions.
- Tokens/auth codes are not intentionally logged. Existing redaction remains active.
- Live FYERS dynamic subscribe/unsubscribe behavior requires acceptance on the user's Windows/FYERS session; it cannot be network-validated in the build container.

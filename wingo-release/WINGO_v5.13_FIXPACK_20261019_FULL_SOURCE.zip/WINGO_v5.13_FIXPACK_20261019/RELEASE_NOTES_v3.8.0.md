# WINGO v3.8.0 profitability_roadmap

Paper/Shadow profitability upgrade for NSE F&O. BSE remains excluded and live execution remains hard locked.

- Signed debit/credit cashflows with lot-size and ratio-correct multi-leg arithmetic.
- Executable marking: long legs close at BID, short legs close at ASK; incomplete/stale legs freeze the prior valid snapshot.
- Charges, entry/exit slippage, gross/net P&L and reconciliation status are visible and persisted.
- Edge-after-cost NO TRADE gate, strict strategy/regime evidence, top-1/2 ranking and concentration controls.
- Position-level currency stop, optional cost-aware break-even, monotonic trailing profit and prioritized atomic exits.
- Manual versus Auto evidence is separated; invalid/unreconciled observations are excluded from analytics.
- Profitability Data Matrix and Paper Positions/Ledger expose edge, evidence, reconciliation and protection fields.
- Promotion remains Historical -> OOS -> Shadow -> Baseline uplift; live eligibility is always false in this build.

# WINGO v3.4.1 - Session-Aware Full Auto-Run

- Added `WINGO_AUTO_RUN=1` master startup policy, enabled by default.
- Automatically maintains provider validation, eligible feed connection,
  daily RSI baseline/resume, interval scans, Futures/Options intelligence,
  market breadth, signals, Super Panel and validated paper lifecycle.
- Added bounded three-minute recovery checks without bypassing the configured
  scan interval or creating duplicate background jobs.
- Retains every OPEN Profitability Lab Shadow/validated Paper symbol in the
  canonical live subscription plan until it receives a closing mark.
- Market-closed state is ARMED rather than falsely reported as completed.
- Interactive broker authentication remains manual when required.
- Live broker execution remains locked; automation is analysis and paper-only.

# WINGO v2.8.2 — Futures Intelligence

Functional audit fixes:
- Correct spot symbol mapping for index futures:
  NIFTY, BANKNIFTY, FINNIFTY, MIDCPNIFTY, NIFTYNXT50.
- FYERS Quotes is no longer treated as an OI source.
- Future OI is requested from FYERS Market Depth when `depth()` is available.
- OI source is explicit: FYERS DEPTH or UNAVAILABLE.
- Index lot size can fall back to FYERS Symbol Master lot.
- Expiry parsing is more robust when both last-update and expiry timestamps exist.
- Expired contracts are filtered from the active master view.

New snapshot analytics:
- Near / Next / Far series
- Days to expiry
- Spot change %
- Future change %
- Basis / Basis %
- Annualized basis %
- Contango / Backwardation
- Basis change / trend
- Contract value
- OI / Delta OI / Delta OI %
- Volume / OI ratio
- Bid / Ask / Spread %
- Buildup
- Lot source
- OI source

Term Structure:
- one batched Quotes request for Spot + first 3 futures
- Depth request per futures contract for OI
- Near / Next / Far comparison table

UI:
- compact Futures Intelligence page
- consolidated active contracts table
- series + DTE + lot source
- optional Auto Refresh 10s (OFF by default)
- single click selects contract
- double click opens full snapshot

No live order execution.

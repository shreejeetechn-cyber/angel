# WINGO v2.8.6 — Live Feed Lifecycle

Fixes the case where:
- Session is OPEN
- FYERS Health Check passes
- Connect Live Feed immediately becomes OFFLINE

Changes:
- Generic provider/transport errors no longer call stop().
- reconnect=True is allowed to do its job.
- Close callback becomes RECONNECTING unless user explicitly disconnected.
- QThread remains alive even if SDK connect() returns while callbacks continue.
- Removed race-prone second keep_running() fallback.
- AUTH and SUBSCRIPTION errors remain fatal.
- MODE warnings are non-fatal.
- Exact close reason stays visible.
- Footer shows RECONNECTING in amber.
- Current documented simultaneous subscription safety cap: 200 symbols.

Expected healthy flow:
AUTH CHECK -> AUTH PASS -> CONNECTING -> CONNECTED ->
SUBSCRIPTION SENT -> SUBSCRIBED

Transient network flow:
RECONNECTING -> CONNECTED -> SUBSCRIBED

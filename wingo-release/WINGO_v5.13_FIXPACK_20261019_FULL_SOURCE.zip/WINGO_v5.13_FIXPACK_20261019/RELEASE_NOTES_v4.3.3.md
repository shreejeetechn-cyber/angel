# WINGO v4.3.3 — Runtime Stability Hotfix

Build: `WINGO v4.3.3 Runtime Stability Hotfix (Live Execution Locked)`

## Why this release exists

Three independent v4.3.2 watchdog reports captured GUI/MainThread stalls in:

1. live Profitability/CVD ingestion from `_flush_live_tick_buffer`,
2. Session Status table refresh / resize persistence,
3. deferred Profitability row rebuild / latest-tick alias lookup.

v4.3.2's chunked Signals renderer prevented the original monolithic table rebuild, but large restored signal books still spent minutes rendering rows that the ACTIVE view later hid.

## Runtime stability changes

- Profitability live tick ingestion is now queued to one dedicated `WINGO-ProfitabilityAnalytics` worker.
- The 750-ms Qt analysis timer only wakes the worker; it no longer performs heavy row rebuilds on the GUI thread.
- Profitability rebuild work is processed in bounded time slices.
- Profitability visible refresh settings are unchanged. `MANUAL` still uses the configured minute cadence (default 5 minutes); backend analytics remain live.
- Live GUI ingress drains at most 3,000 raw events per 250-ms slice instead of 12,000.
- CVD trade-marker deduplication now uses a bounded deque + set for O(1) duplicate checks while retaining the 2,000-marker memory limit.
- Profitability latest-tick lookup now uses a reverse alias index rather than scanning every alias for every rebuilt row.

## Session Status stability

- Bulk Session Status refresh blocks table/header signals.
- Programmatic column changes marked `wingo_bulk_update` no longer trigger manual layout persistence.
- Existing table items are reused when text is unchanged.
- Session Status auto-fit is scheduled only when row count changes.

## Signals rendering v2

- ACTIVE view removes terminal signals before Qt rows are created.
- OPTIONS and FUTURES views pre-filter by asset type before rendering.
- The complete signal book is still retained for filter choices, policy evaluation, persistence, and diagnostics.
- Refresh diagnostics now log `rendered=<n> | total=<n>`.

## Upstox silent-stale recovery

- `SUBSCRIBED` transport state is no longer treated as proof of fresh market data.
- During market OPEN, a running Upstox feed with no fresh ticks for >30 seconds is marked `STALE`.
- WINGO issues bounded force-resubscribe attempts.
- After three unsuccessful attempts, recovery enters a 5-minute cooldown and then re-arms automatically; the feed is not permanently abandoned.
- Fresh ticks transition the feed back to `LIVE` and reset recovery counters.

## Preserved safety / operational contracts

- Stage 8 execution engine: NOT PRESENT.
- Live execution remains LOCKED.
- Shared environment remains `C:\Wingo\.venv`.
- Centralized environment file remains `C:\Wingo\.env`.
- Desktop launcher still enforces Python 3.12 and repairs missing dependencies through `requirements.txt`.
- Local Web Dashboard Phase 2 remains present.

## Deliberately not changed in this release

FYERS full-set subscription lifecycle was not rewritten into differential add/remove subscription calls. That changes broker transport semantics and should be validated separately against the live FYERS SDK. v4.3.3 focuses on the confirmed GUI hang paths and Upstox silent-stale recovery.

## Verification

- `qa/verify_v4_3_3_runtime_stability_hotfix.py`: PASS.
- Python compile/AST verification: PASS.
- v4.2.10 Profitability MTF + Manual Minute Refresh regression contract: PASS on compatibility identity copy.
- v4.2.8 performance/CVD/scanner-cache regression contract: PASS on compatibility identity copy.
- 10,000-tick background queue smoke test: queue accepted in ~0.03 ms in the test environment and drained to zero backlog.

PySide6 is not installed in the build container, so an actual Qt/Windows multi-monitor runtime soak test could not be executed here. The definitive validation is a Windows v4.3.3 session with watchdog diagnostics enabled.

# WINGO v2.8.13 — Signal & Strategy Intelligence

## Standard signal model

Trade type and lifecycle are now separate concepts.

Primary trade signal types:
- `BUY_CALL`
- `BUY_PUT`
- `SELL_CALL`
- `SELL_PUT`
- `FUTURE_BUY`
- `FUTURE_SELL`

Lifecycle states remain:
- `NEW`
- `ACTIVE`
- `IMPROVING`
- `WEAKENING`
- `INVALIDATED`
- `EXIT`
- `EXPIRED`

Older saved option signals/positions are migrated with safe defaults.

## Greeks-aware strategy engine

Option decisions now use Delta, Gamma, Theta, Vega and snapshot IV context.
Multi-leg recommendations carry net position Greeks, while the primary-leg
Greek fit score is preserved for diagnostics.

Implemented recommendation structures:
- LONG_CALL
- LONG_PUT
- BULL_CALL_SPREAD
- BEAR_PUT_SPREAD
- BULL_PUT_SPREAD
- BEAR_CALL_SPREAD
- LONG_STRADDLE
- LONG_STRANGLE
- IRON_CONDOR

Premium-selling recommendations use defined-risk wings/spreads by default;
WINGO does not make naked short-call/short-put the default strategy.

Snapshot IV is labeled as a chain IV regime only. WINGO does not invent IV
Rank/IV Percentile without a historical IV series.

## Futures signals

Futures Snapshot can create standardized `FUTURE_BUY` / `FUTURE_SELL` signals
when buildup, price direction and OI context confirm. The recommendation carries
entry reference, stop reference, target reference, per-unit risk/reward and
lot-level risk/reward.

Superseded or no-longer-confirmed Futures signals are invalidated so stale
contracts do not remain eligible/subscribed.

## Strategy P&L and risk

Recommendations expose where applicable:
- entry/debit/credit per unit
- max profit per unit / lot
- max loss per unit / lot
- breakeven(s)
- reward:risk
- expiry P&L scenario grid
- one-day Greek approximation using Delta/Gamma/Theta/Vega

These are analytical estimates and exclude brokerage, exchange charges, taxes,
slippage, funding/margin cost and model error.

## Autonomous Auto Strategy Queue

After a daily scanner baseline is restored or completed, and after meaningful
incremental scanner refreshes, WINGO can automatically analyze the strongest
fresh A+/A directional candidates.

Default queue behavior:
- top 3 candidates
- sequential processing (no option-chain request storm)
- 15-minute per-underlying cooldown
- best-effort Near Future confirmation
- FYERS Option Chain fetch
- liquidity + opportunity scoring
- Greeks/IV strategy ranking
- standardized signal creation

The queue always advances even if one candidate callback fails.

## Cross-asset Auto Paper choice

For each auto-analyzed underlying, WINGO compares the current Futures signal
against the best paper-eligible option strategy. Exactly one is marked as the
preferred Auto Paper candidate for that underlying. Alternatives remain visible
as lifecycle signals but cannot race into duplicate positions.

AUTO ENTRY remains **OFF by default**. When enabled, Paper Automation still
requires market OPEN, signal freshness, minimum quality, max-position limits,
duplicate protection and Risk Engine approval.

## Multi-leg Paper engine

Paper positions now persist strategy semantics and legs. Live marking supports
BUY/SELL legs, defined-risk spreads, neutral structures and short Futures.
Strategy exits use marked P&L against risk reference; single-leg positions retain
direction-aware price SL/target handling.

The Paper Live Feed subscribes every live leg symbol for an open position.

## Subscription hygiene

Current strategy analysis invalidates superseded same-underlying option signals.
This prevents stale strategy legs from accumulating indefinitely in the dynamic
WebSocket subscription plan.

## UI

Options Workspace adds:
- individual contract Greek Fit
- recommended Signal Type
- recommended Strategy
- ranked Strategy Recommendations
- net position Delta/Gamma/Theta/Vega in the best-strategy summary
- max profit/loss, breakeven and R:R
- expiry and Greek P&L scenario text

Signals table now shows standardized signal type, strategy, asset class, Greek
fit and risk/reward fields. Paper table shows asset, signal type, strategy, legs,
risk/reward and live state. Futures Intelligence shows its trade recommendation.

## Safety

- Real broker execution remains locked.
- Dhan remains parked unless separately configured/subscribed.
- No token/auth-code values are intentionally logged.
- Safe Start still suppresses automatic FYERS/bootstrap/scan/strategy/live
  startup services.

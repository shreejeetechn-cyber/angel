@echo off
setlocal EnableExtensions
cd /d "%~dp0developer_tools\WINGO_TOOLBOX_v1.0.5"
call START_TOOLBOX_FROM_SOURCE.bat
exit /b %ERRORLEVEL%

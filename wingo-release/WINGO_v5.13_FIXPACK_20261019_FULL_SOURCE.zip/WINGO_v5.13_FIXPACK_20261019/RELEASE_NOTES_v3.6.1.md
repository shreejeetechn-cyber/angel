# WINGO v3.6.1 — Roadmap Resilience Shield

This is a lightweight hardening release on top of v3.6.0 Roadmap Logic Completion. It does **not** change Profitability Lab scoring, lifecycle, VWAP/OI/CVD logic, strategy selection, OOS validation, or execution policy. Live broker execution remains locked.

## Lightweight crash/hang resilience
- Bootstrap logging and resilience initialize before PySide6 and MainWindow imports.
- Dedicated sanitized crash reports under `.wingo_state/crashes/WINGO_CRASH_*.txt`.
- Dedicated GUI-stall reports under `.wingo_state/crashes/WINGO_HANG_*.txt`.
- Python `faulthandler` native-fault stream enabled before heavy UI/broker imports.
- C-level faulthandler hang fallback is re-armed by the GUI heartbeat; healthy operation emits no recurring dump files.
- `sys.excepthook`, `threading.excepthook`, and `sys.unraisablehook` are covered.
- Background `FunctionWorker` failures retain the compact UI message but now persist the full traceback in the rotating WINGO log.
- Abnormal previous exit is detected using an atomic run-state marker and dead-PID check.
- After a confirmed abnormal prior exit, WINGO offers temporary Safe Start before constructing MainWindow.
- A Python-thread watchdog records stacks after a 10-second missing GUI heartbeat; it never kills or auto-restarts WINGO.
- Crash and hang reports are bounded/pruned (20 per kind); empty native-fault streams are removed after a healthy run.
- AI Diagnostics now includes recent crash/hang/native resilience evidence.
- Production Hardening audit reports crash/hang/native-fault counts and last-problem metadata.

## Recovery philosophy
- Diagnostic capture first; no watchdog-triggered forced termination.
- Safe Start does not delete saved settings or positions.
- A clean Qt return atomically marks the run as clean; fatal termination leaves the marker unclean for the next-start recovery prompt.

## Roadmap compatibility
- v3.6.0 research logic remains unchanged.
- This release strengthens the roadmap's release-safety/crash-isolation objective without starting a new profitability phase.
- Real Windows GUI plus authenticated FYERS/Upstox market-hours acceptance testing is still required before calling the desktop runtime operationally proven.

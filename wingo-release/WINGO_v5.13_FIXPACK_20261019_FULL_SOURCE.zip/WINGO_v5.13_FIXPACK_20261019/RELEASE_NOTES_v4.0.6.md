# WINGO v4.0.6 autonomous_ai_trade_planner

## Summary

v4.0.6 is a dashboard-presentation refinement release built on v4.0.5. It keeps the v4.0.5 startup hotfix and all v4.0.4 AI/planner/learning/reporting behavior, while redesigning the main dashboard ribbon for one-line operational clarity and brighter, elegant, colorful, high-opacity border styling. Live execution remains locked.

## New in v4.0.6

- Large `WINGO Dashboard Pro` branding removed from the top dashboard ribbon.
- Replaced with a compact `WINGO` badge so the operational controls remain on one line.
- `SESSION`, `PRIMARY / ACTIVE`, `LAST FULL SCAN`, and `UPDATED` now render as compact bright inline pills.
- `ALARMS` remains a dedicated right-side button and feed badges remain clickable.
- `NIFTY 50`, `BANK NIFTY`, and `INDIA VIX` cards now use colorful high-opacity border styling and a clearer dark gradient surface.
- Existing BANK NIFTY sparkline binding fix retained.

## Verification notes

- Python compileall pass.
- Static dashboard GUI contract checked for the one-line ribbon and colorful card styling.
- Qt attribute collision scan still passes.
- Startup-alert regression from v4.0.5 still passes.
- Live execution remains locked.

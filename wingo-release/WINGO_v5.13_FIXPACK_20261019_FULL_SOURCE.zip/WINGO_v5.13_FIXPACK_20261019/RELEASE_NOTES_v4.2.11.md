# WINGO v4.2.11 — Dual-Feed GUI Stability Hotfix

Base: v4.2.10 Profitability Multi-Timeframe + Manual Minute Refresh.

## Fixed

- Prevents FYERS and Upstox full resubscription when the same symbol membership arrives in a different order.
- Clears stale FYERS dirty state when desired and active memberships are already equal.
- Makes FYERS subscription ACK comparison order-independent.
- Preserves established plan order for membership-equivalent dynamic plans.
- Limits Profitability analysis to 16 symbols per 750 ms event-loop slice.
- Stops constructing an unused CVD snapshot for every raw tick.
- Updates bounded live-candle state in place instead of copying it per tick.
- Avoids duplicate MTF candle merge and caches MTF snapshots for 30 seconds.
- Queues provider, subscription-plan and table-layout persistence away from the GUI thread.
- Debounces session-status refresh and performs one bulk table update.
- Suppresses automatic table fit for hidden tables and during bulk row insertion.

## Safety invariants

- Stage 8 execution engine remains absent.
- Live execution remains locked.
- Paper/Shadow behaviour and existing v4.2.10 features remain available.
- Centralized `C:\\Wingo\\.env` configuration remains unchanged.

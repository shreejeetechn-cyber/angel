# WINGO F&O_UPGRADE — Signal + Paper F&O Intelligence

## Base
WINGO Desktop v3.7.15 Signal Page Readability & Lifecycle Observability.

## Scope
F&O_UPGRADE is limited to the **Signal + Paper F&O workflow**. The Profitability Lab remains an independent module and its Python tree is byte-identical to the v3.7.15 baseline.

## Delivered
- Automatic option analysis can compare up to **3 provider-supported expiries** before selecting the winning expiry/strategy package.
- Upstox fallback can expose the first 3 active **monthly** option expiries from its local instrument master; weekly symbols are not guessed.
- Automatic Futures analysis can evaluate **NEAR / NEXT / FAR** (up to 3 contracts) while retaining a material-advantage preference for NEAR liquidity.
- Strategy-aware expiry fitness includes DTE, liquidity, spread quality, strategy score, Greek fit and risk/reward evidence.
- Strike selection uses combined fitness rather than Delta distance alone: Delta fit, liquidity, spread, opportunity score, OI/volume depth, ATM/distance and DTE evidence.
- Missing Delta is explicit (`DELTA UNAVAILABLE`) and uses a controlled liquidity/ATM fallback rather than silently treating Delta as valid.
- Debit/credit/condor hedge selection compares up to the first **3 outward liquid strike widths**, including payoff/risk-reward evidence.
- Every selected option leg retains exact expiry, symbol, side, strike, bid/ask/LTP reference, quote timestamp and selection evidence.
- Signal → Paper uses an **exact contract-lock hash**. Paper cannot silently substitute another expiry/strike/symbol.
- Paper entry requires exact-leg quote freshness (maximum **30 seconds**).
- Paper fills are side-aware: BUY uses ask-side evidence plus impact; SELL uses bid-side evidence minus impact; fresh LTP fallback remains bounded.
- Futures Signal detail retains **spot, Futures LTP, basis and basis %**.
- One strategy remains one Signal/Paper row. Two-leg structures show both strikes compactly; four-leg structures stay compact and expose every leg in hover/details.
- Signal details expose source, expiry rank, quote age, why-selected reasons, rejected alternatives and lifecycle history.
- Signal quick/view buttons expose checked state plus an `ACTIVE FILTERS` summary using the existing WINGO palette.
- Paper exposes **Capital Required, Capital Deployed, Notional Exposure, ROC %, Margin Source, Max Loss, Max Profit, Breakeven and Quote Age@Open**.
- Paper detail provides leg-wise BUY/SELL, expiry, quantity ratio, entry/current marks and leg-wise P&L.

## Signal header sorting hotfix
- Signal table header clicks are now explicitly routed to the external record-level sorter.
- First click on a column sorts ascending; clicking the same column again toggles descending/ascending.
- The active column/direction sort indicator is shown in the header and cleared by Reset/Clear Sorting.
- Saved table-layout sort restore is now compatible with the Signal sorter via `rerender=False`, avoiding unnecessary table rebuild during restore.
- This is presentation/data-ordering only; Signal generation, F&O selection policy, Paper logic, Profitability logic and the global color map are unchanged.

## Color-code protection
No global color token was changed. The existing `THEME` assignment is byte-identical to v3.7.15.
- BUY legs reuse existing green.
- SELL legs reuse existing red.
- Positive P&L/ROC reuse green; negative P&L/ROC reuse red.
- Max Loss uses red; Max Profit uses green.
- `ESTIMATED` / unavailable margin source uses existing amber.

## Safety / separation
- Profitability Lab Python tree SHA-256 remains `5eb3cb29f5b704d3dfff5a5c02f63c7d97d008890e09a904ab54f6dcce78dbb7`.
- Existing WINGO THEME SHA-256 remains `53d6830f1cd99388f234a0632aeb92de20c4e3b5f1720a33fadbd5a3bbb8a3b1`.
- Execution gate is byte-identical to v3.7.15.
- FYERS SDK remains pinned to **3.1.16**.
- Application `.place_order()` calls remain **0**.
- Real execution remains **LOCKED**.

## Validation note
Expiry/strike/width ranking is a bounded research selection policy, not proof of profitability. It should continue through Paper/OOS evidence before any future activation decision.

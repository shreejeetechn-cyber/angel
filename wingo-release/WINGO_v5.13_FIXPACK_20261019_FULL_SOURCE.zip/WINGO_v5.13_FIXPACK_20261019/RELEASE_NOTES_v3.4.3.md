# WINGO v3.4.3 - Final Data-Safety Stabilization

- Data Age is calculated from the last accepted market tick and continues to
  advance when a provider freezes or disconnects.
- Data Age visibly changes through LIVE, AGING and STALE states.
- A stale row cannot remain accepted: after 15 seconds without a live tick,
  the strict gate automatically adds `STALE_OVER_15S` and blocks the row.
- UPSTOX and FYERS have independent LIVE/READY/OFFLINE colours; the configured
  primary provider is marked with a star.
- v3.4.2 Mode 2 numerical screen, automatic scans, shadow validation, paper
  simulation, NSE-only scope and central `.env` behavior are retained.
- Live broker execution remains locked.

# WINGO v4.3.4 — Web Phase 3 Local Control Plane

Build: `WINGO v4.3.4 Web Phase 3 Local Control Plane (Live Execution Locked)`

## Phase 3

- Adds a localhost Control Center on top of Web Phase 1/2.
- Adds central `.wingo_state/web_control` disk IPC between browser server and desktop WINGO.
- Desktop publishes a bounded heartbeat; browser controls are enabled only while the desktop runtime is fresh/online.
- Commands are allow-listed, atomically claimed, expire after 5 minutes, and retain bounded PASS/FAIL history.
- Safe browser actions: Full Scan, Incremental Scan, Stop Scan, Profitability manual refresh, Market Breadth refresh, Signals refresh, Scheduled Entries refresh.
- Phase 2 Scanner, Signals, Scheduled Entries, provider cards, market ribbon, sorting, filters, pagination, WebSocket status, and localhost security remain present.

## Safety

No broker-order action, auth-secret action, Paper order-creation action, Stage-8 action, or live-execution unlock exists in the bridge. Live execution remains LOCKED.

## Runtime stability retained

All v4.3.3 runtime-stability changes are retained, including Profitability live analytics background processing, CVD O(1) deduplication, bounded live ingress, Session Status bulk-signal guards, Signals pre-render filtering, and Upstox silent-stale recovery.

## Verification

- `qa/verify_v4_3_4_web_phase3.py`: PASS.
- Real FastAPI localhost control handshake: OFFLINE 409 -> fresh desktop heartbeat -> 202 queued command: PASS.
- v4.3.1 Web Phase 2 regression contract on compatibility identity: PASS.
- v4.3.3 Runtime Stability Hotfix regression contract on compatibility identity: PASS.
- Python compileall and JavaScript syntax check: PASS.

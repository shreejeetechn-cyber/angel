# WINGO 5.11.1

Dashboard readability hotfix only.

- No dashboard layout/panel geometry redesign.
- Dashboard/status text uses Arial 10 minimum where compact text previously used 9 px.
- Ambiguous provider/status abbreviations are expanded.
- Market Breadth is text-only: DECLINE, ADVANCE, UNCHANGED; donut/graphics removed.
- Ambiguous dashboard headers expanded (Monthly/Weekly/Daily RSI, Change, Last Price).
- Footer uses full INTERFACE and LAST ACTION labels; theme names are never reduced to one-letter codes.
- Trading logic, scanner logic, broker routing, Paper logic, licensing, keys and live-execution lock are unchanged.

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PY=%CD%\.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=python"

echo [1/5] Python + PySide6 environment
"%PY%" -c "import sys, PySide6; print(sys.version); print('PySide6', PySide6.__version__)" || exit /b 1

echo [2/5] Compile all
"%PY%" -m compileall -q . || exit /b 1

echo [3/5] v5.09 architecture
set PYTHONPATH=%CD%
"%PY%" qa\verify_v5_09_architecture.py || exit /b 1

echo [4/5] Stress/soak
"%PY%" qa\verify_v5_08_stress_soak.py || exit /b 1

echo [5/5] Active release gate
"%PY%" qa\run_active_release_gate.py || exit /b 1

echo.
echo WINGO v5.09 OFFLINE/WINDOWS QA PASS
exit /b 0

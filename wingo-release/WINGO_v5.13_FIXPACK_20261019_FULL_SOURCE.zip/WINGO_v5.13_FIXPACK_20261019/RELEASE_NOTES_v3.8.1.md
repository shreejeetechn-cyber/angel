# WINGO v3.8.1 spread_risk_hotfix

Scope: NSE F&O Paper/Shadow only. Live execution remains locked.

## Fixed

- Multi-leg option max loss is independently recomputed from the complete
  expiry payoff instead of trusting a single-leg premium or stale signal value.
- Debit spread risk uses net debit.
- Credit spread risk uses wing width less net credit.
- Iron-condor risk uses the worst wing after combined net credit.
- Manual and Auto Paper sizing now use the configured planned Stop-Loss on the
  recomputed defined spread loss, matching the multi-leg Paper exit rule.
- Risk dialog separately reports planned Stop-Loss risk, theoretical maximum
  loss, and the calculation source.

## Safety

- Risk limits remain enforced; this hotfix does not force an unaffordable lot.
- Existing Paper accounting, brokerage/tax/slippage, signal generation,
  provider feeds and live-execution lock are unchanged.

## Verification

Run:

`python qa/verify_v3_8_1_spread_risk_hotfix.py`


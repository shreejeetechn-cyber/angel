# WINGO v3.7.3 — Compact Merged Header

A presentation-only Profitability Page refinement on top of v3.7.2 Slim Market Ribbon.

## Profitability Page header
- Merged the former title, readiness and engine/status areas into one slim operational header.
- New compact sequence: `WINGO Matrix | VIEW | ENG | SES | EXEC | SAFE | ROWS | SH | OF | ACC | PA | DATE/TIME | F | ↻ | Pop Out/Return`.
- Detached Profitability window uses the short `Return` action in the header.
- Long explanatory subtitle and the former broad readiness/status panels are removed from the visual flow; full readiness/provider detail remains available through tooltips.
- Matrix tabs use short labels: Matrix, Details, Graph, Shadow, Performance and Paper.
- Filters remain fully functional but are on-demand through the compact `F` control in both Superpage and Advanced Matrix modes.

## Functional status colours
- `ENG`: green when active, amber when disabled.
- `SES`: green READY, cyan ARMED, amber WARMING/CHECKING, red BLOCKED.
- `EXEC`: amber while the execution lock is asserted; red warning if that assertion is ever absent.
- `SAFE`: green when Safe Start is OFF (normal mode), amber when Safe Start is ON/restricting automation.
- `ROWS`: cyan when populated, amber at zero.
- `OF`: green active, amber waiting.
- `ACC`: green all-pass, amber mixed/warn, red all-blocked; shown as PASS/TOTAL and includes WARN rows in the total.
- `PA`: green ARMED, amber WAIT, red BLOCK/FAIL, neutral OFF.

## Vertical-density target
- Merged header: 28–30 px.
- Tab strip: capped at 20 px.
- Market ribbon: 38–40 px.
- Filters are hidden by default.
- Source-level layout budget keeps the normal Matrix upper chrome near the requested ~100 px target before the data table.

## Safety / scope
- No Profitability calculation, RSI, lifecycle, VWAP, OI, CVD, depth, scoring, strategy, validation, optimizer or paper-automation engine logic changed.
- Live broker execution remains locked.
- Crash/Hang Shield and the v3.6.2 native sorting crash protection remain intact.
- This environment does not include PySide6, so final Windows DPI/font pixel appearance still requires the normal Windows visual acceptance check.

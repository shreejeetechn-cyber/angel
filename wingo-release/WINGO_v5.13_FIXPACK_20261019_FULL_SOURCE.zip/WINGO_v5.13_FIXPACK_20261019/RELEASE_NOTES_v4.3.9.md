# WINGO v4.3.9 — Desktop-Web GUI Parity Hotfix

Base: WINGO v4.3.8 Profitability Intelligence Merge + Web Phase 5.

## Delivered

- Preserved the v4.2.13-derived desktop GUI as the visual source of truth.
- Matched the Web Phase-5 shell to desktop compact geometry:
  - Sidebar 225px expanded / 64px collapsed.
  - Sidebar padding 8/14/8/8 and 44px navigation rows.
  - WINGO / OPTION SCANNER desktop branding.
  - 38px workspace bar and 38px fixed status footer.
  - Arial operational typography.
  - 11px table text, 6x7px header padding, 3x6px cell padding.
  - Desktop panel/sidebar/border/hover/selection semantics.
- Added exact Web palette mappings for Midnight Dark, Royal Blue and Royal Green.
- Desktop heartbeat now publishes `ui_theme`; authenticated Web UI mirrors the active desktop theme automatically.
- Web footer now surfaces FYERS, UPSTOX, Scanner, Paper, Data and Live-lock status with the desktop clock format `DD:MM:YY - HH:MM:SS`.
- Current Web navigation updates the PAGE label in the workspace bar.
- Removed duplicate Scheduled Entries filter listener wiring.

## Retained

- v4.2.13 Profitability Intelligence correctness/performance contract.
- v4.3.3 background Profitability analytics/CVD stability architecture.
- Web Phase 1–5 data/auth/control wiring.
- Login, Logout, HttpOnly session, CSRF and authenticated WebSocket.
- Live execution LOCKED; Stage 8 absent.

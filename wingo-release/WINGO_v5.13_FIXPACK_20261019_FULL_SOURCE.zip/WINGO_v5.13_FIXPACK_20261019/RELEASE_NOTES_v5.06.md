# WINGO v5.06 — AI Trade Intelligence Feedback + Hang Hardening

## AI trade intelligence
- Corrected MCX Futures AI economics: `broker_lot_size` is kept for order quantity while `economic_quantity_per_lot` drives notional, risk and capital-efficiency calculations.
- Added functional AI master pause, Auto Paper Entry/Exit controls, minimum grade, DTE range, maximum bid/ask spread, quote-age, alternative-search, candidates-per-signal and bootstrap-position controls.
- Added bounded champion-learning feedback to ranking only. The multiplier is safety-capped to ±10% and cannot make an ineligible candidate eligible.
- Added automatic auditable rollback to the prior champion policy when promoted evidence later fails configured PF/expectancy requirements.
- Rejected-trade and missed-opportunity learning toggles now control their respective optional learning streams while the audit passport remains intact.

## True market freshness
- Removed analysis-time/repricing-time `time.time()` fallbacks from Futures and option leg freshness paths.
- Provider quote timestamps are preserved through strategy normalization and Paper repricing. Unknown timestamps fail closed rather than being fabricated as fresh.

## GUI / hang hardening
- AI planner evaluation moved to a background `FunctionWorker` using immutable snapshots.
- Added a cheap AI signal prefilter and a default 120-signal per-cycle cap before expensive profitability analysis.
- Signals UI rendering now uses a production time-budget helper and a hard four-row chunk cap.
- Web-control heartbeat polling no longer performs a full Qt widget mirror walk. Non-forced mirror updates reuse cache; forced compatibility snapshots are time-budgeted.
- Added deterministic 2,500-candidate AI planner and 2,500-row Signals stress tests.

## Retained
- v5.05 MCX contract economics, conservative broker-margin authority and fresh-LTP gates.
- v5.03 MCX Futures signal decoupling.
- Profitability Policy v2.
- Daily manual broker 2FA security model.
- Live Execution LOCKED; Stage 8 ABSENT.

## Runtime-only validation
Actual Windows GUI heartbeat under a live broker session, actual fresh NSE/MCX ticks, downloaded live MCX lot/multiplier provider consensus, live broker margin response and live websocket hard-reconnect remain runtime-session checks and are not represented as offline PASS.

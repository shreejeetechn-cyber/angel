# WINGO v3.2.5 — UI Self-Test Readability Hotfix

Build: `WINGO v3.2.5 UI Self-Test Readability Hotfix (Execution Locked)`

## Runtime failure closed

Diagnostics reported `96 buttons checked; blank-without-icon=2`. When the
sidebar was collapsed, page text was intentionally removed, but the
filename-derived icons for `RSI Divergence` and `Backtest` did not exist.
Those two controls therefore became blank and UI Self-Test correctly failed.

## Corrections

- `RSI Divergence` reuses the verified Scanner icon.
- `Backtest` reuses the verified Research icon.
- The navigation resolver now has an Intelligence fallback icon.
- Navigation buttons have stable object names for precise diagnostics.
- A new Navigation Icons check validates all 20 pages even with the sidebar
  expanded.
- Button Readability failure details now include exact control identities.
- Paper's continuous quote transport is shown as `READY` with
  `transport=ACTIVE`; it is no longer mislabeled as a blocking `BUSY` job.
- Authentication readiness checks both FYERS and Upstox control/handler sets.
- Core credential diagnostics follows the selected primary provider and marks
  an unconfigured optional provider as informational instead of failed.

## Retained scope and safety

- v3.2.4 provider-neutral market breadth remains included.
- Paper ledger, charges, slippage, manual funds, table tools, trend policy,
  A+/B+ divergence and cache/restart controls remain included.
- Credentials remain only in the centralized Wingo-root `.env`.
- BSE remains excluded and real broker execution remains locked.

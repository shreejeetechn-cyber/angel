# WINGO v4.5.1 — Cross-Version Runtime Exclusivity Hotfix

Base: WINGO v4.5.0 Unified Core + AutoFit Clean GUI.

## Problem fixed

v4.5.0 correctly prevented a second **v4.5.x Unified Core** from starting, but legacy builds such as v4.4.1 did not know the new `core.lock` / port-8788 protocol. A legacy Desktop runtime could therefore be launched at the same time and could establish its own broker/login/feed session.

## Cross-version exclusivity

- Uses the already-shared `C:\Wingo\.wingo_state\runtime\run_state.json` marker written by both legacy and current WINGO builds.
- Before spawning the Unified Core, the launcher rejects any live foreign WINGO runtime owner.
- Direct `unified_main.py` startup has the same guard, so bypassing the BAT launcher cannot create a second runtime.
- A v4.5.1 launcher refuses to silently attach to an already-running different Unified Core version such as v4.5.0.
- While v4.5.1 is running, a 250 ms fail-closed monitor detects a later legacy WINGO launch through the shared run-state.
- On such a conflict, v4.5.1 first requests live-feed disconnect and active scanner stop, then cleanly shuts down its own Core.
- WINGO never silently kills the foreign/legacy process.
- Conflict evidence is written to `.wingo_state\unified_core\LAST_RUNTIME_CONFLICT.txt` and exposed in Core status while shutdown is beginning.
- Startup process verification uses the foreign PID command line when available to avoid stale PID-reuse false positives.

## Retained

- One Unified Core shared by Desktop and Web.
- Desktop-first, Web-first, Core-only and combined launch modes.
- Desktop close hides only the Desktop client when no runtime conflict exists.
- 32/32 Desktop/Web page mirror.
- AutoFit clean Desktop/Web GUI.
- v4.4.1 Profitability `_row_refresh_signature` crash hotfix.
- v4.3.3 background Profitability/CVD stability architecture.
- v4.2.13 selected-timeframe Profitability intelligence.
- Sensitive broker/auth input remains memory-only/redacted.
- Stage 8 remains absent. Live Execution remains LOCKED.

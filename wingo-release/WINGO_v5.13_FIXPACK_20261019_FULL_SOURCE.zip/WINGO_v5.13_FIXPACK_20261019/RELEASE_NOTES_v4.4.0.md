# WINGO v4.4.0 — Web Phase 6 Full Desktop Parity

Base: WINGO v4.3.9 Desktop-Web GUI Parity.

## Implemented

- Browser navigation now exposes the same 32 Desktop WINGO pages in the same order.
- Web Phase 6 mirrors the currently active PySide page instead of duplicating business logic.
- Browser controls dispatch to the existing Desktop widget/action handlers.
- Direct browser controls for Connect Live Feed, Disconnect, and Reconnect call the single Desktop feed engine; no second broker socket is created.
- Mirrored controls: push/tool buttons, checkbox/radio, line edit, text edit, combo, spin/slider, tabs, progress bars and QTableWidget content.
- Tables are bounded to 80 rows per mirror page and maintain per-table offsets to protect the GUI thread.
- Table actions include cell click/double-click, sort, filter, Auto Fit, Fit Window, A-/A+, Focus, Copy, hide/show rows/columns, Reset and CSV export.
- Workspace controls include page navigation, Pop Out, Dock, Focus, Next Monitor, Dock All, restore-layout setting, target monitor, theme, UI scale and Safe Quit.
- Authentication credential-like fields are redacted from snapshots. Browser-submitted sensitive values use a memory-only localhost socket bridge and never enter disk command history.
- Web session authentication, CSRF protection, localhost-only binding, HttpOnly session cookie and authenticated mutation rules remain in place.
- Stage 8 remains absent. Live/broker order execution remains LOCKED and execution-like mirrored browser controls are explicitly blocked.
- v4.2.13 selected-timeframe Profitability Intelligence and v4.3.3 background analytics/CVD stability architecture are retained.

## Runtime architecture

`FYERS / Upstox -> Desktop WINGO engine -> bounded GUI mirror/state -> authenticated localhost Web GUI`

Desktop remains the sole engine owner. Web Phase 6 is a control/mirror surface, not a second trading engine.

## Verification boundary

Static/source QA, Python compile, JavaScript syntax, API contract and package integrity can be verified in the build environment. A real Windows + PySide6 + live-broker soak still requires the target WINGO PC.

Live execution remains locked.

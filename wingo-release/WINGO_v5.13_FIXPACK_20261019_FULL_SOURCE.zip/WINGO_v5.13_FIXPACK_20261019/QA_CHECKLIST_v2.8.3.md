# WINGO v2.8.3 QA Checklist

## Local runtime
1. Start with `START_WINGO.bat` using the existing shared WINGO `.venv` and `.env`.
2. Authentication -> generate/refresh token -> Validate Auth without restarting WINGO.
3. Diagnostics -> Run Full Diagnostics; both System and UI tables should have no unexpected FAIL.
4. Start Full Scan, verify live Dashboard updates, then press Stop before completion:
   - Scanner must say STOPPED, not DONE.
   - Progress must remain below 100%.
   - Partial scan must not become the previous-full-scan baseline.
5. Run a full scan to completion and verify 100%/DONE and baseline persistence.
6. Futures -> Sync Master -> Snapshot -> Near/Next/Far. Force a failure (e.g. offline) and verify Sync button re-enables.
7. Option Chain -> Analyze two different underlyings; Dashboard Best Contract must only appear for its matching underlying.
8. Paper -> with an open paper position, disconnect/error the option feed and click Sync Live Option Feed; it must retry even with the same symbol set.
9. Enable Automation, close WINGO, restart; Automation page must show RUNNING and timer must be active.
10. Collapse/expand sidebar; icons should remain readable and Settings Save must preserve collapsed preference.
11. Watchlist -> add/remove/open Scanner/Futures/Option Chain.
12. Close WINGO while a background job is active; app should wait for the thread instead of emitting QThread destruction errors.
13. Logs -> verify no token/auth-code/PIN/TOTP value is visible after auth failures or successes.
14. Diagnostics UI matrix -> Watchlist should report READY (not false FAIL); Live Execution should report DISABLED as the expected safety state.
15. Check dense table headers and metric labels for `Chg` / `Chg %`; no tiny delta glyph is required for meaning.

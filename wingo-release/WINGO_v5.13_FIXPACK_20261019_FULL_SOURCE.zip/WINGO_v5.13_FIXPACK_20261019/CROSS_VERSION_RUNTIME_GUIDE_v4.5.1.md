# WINGO v4.5.1 Cross-Version Runtime Guide

## Intended rule

Only one WINGO build/runtime may own the shared `C:\Wingo` operational state at a time.

Desktop and Web **of the same v4.5.1 build** are equal clients of one Unified Core and may both remain open. Different WINGO versions must not run together.

## Expected behavior

### If v4.4.1 is already running

Starting v4.5.1 is refused before a second Core is spawned. Close v4.4.1, then start v4.5.1.

### If v4.5.0 Unified Core is already running

v4.5.1 refuses to attach to it. Run the older build's `STOP_WINGO_CORE.bat`, then start v4.5.1.

### If v4.5.1 is already running and a legacy v4.4.1 Desktop is launched later

The legacy build cannot honor the v4.5.x lock because it predates it. v4.5.1 therefore detects the foreign run-state within about 250 ms, requests its own feeds/scanner to stop and cleanly exits. The legacy process is not force-killed.

## Recommended operating practice

After verifying v4.5.1, keep old build folders only as archives. Do not use their `START_WINGO.bat` launchers during normal operation. Use the v4.5.1 launchers only:

- `START_WINGO.bat` — Desktop client + ensure same v4.5.1 Core
- `START_WINGO_WEB.bat` — Web client + ensure same v4.5.1 Core
- `START_WINGO_ALL.bat` — Desktop + Web on one Core
- `STOP_WINGO_CORE.bat` — explicit full shutdown

## Diagnostic evidence

Cross-version conflict report:

`C:\Wingo\.wingo_state\unified_core\LAST_RUNTIME_CONFLICT.txt`

Main log:

`C:\Wingo\.wingo_state\logs\wingo.log`
